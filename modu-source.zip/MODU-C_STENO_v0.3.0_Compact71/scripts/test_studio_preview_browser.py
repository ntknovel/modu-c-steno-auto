#!/usr/bin/env python3
"""Optional source-derived HTML preview test. NOT an official Studio/device test.

Requires Playwright and Chromium only for this optional test, not for firmware builds.
The page is loaded with set_content: no browser extension, web server or device API.
"""
from __future__ import annotations
import argparse
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--screenshots', action='store_true', help='Refresh docs preview PNGs')
    args = parser.parse_args()
    from playwright.sync_api import sync_playwright
    binary = shutil.which('chromium') or shutil.which('chromium-browser')
    if not binary:
        raise SystemExit('Chromium is required for this optional preview test.')
    markup = (ROOT/'STUDIO_LAYOUT_PREVIEW_KO.html').read_text(encoding='utf-8')
    checks: list[str] = []
    def ok(name: str, condition: bool) -> None:
        if not condition:
            raise AssertionError(name)
        checks.append(name)
        print('PASS:', name)
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=binary, headless=True, args=['--no-sandbox'])
        page = browser.new_page(viewport={'width':1440,'height':1100},device_scale_factor=1)
        page.set_default_timeout(8000)
        errors: list[str] = []; requests: list[str] = []
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.on('request', lambda r: requests.append(r.url))
        page.set_content(markup,wait_until='load')
        ok('71 keys and exactly two mode-setting squares',page.locator('.key').count()==71 and page.locator('.mode-setting').count()==2)
        ok('center squares are not circular',page.locator('.mode-setting').evaluate_all('(xs)=>xs.every(x=>{const r=x.getBoundingClientRect();return Math.abs(r.width-r.height)<.01&&parseFloat(getComputedStyle(x).borderRadius)<r.width/4;})'))
        for start,center in ((61,69),(65,70)):
            ok('pixel-accurate four-way cross '+str(center),page.evaluate('''([start,center])=>{
              const at=i=>document.getElementById('key-'+i).getBoundingClientRect();const c=at(center);
              return [[0,-1],[0,1],[-1,0],[1,0]].every(([dx,dy],i)=>{const a=at(start+i);
                return Math.abs(a.x-c.x-dx*62)<.01&&Math.abs(a.y-c.y-dy*62)<.01&&Math.abs(a.width-c.width)<.01&&Math.abs(a.height-c.height)<.01;});
            }''',[start,center]))
        ok('additional B remains beside N',page.evaluate('''()=>{let b=document.getElementById('key-60').getBoundingClientRect(),n=document.getElementById('key-42').getBoundingClientRect();return Math.abs(b.y-n.y)<.01&&Math.abs(n.x-b.x-62)<.01;}'''))
        ok('all keys fit the keyboard canvas',page.evaluate('''()=>{let c=document.getElementById('keyboard').getBoundingClientRect();return [...document.querySelectorAll('.key')].every(k=>{let r=k.getBoundingClientRect();return r.x>=c.x-.01&&r.y>=c.y-.01&&r.right<=c.right+.01&&r.bottom<=c.bottom+.01;});}'''))
        for center,modifier,up in ((69,49,61),(70,52,65)):
            ok('cross directly below Alt/Ctrl '+str(center),page.evaluate("""([c,m,u])=>{
              const at=i=>document.getElementById('key-'+i).getBoundingClientRect();
              return Math.abs(at(c).x-at(m).x)<.01&&Math.abs(at(u).y-at(m).y-62)<.01;
            }""",[center,modifier,up]))
        ok('compact source layout is 14 by 8 units',page.evaluate("""()=>
          Math.max(...DATA.layout.map(k=>k.x+(k.w||1)))===14&&
          Math.max(...DATA.layout.map(k=>k.y+(k.h||1)))===8"""))
        ok('group captions do not cover keys',page.evaluate("""()=>{
          const overlaps=(a,b)=>Math.min(a.right,b.right)>Math.max(a.left,b.left)+.01&&
            Math.min(a.bottom,b.bottom)>Math.max(a.top,b.top)+.01;
          return [...document.querySelectorAll('.sub-group-label')].every(t=>
            [...document.querySelectorAll('.key')].every(k=>!overlaps(t.getBoundingClientRect(),k.getBoundingClientRect())));
        }"""))
        page.locator('#key-69').click()
        ok('left center selects left profile',page.locator('#details code').inner_text()=='&lball MC_MOUSE')
        page.locator('#profile-choice').select_option('1')
        ok('left Wheel preview does not change right',page.locator('#key-69 .mode').inner_text()=='Wheel' and page.locator('#key-70 .mode').inner_text()=='Mouse')
        page.locator('#key-70').click(); page.locator('#profile-choice').select_option('2')
        ok('right center selects independent Arrows preview',page.locator('#details code').inner_text()=='&rball MC_ARROWS' and page.locator('#key-69 .mode').inner_text()=='Wheel')
        page.locator('#demo-left').click()
        ok('mode cycle demo keeps profile display as baseline',page.locator('#key-69 .mode').inner_text()=='Wheel' and page.locator('#demo-status').inner_text()=='왼쪽: Arrows / 오른쪽: Arrows')
        for side in (69,70):
            page.locator('#key-'+str(side)).click();page.locator('#profile-choice').select_option('4')
            ok('Follow preview shows real source macro '+str(side),page.locator('#details code').inner_text()==('&lball ' if side==69 else '&rball ')+'MC_PROFILE_KEYS')
        page.locator('#key-63').click()
        ok('leftward virtual key opens LEFT binding',page.locator('#details code').inner_text()=='&kp LEFT')
        page.locator('#key-69').click();page.locator('[data-layer="1"]').click()
        ok('Fn center remains transparent with profile editing disabled',page.locator('#key-69 .mode').inner_text()=='▽' and page.locator('#profile-choice').is_disabled() and page.locator('#details code').inner_text()=='&trans')
        page.locator('[data-layer="2"]').click()
        ok('controls keep two physical cycle keys and bootloaders',page.locator('.cycle').count()==2 and page.locator('.boot').count()==2 and page.locator('#key-54').inner_text().startswith('L ↻') and page.locator('#key-58').inner_text().startswith('R ↻'))
        page.locator('[data-layer="0"]').click()
        ok('return to Base enables central preview selection',page.locator('#profile-choice').is_enabled())
        ok('nine layer tabs exposed',page.locator('[data-layer]').count()==9)
        page.locator('[data-layer="7"]').click()
        for key,binding in ((60,'&st_mode'),(13,'&st_i_b'),(56,'&st_vu_enter'),(57,'&st_veo_space'),(0,'&mxesc'),(11,'&mxbsp'),(12,'&mxtab')):
            page.locator('#key-'+str(key)).click()
            ok('STENO source binding '+str(key),page.locator('#details code').inner_text()==binding)
        for lid in range(9):
            page.locator('[data-layer="'+str(lid)+'"]').click()
            ok('all 71 positions visible on layer '+str(lid),page.locator('.key').count()==71)
        page.locator('[data-layer="0"]').click()
        page.set_viewport_size({'width':700,'height':1000})
        ok('small viewport uses an internal horizontal canvas without key loss',page.locator('.canvaswrap').evaluate('(x)=>x.scrollWidth>x.clientWidth&&getComputedStyle(x).overflowX==="auto"') and page.locator('.key').count()==71)
        ok('no JavaScript errors',not errors)
        ok('no external resources or network requests',not requests)
        if args.screenshots:
            page.close()
            page=browser.new_page(viewport={'width':1440,'height':1100},device_scale_factor=1)
            page.set_default_timeout(8000)
            page.on('pageerror',lambda e:errors.append(str(e)))
            page.set_content(markup,wait_until='load')
            assert page.locator('.key').count()==71 and not errors
            print('Rendering source preview PNGs', flush=True)
            page.screenshot(path=str(ROOT/'docs/studio-layout-preview.png'),full_page=True)
            page.locator('#keyboard').screenshot(path=str(ROOT/'docs/studio-keyboard-layout.png'))
            page.locator('[data-layer="7"]').click()
            page.screenshot(path=str(ROOT/'docs/steno-layout-preview.png'),full_page=True)
            page.locator('[data-layer="2"]').click()
            page.screenshot(path=str(ROOT/'docs/controls-preview.png'),full_page=True)
        browser.close()
    print(f'PASS: {len(checks)} source-preview browser checks. No official Studio/USB/hardware test.')

if __name__ == '__main__':main()
