#!/usr/bin/env python3
"""Run inside the official ZMK build container after west update. No Codespaces."""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from prepare_build import verify_commit, MODU_REV, ZMK_REV
from prepare_from_edt import prepare, original_keymap
from patch_compact_storage import apply as apply_compact_storage
from compile_mapper import prepare_project

def run(command, cwd, log):
    print('+ '+' '.join(map(str,command)),flush=True)
    with log.open('a',encoding='utf-8') as out:
        out.write('+ '+' '.join(map(str,command))+'\n');out.flush()
        p=subprocess.Popen(list(map(str,command)),cwd=cwd,stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT,text=True,bufsize=1)
        assert p.stdout
        for line in p.stdout:print(line,end='');out.write(line)
        if p.wait():raise subprocess.CalledProcessError(p.returncode,command)

def build_command(root: Path, workspace: Path, side: str, entry: dict) -> list:
    """Pure command construction, exercised without starting west or fetching sources."""
    if side not in ('left', 'right'):
        raise ValueError('Unknown side: ' + side)
    build=workspace/'build'/side
    mods=[workspace/'modu-c-firmware/modu-module',workspace/'modu-c-firmware/zmk-pmw3610-driver',root/'modules/modu-control',root/'modules/modu-steno']
    cmd=['west','build','-p','always','-s',workspace/'zmk/app','-d',build,'-b',entry['board']]
    if entry['snippet']:cmd+=['-S',entry['snippet']]
    cmd+=['--',f'-DSHIELD={entry["shield"]}',f'-DZMK_CONFIG={root/"config"}',
          '-DZMK_EXTRA_MODULES='+';'.join(map(str,mods)),
          f'-DEXTRA_CONF_FILE={root/"modules/modu-control/modu.conf"};{root/"modules/modu-steno/modu-steno.conf"}',
          '-DCONFIG_ZMK_STUDIO='+('y' if side=='left' else 'n')]
    if side=='left':
        # Only disable Studio GATT, not BLE HID or the wireless split link.
        cmd+=['-DCONFIG_ZMK_STUDIO_TRANSPORT_BLE=n', '-DCONFIG_ZMK_STUDIO_LOCKING=n']
    return cmd

def baseline_command(root: Path, workspace: Path, side: str, entry: dict) -> list:
    """Configure the uploaded ORIGINAL keymap with only the original hardware modules."""
    if side not in ('left', 'right'):
        raise ValueError('Unknown side: ' + side)
    baseline_config=workspace/'build'/('original-config-'+side)
    modules=[workspace/'modu-c-firmware/modu-module',
             workspace/'modu-c-firmware/zmk-pmw3610-driver']
    return ['west','build','-p','always','--cmake-only',
            '-s',workspace/'zmk/app','-d',workspace/'build'/('original-'+side),
            '-b',entry['board'],'--',f'-DSHIELD={entry["shield"]}',
            f'-DZMK_CONFIG={baseline_config}',
            '-DZMK_EXTRA_MODULES='+';'.join(map(str,modules))]

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--side',choices=['left','right'],required=True)
    p.add_argument('--workspace',type=Path,required=True)
    p.add_argument('--config',type=Path,required=True)
    a=p.parse_args();root=a.config.resolve();workspace=a.workspace.resolve()
    diagnostics=root/'diagnostics'/a.side;diagnostics.mkdir(parents=True,exist_ok=True)
    build=workspace/'build'/a.side
    baseline=workspace/'build'/('original-'+a.side)
    try:
        verify_commit(workspace/'zmk',ZMK_REV)
        verify_commit(workspace/'modu-c-firmware',MODU_REV)
        entry=next(x for x in json.loads((root/'build.yaml').read_text())['include'] if x['side']==a.side)
        baseline_config=workspace/'build'/('original-config-'+a.side)
        baseline_config.mkdir(parents=True,exist_ok=True)
        (baseline_config/'modu.keymap').write_bytes(original_keymap(root))
        print('=== 1/4: Configure ORIGINAL hardware (CMake only, no baseline UF2) ===',flush=True)
        run(baseline_command(root,workspace,a.side,entry),workspace,diagnostics/'original-configure.log')
        print('=== 2/4: Use original compiled wiring; add Studio/trackball controls ===',flush=True)
        prepare(root,workspace,a.side,baseline)
        mapper_report = prepare_project(root)
        (diagnostics/'local-mapper-build.json').write_text(json.dumps(mapper_report, indent=2))
        patch_report = apply_compact_storage(root, workspace)
        (diagnostics/'compact-storage-patch.json').write_text(json.dumps(patch_report, indent=2))
        print('=== 3/4: Compile modified firmware ===',flush=True)
        cmd=build_command(root,workspace,a.side,entry)
        run(cmd,workspace,diagnostics/'build.log')
        print('=== 4/4: Compare original sensor properties; verify final binary ===',flush=True)
        run([sys.executable,root/'scripts/check_built.py','--build',build,'--side',a.side,'--zephyr-base',workspace/'zephyr','--baseline-report',diagnostics/'original-hardware.json'],workspace,diagnostics/'build.log')
        output=root/'intermediate';output.mkdir(exist_ok=True)
        for ext in ('uf2','hex'):
            src=build/'zephyr'/f'zmk.{ext}'
            if src.is_file():
                shutil.copy2(src,output/f'modu_{a.side}.{ext}');break
        else:raise RuntimeError('Build has neither zmk.uf2 nor zmk.hex; no flash artifact published')
    finally:
        for name in ('LICENSE','NOTICE.md','THIRD_PARTY_NOTICES.md'):
            shutil.copy2(root/name,diagnostics/name)
        shutil.copytree(root/"LICENSES",diagnostics/"LICENSES",dirs_exist_ok=True)
        # Retain the exact small hardware definitions on errors, so an unsupported
        # pinned layout can be corrected from evidence rather than guessed.
        upstream=workspace/'modu-c-firmware'
        snapshot=diagnostics/'upstream-hardware'
        snapshot.mkdir(exist_ok=True)
        for part in ('modu-module','zmk-pmw3610-driver'):
            for source in (upstream/part).rglob('*'):
                if source.is_file() and (source.suffix in ('.h','.c','.dts','.dtsi','.overlay','.conf','.yaml','.yml') or source.name.startswith('Kconfig') or source.name.endswith('_defconfig') or source.name=='CMakeLists.txt'):
                    dest=snapshot/source.relative_to(upstream)
                    dest.parent.mkdir(parents=True,exist_ok=True)
                    shutil.copy2(source,dest)
        for name in ('LICENSE','NOTICE.md','THIRD_PARTY_NOTICES.md'):
            source=upstream/name
            if source.is_file(): shutil.copy2(source,snapshot/name)
        # Original CMake output and the relevant pinned ABI sources make a failed
        # Actions run useful even when GitHub is unreachable from a review session.
        for relative in ('zephyr/.config','zephyr/zephyr.dts','CMakeCache.txt'):
            src=baseline/relative
            if src.is_file(): shutil.copy2(src,diagnostics/('original-'+src.name.lstrip('.')))
        abi_files=('app/include/drivers/behavior.h','app/include/drivers/input_processor.h',
                   'app/include/zmk/behavior.h','app/include/zmk/keymap.h',
                   'app/src/behavior.c','app/src/keymap.c','app/src/studio/Kconfig',
                   'app/src/split/central.c','app/src/split/peripheral.c')
        for relative in abi_files:
            src=workspace/'zmk'/relative
            if src.is_file():
                dst=diagnostics/'pinned-zmk-api'/relative
                dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
        # Capture actual selected Zephyr Bluetooth ABI/config definitions, not the whole checkout.
        zephyr_abi_files=('include/zephyr/bluetooth/hci.h','include/zephyr/bluetooth/hci_vs.h',
                          'include/zephyr/bluetooth/conn.h','include/zephyr/drivers/sensor.h',
                          'subsys/bluetooth/Kconfig','subsys/bluetooth/host/Kconfig',
                          'subsys/bluetooth/common/Kconfig','subsys/bluetooth/controller/Kconfig',
                          'samples/bluetooth/hci_pwr_ctrl/prj.conf','VERSION')
        for relative in zephyr_abi_files:
            src=workspace/'zephyr'/relative
            if src.is_file():
                dst=diagnostics/'pinned-zephyr-api'/relative
                dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
        for file in ('zephyr/.config' ,'zephyr/zephyr.dts','zephyr/zmk.map','zephyr/zephyr.map','CMakeCache.txt','modu-integration.json'):
            src=build/file
            if src.is_file():shutil.copy2(src,diagnostics/src.name)
        for src in (root/'config/generated').glob('*'):
            if src.is_file() and src.name!='.gitignore':shutil.copy2(src,diagnostics/src.name)

if __name__=='__main__':main()
