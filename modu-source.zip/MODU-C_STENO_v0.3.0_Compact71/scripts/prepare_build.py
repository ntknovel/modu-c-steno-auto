#!/usr/bin/env python3
"""Shared pinned-API checks plus LEGACY text-fixture utilities.

Production wiring is resolved by prepare_from_edt.py from an original Zephyr
CMake result. flatten()/resolve_dts() below are NOT used by the firmware build.
They remain solely to run the older synthetic fixture regression tests.
"""
from __future__ import annotations
import argparse
import json
from layout_contract import POSITIONS, POPULATED
import re
import subprocess
from pathlib import Path

ZMK_REV = '641514a97db345f499dd50b0360e594270f008fe'
MODU_REV = 'bee0bb4b812f63f279eb67e928accc89600b5904'
ORIGINAL = [(r,c) for r in range(5) for c in range(12)] + [(5,c) for c in (0,1,2,6,7,8,9)]
class PreflightError(RuntimeError): pass

def clean(text: str) -> str:
    """Remove comments, not comment-shaped string contents; retain line structure."""
    tokens = re.compile(r'"(?:\\.|[^"\\])*"|/\*.*?\*/|//[^\n]*', re.S)
    def replace(match):
        token = match[0]
        if token.startswith('"'):
            return token
        return ''.join('\n' if char == '\n' else ' ' for char in token)
    return tokens.sub(replace, text)

def closing(text: str, start: int) -> int:
    depth = 0
    quoted = False
    escape = False
    for i in range(start,len(text)):
        c=text[i]
        if quoted:
            if escape: escape=False
            elif c=='\\': escape=True
            elif c=='"': quoted=False
            continue
        if c=='"': quoted=True;continue
        if c=='{': depth+=1
        elif c=='}':
            depth-=1
            if depth==0: return i
    raise PreflightError('Unbalanced DTS braces')

def mask_strings(text: str) -> str:
    """Keep offsets but prevent literal braces/names from participating in syntax."""
    return re.sub(r'"(?:\\.|[^"\\])*"',
                  lambda m: ''.join('\n' if c == '\n' else ' ' for c in m[0]), text)

def top(text: str) -> str:
    # Remove child bodies before searching for properties on their parent.
    out=[]; pos=0; syntax=mask_strings(text)
    while True:
        i=syntax.find('{',pos)
        if i<0: return ''.join(out)+text[pos:]
        out.append(text[pos:i]); pos=closing(text,i)+1

def nodes(text: str) -> list[dict]:
    text=clean(text)
    pattern=r'(?:(?P<label>[A-Za-z_][\w]*)\s*:\s*)?(?P<name>&\{[^}]+\}|&[\w]+|[\w][\w,\-@]*)\s*\{'
    result=[]
    for m in re.finditer(pattern,mask_strings(text)):
        begin=m.end()-1; end=closing(text,begin)
        body=text[begin+1:end]
        result.append({'label':m['label'],'name':m['name'],'body':body,'top':top(body)})
    return result

def prop(n: dict, name: str) -> str | None:
    """Resolve ordered assignments/deletions in the merged node's own statements."""
    value = None
    begin = 0
    quoted = escape = False
    for index, char in enumerate(n['top']):
        if quoted:
            if escape:
                escape = False
            elif char == '\\':
                escape = True
            elif char == '"':
                quoted = False
            continue
        if char == '"':
            quoted = True
        elif char == ';':
            statement = n['top'][begin:index].strip()
            begin = index + 1
            if re.fullmatch(r'/delete-property/\s+' + re.escape(name), statement):
                value = None
            else:
                match = re.fullmatch(re.escape(name) + r'\s*=\s*(.*)', statement, re.S)
                if match:
                    value = match[1].strip()
    return value

def flatten(path: Path, seen: set[Path] | None=None) -> str:
    seen=set() if seen is None else seen
    path=path.resolve()
    if path in seen: return ''
    seen.add(path)
    text=clean(path.read_text(encoding='utf-8'))
    def include(m):
        child=path.parent/m[1]
        return flatten(child,seen) if child.is_file() else m[0]
    return re.sub(r'^\s*#include\s+"([^"\n]+)"',include,text,flags=re.M)

def one(values, what):
    values=list(dict.fromkeys(values))
    if len(values)!=1: raise PreflightError(f'Expected exactly one {what}; found {values}')
    return values[0]

def phandle(value: str | None, what: str) -> str:
    if not value: raise PreflightError(f'Missing {what}')
    # Both `property = &label;` and `<&label>` are valid single phandles.
    # Do not accept lists, path references or extra cells by partial matching.
    m=re.fullmatch(r'&([A-Za-z_]\w*)',value.strip())
    if not m: m=re.fullmatch(r'<\s*&([A-Za-z_]\w*)\s*>',value.strip())
    if not m: raise PreflightError(f'Unsupported {what}: {value}')
    return m[1]

def merged_for_label(ns, label):
    group=[n for n in ns if n['label']==label or n['name']=='&'+label]
    if not group: raise PreflightError('DTS label absent: '+label)
    return {'label':label,'name':group[0]['name'],'top':'\n'.join(n['top'] for n in group),
            'body':'\n'.join(n['body'] for n in group)}

def listener(ns, name):
    found=[n for n in ns if n['name']==name]
    if len(found)!=1: raise PreflightError(f'Cannot identify existing {name}: {len(found)} definitions')
    base=found[0]
    group=[n for n in ns if n is base or n['name']=='&{/'+name+'}' or
           (base['label'] and n['name']=='&'+base['label'])]
    return {'label':base['label'],'name':name,'top':'\n'.join(n['top'] for n in group),
            'body':'\n'.join(n['body'] for n in group)}

def require_enabled(node: dict, what: str) -> None:
    status=prop(node,'status')
    if status is not None and status not in ('"okay"','"ok"'):
        raise PreflightError(f'{what} is not enabled: {status}')

def resolve_dts(text: str, side: str, layout: list[dict]) -> tuple[str,dict]:
    ns=nodes(text)
    chosen={'top':'\n'.join(n['top'] for n in ns if n['name']=='chosen')}
    scan=phandle(prop(chosen,'zmk,kscan'),'chosen scan wrapper')
    transform=phandle(prop(chosen,'zmk,matrix-transform'),'chosen transform')
    tx=merged_for_label(ns,transform)
    actual=[tuple(map(int,p)) for p in re.findall(r'RC\(\s*(\d+)\s*,\s*(\d+)\s*\)',prop(tx,'map') or '')]
    if actual!=ORIGINAL: raise PreflightError(f'Pinned 67-key transform mismatch ({len(actual)} parsed entries)')
    if [(p['row'],p['col']) for p in layout] != POSITIONS:
        raise PreflightError('71-position JSON layout does not preserve the original order')
    # Preserve the local sensor selected by the original input listener where possible.
    local=listener(ns,'trackball_listener')
    require_enabled(local,'Local trackball listener')
    sensor=phandle(prop(local,'device'),'local trackball listener device')
    sensor_node=merged_for_label(ns,sensor)
    require_enabled(sensor_node,'Local PMW3610 sensor')
    if 'pmw3610' not in (prop(sensor_node,'compatible') or '').lower():
        raise PreflightError('Local listener device is not an explicitly identified PMW3610')
    scan_node=merged_for_label(ns,scan)
    require_enabled(scan_node,'Alternate-thumb scanner')
    if 'alt' not in (prop(scan_node,'compatible') or '').lower():
        raise PreflightError('Chosen scan is not the expected alternate-thumb wrapper; refusing to replace it')
    out=['/* AUTO-GENERATED from pinned sources; do not hand edit. */',
         '#include <physical_layouts.dtsi>', '#include <dt-bindings/zmk/matrix_transform.h>',
         f'&{transform} {{', '    rows = <7>;', '    map = <']
    for r in range(7):
        row=[f'RC({a},{b})' for a,b in POSITIONS if a==r]
        if row: out.append('        '+' '.join(row))
    out += ['    >;', '};', '/ {', '    chosen {',
            '        /delete-property/ zmk,matrix-transform;',
            '        zmk,physical-layout = &modu_layout;', '    };',
            '    modu_hw_info: modu_hw_info {', '        compatible = "modu,hardware";',
            f'        side = <{0 if side=="left" else 1}>;',f'        sensor = <&{sensor}>;', '    };',
            '    modu_layout: modu_layout {','        compatible = "zmk,physical-layout";',
            '        display-name = "MODU-C Compact 71 - L/R trackballs";',
            f'        transform = <&{transform}>;', f'        kscan = <&{scan}>;', '        keys =']
    for i,p in enumerate(layout):
        vals=[round(p.get('w',1)*100),round(p.get('h',1)*100),round(p['x']*100),round(p['y']*100),0,0,0]
        out.append('            <&key_physical_attrs '+' '.join(str(v) if v>=0 else f'({v})' for v in vals)+('>;' if i==len(layout)-1 else '>,'))
    out+=['    };','};']
    listeners=[]
    if side=='left':
        for s,name in enumerate(('trackball_listener','peripheral_trackball_listener')):
            n=listener(ns,name)
            require_enabled(n,name)
            input_device=phandle(prop(n,'device'),name+' input device')
            if s==1 and input_device==sensor:
                raise PreflightError('Right input listener points at the left local sensor')
            # Layer override children could bypass the root processors. Never silently ignore that.
            if re.search(r'\blayers\s*=',n['body']):
                raise PreflightError(f'{name} has layer overrides: explicit integration review required')
            chain=prop(n,'input-processors')
            ref='&'+n['label'] if n['label'] else '&{/'+n['name']+'}'
            addition=f'<&modu_tb {s}>'
            # Both <&a>, <&b> and <&a &b> are valid phandle-array syntax.
            value=(chain+', ' if chain else '')+addition
            out += [f'{ref} {{',f'    input-processors = {value};','};']
            listeners.append({'node':name,'device':input_device,'previous_chain':chain,'side':s})
    report={'side':side,'scan_wrapper':scan,'transform':transform,'local_sensor':sensor,
            'original_positions':67,'positions_with_virtual_directions':71,'listeners':listeners,
            'hardware_driver_modified':False,'gpio_modified':False}
    return '\n'.join(out)+'\n',report

def verify_commit(path: Path, expected: str):
    got=subprocess.check_output(['git','-C',str(path),'rev-parse','HEAD'],text=True).strip()
    if got!=expected: raise PreflightError(f'{path.name} must be pinned to {expected}; got {got}')

def finish_prepare(config: Path, workspace: Path, side: str, overlay_text: str, report: dict):
    """Check the pinned APIs and write the already-resolved hardware additions."""
    modu=workspace/'modu-c-firmware'; zmk=workspace/'zmk'; zephyr=workspace/'zephyr'
    driver=modu/'zmk-pmw3610-driver'
    header_texts={p:p.read_text(errors='replace') for p in driver.rglob('*.h')}
    required=('PMW3610_ALT_ATTR_CPI','PMW3610_SVALUE_TO_CPI')
    headers=[]
    for token in required:
        candidates=[p for p,t in header_texts.items() if token in t]
        if not candidates: raise PreflightError('Pinned sensor header API missing: '+token)
        headers.extend(candidates)
    headers=list(dict.fromkeys(headers))
    hci_headers=list((zephyr/'include/zephyr/bluetooth').glob('*.h'))
    hci='\n'.join(p.read_text(errors='replace') for p in hci_headers)
    if re.search(r'\bbt_hci_cmd_create\s*\(',hci):
        creation='#define MODU_HCI_CMD_CREATE(op, len) bt_hci_cmd_create(op, len)'
    elif re.search(r'\bbt_hci_cmd_alloc\s*\(',hci):
        creation='#define MODU_HCI_CMD_CREATE(op, len) bt_hci_cmd_alloc(K_FOREVER)'
    else: raise PreflightError('No supported HCI command buffer allocation API in pinned Zephyr')
    # Refuse the newer allocation API until it is known to encode opcode separately.
    # This package targets the original pinned Zephyr, which is expected to expose create().
    if 'bt_hci_cmd_create' not in creation:
        raise PreflightError('HCI API changed: bt_hci_cmd_create absent; review new API before building')
    behavior=(zmk/'app/include/drivers/behavior.h').read_text()
    for token in ('BEHAVIOR_LOCALITY_EVENT_SOURCE','parameter_metadata','behavior_parameter_metadata'):
        if token not in behavior:raise PreflightError('Pinned ZMK behavior API missing '+token)
    if side=='left':
        keymap_header=(zmk/'app/include/zmk/keymap.h').read_text()
        if 'zmk_keymap_check_unsaved_changes' not in keymap_header:
            raise PreflightError('Pinned keymap saved/draft check required by mode memory is absent')
        if 'zmk_keymap_get_layer_binding_at_idx' not in keymap_header:
            raise PreflightError('Pinned keymap getter required by Studio ball settings is absent')
        studio=(zmk/'app/src/studio/Kconfig').read_text()
        for token in ('ZMK_STUDIO_TRANSPORT_UART','ZMK_STUDIO_TRANSPORT_BLE','ZMK_STUDIO_LOCKING'):
            if not re.search(r'(?m)^\s*(?:menu)?config\s+'+token+r'\b',studio):
                raise PreflightError('Pinned Studio transport option absent: '+token)
    ip=(zmk/'app/include/drivers/input_processor.h').read_text()
    if 'zmk_input_processor_driver_api' not in ip: raise PreflightError('Pinned ZMK input processor API absent')
    generated=config/'config/generated';generated.mkdir(parents=True,exist_ok=True)
    (generated/'modu-hardware.dtsi').write_text(overlay_text)
    header='#pragma once\n'+''.join(f'#include "{p.resolve().as_posix()}"\n' for p in headers)+creation+'\n'
    (generated/'modu-upstream.h').write_text(header)
    report.update({'zmk_revision':ZMK_REV,'modu_revision':MODU_REV,
                   'sensor_headers':[str(p.relative_to(modu)) for p in headers]})
    (generated/'preflight.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':
    raise SystemExit('Use scripts/build_firmware.py: the production build requires the original Zephyr EDT. '
                     'The raw DTS resolver in this file is retained only for legacy fixture tests.')
