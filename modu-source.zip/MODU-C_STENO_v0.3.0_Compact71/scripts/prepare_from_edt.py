#!/usr/bin/env python3
"""Resolve MODU wiring from Zephyr's original, compiler-preprocessed device tree.

The production build does NOT use the legacy regex/flatten resolver. A cmake-only
configuration of the original keymap supplies edt.pickle, with real includes,
macros, conditionals, overrides, and disabled nodes already resolved by Zephyr.
This script adds a physical layout and CENTRAL-only processors; no sensor, GPIO,
axis orientation, polling, SPI, or alternate-thumb properties are overwritten.
"""
from __future__ import annotations
import hashlib
import json
from layout_contract import POSITIONS, POPULATED
from pathlib import Path
import pickle
import re
import sys
from prepare_build import (MODU_REV, ZMK_REV, ORIGINAL, PreflightError,
                           verify_commit, finish_prepare)
from check_integration import value, compatible, enabled, _ancestors, _descendants

ORIGINAL_KEYMAP_SHA256 = '3e26084afeee4af35f50f911b76c30802f0f3f0135ae88747bc97f7e3455d237'

def require(condition, message):
    if not condition:
        raise PreflightError(message)

def one(items, description):
    items = list(items)
    require(len(items) == 1, f'{description}: expected 1, found {len(items)}')
    return items[0]

def ref(node):
    require(node is not None and isinstance(node.path, str) and
            re.fullmatch(r'/[A-Za-z0-9_.,+@/\-]*', node.path) is not None,
            'Cannot safely reference original DTS node')
    return '&{' + node.path + '}'

def normalize(item):
    """Stable JSON form: compare node paths, not auto-assigned phandle integers."""
    if item is None or isinstance(item, (str, int, float, bool)):
        return item
    if isinstance(item, bytes):
        return {'bytes': item.hex()}
    if isinstance(item, (list, tuple)):
        return [normalize(x) for x in item]
    if isinstance(item, dict):
        return {str(k): normalize(v) for k, v in item.items()}
    if hasattr(item, 'controller') and hasattr(item, 'data'):
        return {'controller': item.controller.path, 'data': normalize(item.data)}
    if hasattr(item, 'path') and hasattr(item, 'props'):
        return {'node': item.path}
    raise PreflightError('Unexpected EDT property type: ' + type(item).__name__)

def snapshot(node, omit=()):
    # phandle values are allocation artifacts and can change when nodes are added.
    omitted = set(omit) | {'phandle', 'linux,phandle'}
    return {'path': node.path, 'status': node.status, 'compats': list(node.compats),
            'properties': {k: normalize(p.val) for k, p in node.props.items()
                           if k not in omitted}, 'omitted_properties': sorted(omitted)}

def load_edt(workspace: Path, build: Path):
    library = workspace / 'zephyr/scripts/dts/python-devicetree/src'
    require(library.is_dir(), 'Missing pinned Zephyr devicetree Python module')
    sys.path.insert(0, str(library.resolve()))
    # Only the pickle produced locally by the just-run Zephyr cmake is accepted.
    with (build / 'zephyr/edt.pickle').open('rb') as stream:
        return pickle.load(stream)

def check_baseline_config(text: str, side: str):
    active = set(re.findall(r'^(CONFIG_\w+)=y$', text, re.M))
    require('CONFIG_ZMK_SPLIT' in active, 'Original baseline is not a split build')
    require(('CONFIG_ZMK_SPLIT_ROLE_CENTRAL' in active) == (side == 'left'),
            'Original baseline role differs from the requested side')
    require('CONFIG_MODU_CONTROL' not in active and 'CONFIG_ZMK_STUDIO' not in active,
            'Original baseline must not contain the MODU extension or Studio')

def original_keymap(root: Path) -> bytes:
    data = (root / 'docs/original-modu.keymap.txt').read_bytes()
    require(hashlib.sha256(data).hexdigest() == ORIGINAL_KEYMAP_SHA256,
            'Original baseline keymap was changed; refusing a misleading comparison')
    return data

def resolve_edt(edt, side: str, layout: list[dict]):
    require(side in ('left', 'right'), 'Unknown side')
    all_nodes = list(edt.nodes)
    transform = edt.chosen_node('zmk,matrix-transform')
    scan = edt.chosen_node('zmk,kscan')
    require(enabled(transform) and compatible(transform, 'zmk,matrix-transform'),
            'Original chosen matrix transform is missing')
    require(enabled(scan) and any('alt' in c for c in scan.compats),
            'Original alternate-thumb scanner is missing')
    actual = value(transform, 'map')
    require(actual == [(r << 8) | c for r, c in ORIGINAL],
            'Original compiled transform differs from the uploaded 67 positions')
    require(value(transform, 'rows') == 6 and value(transform, 'columns', 0) >= 12,
            'Unexpected original transform dimensions')
    require([(p['row'], p['col']) for p in layout] == POSITIONS,
            'Studio layout changed original input positions')
    require(not any(compatible(n, 'modu,hardware') for n in all_nodes),
            'Baseline already contains extension nodes')
    listeners = []
    split = None
    if side == 'left':
        for name in ('trackball_listener', 'peripheral_trackball_listener'):
            listener = one((n for n in all_nodes if n.path == '/' + name), name)
            require(enabled(listener) and compatible(listener, 'zmk,input-listener'),
                    'Original central input listener disabled: ' + name)
            device = value(listener, 'device')
            require(enabled(device), 'Original input device disabled/missing: ' + name)
            for child in _descendants(listener):
                require(not enabled(child) or 'layers' not in child.props,
                        'Original listener has layer overrides needing review: ' + child.path)
            listeners.append(listener)
        sensor = value(listeners[0], 'device')
        split = value(listeners[1], 'device')
        require(split is not sensor and compatible(split, 'zmk,input-split'),
                'Original right input does not use a distinct split receiver')
    else:
        # The peripheral's local HID listener may be disabled or absent. Its
        # actual transmitter (not that listener) is the authoritative route.
        candidates = [n for n in all_nodes
                      if enabled(n) and compatible(n, 'zmk,input-split')
                      and enabled(value(n, 'device'))
                      and any('pmw3610' in c.lower() for c in value(n, 'device').compats)]
        split = one(candidates, 'Original right PMW3610 split sender')
        sensor = value(split, 'device')
    require(enabled(sensor) and any('pmw3610' in c.lower() for c in sensor.compats),
            'Original local device is not an enabled PMW3610 sensor')
    for parent in _ancestors(sensor):
        require(enabled(parent), 'Original sensor parent disabled: ' + parent.path)

    text = ['/* Generated from original Zephyr EDT. Sensor/scan/axis properties are NOT changed. */',
            '#include <physical_layouts.dtsi>', '#include <dt-bindings/zmk/matrix_transform.h>',
            f'{ref(transform)} {{', '    rows = <7>;', '    map = <']
    positions = POSITIONS
    for row in range(7):
        text.append('        ' + ' '.join(f'RC({r},{c})' for r, c in positions if r == row))
    text += ['    >;', '};', '/ {', '    chosen {',
             '        /delete-property/ zmk,matrix-transform;',
             '        zmk,physical-layout = &modu_layout;', '    };',
             '    modu_hw_info: modu_hw_info {', '        compatible = "modu,hardware";',
             f'        side = <{0 if side == "left" else 1}>;',
             f'        sensor = <{ref(sensor)}>;', '    };',
             '    modu_layout: modu_layout {', '        compatible = "zmk,physical-layout";',
             '        display-name = "MODU-C Compact 71 - L/R trackballs";',
             f'        transform = <{ref(transform)}>;', f'        kscan = <{ref(scan)}>;',
             '        keys =']
    for i, key in enumerate(layout):
        attrs = [round(key.get('w', 1) * 100), round(key.get('h', 1) * 100),
                 round(key['x'] * 100), round(key['y'] * 100), 0, 0, 0]
        text.append('            <&key_physical_attrs ' + ' '.join(
            str(v) if v >= 0 else f'({v})' for v in attrs) +
                    ('>;' if i == len(layout) - 1 else '>,'))
    text += ['    };', '};']
    listener_report = []
    for index, listener in enumerate(listeners):
        chain = value(listener, 'input-processors', [])
        expressions = []
        for entry in chain:
            require(enabled(entry.controller), 'Original input processor disabled')
            require(not any('code-mapper' in c or 'behavior' in c or 'modu,trackball' in c
                            for c in entry.controller.compats),
                    'Preceding processor needs explicit XY review: ' + entry.controller.path)
            args = list(entry.data.values())
            require(all(type(x) is int and 0 <= x <= 0xffffffff for x in args),
                    'Unsupported original processor argument')
            expressions.append('<' + ref(entry.controller) + ''.join(' ' + str(x) for x in args) + '>')
        expressions.append(f'<&modu_tb {index}>')
        text += [ref(listener) + ' {', '    input-processors = ' + ', '.join(expressions) + ';', '};']
        listener_report.append({'node': listener.path, 'device': value(listener, 'device').path,
                                'previous_chain': normalize(chain), 'side': index})

    preserve = []
    seen = set()
    # Verify original sensor/bus/scanner/split properties after final compilation.
    # Listener chains are intentionally extended, but other listener properties are preserved.
    def keep(node, omit=()):
        if node is not None and node.path not in seen:
            seen.add(node.path)
            preserve.append(snapshot(node, omit))
    keep(sensor)
    for parent in _ancestors(sensor):
        if parent.path != '/':
            keep(parent)
    keep(scan)
    keep(split)
    for listener in listeners:
        keep(listener, ('input-processors',))
    report = {'resolution_method': 'original Zephyr cmake-only EDT (not source regex)',
              'side': side, 'scan_wrapper': scan.path, 'transform': transform.path,
              'local_sensor': sensor.path, 'split_device': split.path,
              'original_positions': 67, 'positions_with_virtual_directions': 71,
              'listeners': listener_report, 'preserved_nodes': preserve,
              'hardware_driver_modified': False, 'gpio_modified': False,
              'original_keymap_sha256': ORIGINAL_KEYMAP_SHA256}
    return '\n'.join(text) + '\n', report

def check_preserved_nodes(edt, baseline_report: dict):
    by_path = {n.path: n for n in edt.nodes}
    for original in baseline_report['preserved_nodes']:
        path = original['path']
        require(path in by_path, 'Final DTS lost original node: ' + path)
        current = snapshot(by_path[path], original['omitted_properties'])
        require(current == original, 'Final DTS changed original sensor/scan/split properties: ' + path)
    # All pre-existing processors must remain, in order, before the sole new processor.
    for old in baseline_report['listeners']:
        chain = value(by_path[old['node']], 'input-processors', [])
        require(normalize(chain[:-1]) == old['previous_chain'],
                'Final DTS changed original input processing chain: ' + old['node'])
    return {'original_sensor_scan_split_properties_preserved': True,
            'compared_nodes': [p['path'] for p in baseline_report['preserved_nodes']]}

def prepare(config: Path, workspace: Path, side: str, baseline_build: Path):
    verify_commit(workspace / 'modu-c-firmware', MODU_REV)
    verify_commit(workspace / 'zmk', ZMK_REV)
    original_keymap(config)
    check_baseline_config((baseline_build / 'zephyr/.config').read_text(), side)
    edt = load_edt(workspace, baseline_build)
    layout = json.loads((config / 'config/modu.json').read_text())['layouts']['default_transform']['layout']
    overlay_text, report = resolve_edt(edt, side, layout)
    # Save original routing even if a later ABI check rejects the extension.
    diagnostic = config / 'diagnostics' / side
    diagnostic.mkdir(parents=True, exist_ok=True)
    (diagnostic / 'original-hardware.json').write_text(json.dumps(report, indent=2) + '\n')
    finish_prepare(config, workspace, side, overlay_text, report)
