#!/usr/bin/env python3
"""CI-only checks on real compiler output; never substitute these for hardware tests."""
import argparse
import json
from pathlib import Path
import re
import sys
from check_integration import check_graph, check_studio_config, IntegrationError

def check_tx_power_config(cfg: str) -> None:
    """Reject a compiler result that silently drops the maximum-power default."""
    for option in ('CONFIG_BT_CTLR_TX_PWR_PLUS_8=y', 'CONFIG_BT_CTLR_TX_PWR_DBM=8'):
        if not re.search('^' + re.escape(option) + '$', cfg, re.M):
            raise SystemExit('Maximum TX default not effective in built .config: ' + option)

def check_steno_config(cfg: str) -> None:
    required = ('CONFIG_CORNIX_STENO=y', 'CONFIG_CORNIX_STENO_DICTIONARY=y',
                'CONFIG_CORNIX_STENO_MAX_POSITIONS=64',
                'CONFIG_CORNIX_STENO_KEYUP_CORRECTION_MS=0',
                'CONFIG_CORNIX_STENO_FINAL_ROLL_MS=90',
                'CONFIG_CORNIX_STENO_SOLO_CORRECTION_MS=500',
                'CONFIG_CORNIX_STENO_OUTPUT_QUEUE_SIZE=256')
    for option in required:
        if not re.search('^' + re.escape(option) + '$', cfg, re.M):
            raise SystemExit('STENO option absent or changed in compiler output: ' + option)
    if re.search(r'^CONFIG_CORNIX_STENO_LED=y$', cfg, re.M):
        raise SystemExit('Cornix-only LED hardware must not be enabled on MODU')

def check_steno_edt(edt) -> None:
    keymap = next((n for n in edt.nodes if 'zmk,keymap' in n.compats), None)
    if keymap is None:
        raise ValueError('Missing compiled STENO keymap')
    layers = [n for n in keymap.children.values() if n.status in ('okay','ok') and 'bindings' in n.props]
    if len(layers) != 9 or any(len(n.props['bindings'].val) != 71 for n in layers):
        raise ValueError('Compiled keymap must contain 9 layers x 71 positions')
    if layers[7].props.get('display-name') is None or layers[7].props['display-name'].val != 'STENO-KO':
        raise ValueError('STENO layer identity changed')

def main():
    p=argparse.ArgumentParser();p.add_argument('--build',type=Path,required=True)
    p.add_argument('--side',choices=('left','right'),required=True)
    p.add_argument('--zephyr-base',type=Path,required=True)
    p.add_argument('--baseline-report',type=Path,required=True);a=p.parse_args()
    cfg=(a.build/'zephyr/.config').read_text()
    for option in ('CONFIG_MODU_CONTROL=y','CONFIG_SETTINGS=y','CONFIG_SENSOR=y',
                   'CONFIG_ZMK_POINTING=y','CONFIG_BT_HCI_VS=y',
                   'CONFIG_BT_CTLR_TX_PWR_DYNAMIC_CONTROL=y'):
        if not re.search('^'+re.escape(option)+'$',cfg,re.M):raise SystemExit('Missing built option: '+option)
    check_tx_power_config(cfg)
    check_steno_config(cfg)
    try: check_studio_config(cfg,a.side)
    except IntegrationError as e: raise SystemExit('Studio configuration verification failed: '+str(e)) from e
    if a.side=='left':
        for option in ('CONFIG_ZMK_STUDIO=y','CONFIG_ZMK_SPLIT_ROLE_CENTRAL=y'):
            if option not in cfg:raise SystemExit('Missing built option: '+option)
    else:
        if re.search('^CONFIG_ZMK_STUDIO=y$',cfg,re.M):raise SystemExit('Studio incorrectly enabled on peripheral')
        if re.search('^CONFIG_ZMK_SPLIT_ROLE_CENTRAL=y$',cfg,re.M):raise SystemExit('Right shield incorrectly built as central')
    dts=(a.build/'zephyr/zephyr.dts').read_text()
    if not re.search(r'zmk,physical-layout\s*=',dts):raise SystemExit('Studio physical layout not selected')
    # All ELF PT_LOAD ranges that contain flash data must stay in the selected code
    # partition. Reject bootloader/UICR writes. Use compiler-produced DT data, not a
    # hardcoded flash offset from a different nRF board.
    import pickle
    # edt.pickle imports devicetree; use the checked-out Zephyr implementation, not a guessed pip version.
    dt_python=a.zephyr_base/'scripts/dts/python-devicetree/src'
    if not dt_python.is_dir():raise SystemExit('Zephyr devicetree Python module is missing: '+str(dt_python))
    sys.path.insert(0,str(dt_python.resolve()))
    try:
        with (a.build/'zephyr/edt.pickle').open('rb') as f:edt=pickle.load(f)
        report=check_graph(edt,a.side)
        check_steno_edt(edt)
        from prepare_from_edt import check_preserved_nodes
        baseline=json.loads(a.baseline_report.read_text())
        if baseline.get('side')!=a.side: raise ValueError('Baseline belongs to a different half')
        report.update(check_preserved_nodes(edt,baseline))
        (a.build/'modu-integration.json').write_text(json.dumps(report,indent=2)+'\n')
        code=edt.chosen_node('zephyr,code-partition')
        if code is None or len(code.regs)!=1:raise ValueError('No unique chosen code partition')
        lo=code.regs[0].addr;hi=lo+code.regs[0].size
        from elftools.elf.elffile import ELFFile
        with (a.build/'zephyr/zmk.elf').open('rb') as f:
            elf=ELFFile(f)
            for seg in elf.iter_segments():
                if seg['p_type']!='PT_LOAD' or not seg['p_filesz']:continue
                addr=seg['p_paddr'];end=addr+seg['p_filesz']
                # Data sections' LMA is also in flash. SRAM-only segments need no flash write.
                if 0x20000000<=addr<0x30000000:continue
                if not (lo<=addr and end<=hi):
                    raise ValueError(f'ELF load 0x{addr:x}..0x{end:x} outside code partition 0x{lo:x}..0x{hi:x}')
    except Exception as e:raise SystemExit('Integration/flash-range verification failed: '+str(e)) from e
    print(f'PASS: {a.side} compiler config, sensor/input/Studio wiring and ELF flash range. Hardware is NOT tested.')

if __name__=='__main__':main()
