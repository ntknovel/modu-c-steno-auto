"""v0.2.0 MODU compact topology. Persistent storage uses original slot IDs."""
REMOVED = tuple(range(51, 57))
OLD_TO_NEW = {i: (i if i < 51 else i - 6) for i in range(77) if i not in REMOVED}
NEW_TO_OLD = tuple(OLD_TO_NEW)
ORIGINAL = [(r,c) for r in range(5) for c in range(12)] + [(5,c) for c in (0,1,2,6,7,8,9)]
POPULATED = [p for i,p in enumerate(ORIGINAL) if i not in REMOVED]
POSITIONS = POPULATED + [(6,c) for c in range(10)]
DIRECTION_FIRST = 61
PROFILE_FIRST = 69
POSITION_COUNT = 71
