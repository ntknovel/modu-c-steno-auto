#!/usr/bin/env python3
"""Generate a self-contained source-derived layout preview. No device communication."""
from pathlib import Path
import json
import validate
ROOT=Path(__file__).resolve().parents[1]
TEMPLATE=r'''<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>MODU-C v0.3.0 — Cornix 속기 이식 배치</title>
<style>
:root{font-family:Arial,"Noto Sans CJK KR","Malgun Gothic",sans-serif;color:#203244;background:#f3f6fa;font-size:14px;line-height:1.6}
*{box-sizing:border-box}body{margin:0}main{max-width:1360px;margin:auto;padding:28px 24px 32px}.eyebrow{color:#527687;letter-spacing:.14em;font-size:11px;font-weight:bold}
h1{font-size:27px;line-height:1.3;margin:9px 0 8px;letter-spacing:-.03em}h2{font-size:18px;margin:0 0 12px}p{margin:6px 0 13px}.muted{color:#627486}.intro{max-width:1000px}.notice{background:#fff7e4;border:1px solid #e4ce92;padding:10px 15px;border-radius:9px;margin:17px 0}
.toolbar{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:20px 0 12px}.tabs{display:flex;gap:6px;flex-wrap:wrap}.tabs button{border:1px solid #d1dce4;background:white;padding:8px 16px;border-radius:7px;color:inherit;font:inherit;cursor:pointer}.tabs button.active{background:#204c5d;color:white;border-color:#204c5d}.pill{font-size:12px;color:#436170}.workspace{display:grid;grid-template-columns:minmax(0,1fr) 282px;gap:16px;align-items:start}.card{min-width:0;border:1px solid #dce4eb;background:white;border-radius:13px;box-shadow:0 3px 16px #24364706;padding:18px}.canvaswrap{overflow-x:auto;overflow-y:hidden}.keyboard{position:relative;margin:26px auto 0}.side-label{position:absolute;font-size:11px;letter-spacing:.15em;font-weight:bold;color:#8093a1}.key{position:absolute;background:#fafcfe;border:1px solid #ccd6df;border-bottom:3px solid #c4cfda;border-radius:7px;display:flex;align-items:center;justify-content:center;flex-direction:column;font:inherit;font-size:13px;color:#283b4d;cursor:pointer;gap:0;padding:5px;line-height:1.2;white-space:pre-line}.key:hover{background:#edf4f8;border-color:#4f899d}.key:focus-visible{outline:3px solid #67a8c0;outline-offset:2px}.key small{position:absolute;top:5px;right:5px;font-size:8px;color:#93a2af}.key.extra{background:#fff2df;border-color:#d59741}.key.extra:after{content:"추가 B";font-size:8px;color:#92621f;margin-top:3px}.key.cycle{background:#e0f3ee;border-color:#5b9e8b}.key.boot{background:#fff0ee;border-color:#c59085}.key.virtual{background:#f4f6fc;border-color:#c5cee4}.key.placeholder{opacity:.5;padding:0;border:1px solid #d8e2e9;background:#f8fafc;border-radius:2px}.mode-setting{border-radius:7px;background:#e8f2f7;border:2px solid #5796b0;gap:3px}.mode-setting.right{background:#f0ebf7;border-color:#9a85b8}.mode-setting .caption{font-size:9px;font-weight:bold;letter-spacing:.03em}.mode-setting .mode{font-size:12px;font-weight:bold}.mode-setting .tag{font-size:8px;opacity:.59}.mode-setting.transparent{background:#fafcfe;color:#607486}.sub-group-label{font-size:12px;letter-spacing:0;font-weight:bold}.key.virtual{font-size:20px}select:disabled{color:#748594;background:#eff3f6;cursor:not-allowed}.selected{outline:3px solid #86b5c8;outline-offset:3px}.detail{font-size:13px}.detail code{display:block;background:#f1f4f8;padding:9px;border-radius:6px;font-size:11px;white-space:pre-wrap;word-break:break-all;margin:10px 0}.detail label{display:block;margin:12px 0 6px;font-weight:bold}select{width:100%;border:1px solid #becdd8;border-radius:6px;padding:9px;font:inherit;background:white;color:inherit}.info{padding:10px 12px;background:#edf4f8;border-radius:8px;font-size:12px;margin-top:14px}.sub{font-size:11px;color:#66798a;margin-top:8px}.divider{border:0;border-top:1px solid #e3e9ef;margin:18px 0}.legend{display:flex;gap:18px;flex-wrap:wrap;font-size:11px;color:#607587;margin-top:5px}.dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:5px;background:#d79b49}.dot.c{background:#69a38f}.footer{font-size:12px;color:#64788a;margin-top:14px}.demo{display:flex;gap:6px}.demo button{border:1px solid #bad1d7;background:#f3f9fa;border-radius:6px;padding:8px;cursor:pointer;flex:1;color:#285364}.demo-status{font-size:12px;margin:8px 0}.raw-title{font-size:11px;color:#738698}
@media(max-width:1060px){.workspace{grid-template-columns:1fr}.detail{max-width:100%}.toolbar{flex-wrap:wrap}main{padding:18px 12px}.keyboard{margin-left:0}.card{padding:12px}}
</style><main>
<div class="eyebrow">MODU-C / v0.3.0 / SOURCE-DERIVED PREVIEW</div>
<h1>MODU-C × Cornix 속기</h1>
<p class="intro muted">오른쪽 추가 B는 <b>일반 ↔ 속기</b> 전환키입니다. Cornix v2.2.6의 자음·모음·약어 규칙을 유지하고 숫자줄을 추가했습니다. 아래 레이어 탭과 키를 눌러 기본 배정을 확인하세요. 트랙볼 위치와 설정 기능은 유지합니다.</p>
<div class="notice"><b>연결 없는 미리보기입니다.</b> 실제 Studio 스크린샷이나 USB 설정 도구가 아닙니다. 사각형과 십자 좌표는 펌웨어의 기본 Studio용 레이아웃입니다. 확장 설치나 이 HTML 실행은 실제 설정에 필요하지 않습니다. 색상·한글 패널은 안내용입니다.</div>
<div class="toolbar"><div class="tabs"><button data-layer="0" class="active">일반</button><button data-layer="7">속기</button><button data-layer="1">Num</button><button data-layer="3">Mouse</button><button data-layer="4">Nav</button><button data-layer="5">Fn·BT</button><button data-layer="6">기호</button><button data-layer="2">트랙볼 제어</button><button data-layer="8">선택 이동</button></div><span class="pill">71 논리 위치 · 방향 8 + 볼 설정 2 · RF 기본 +8 dBm 유지</span></div>
<div class="workspace"><section class="card"><div class="canvaswrap"><div class="keyboard" id="keyboard"></div></div><div class="legend"><span><i class="dot"></i>추가 B: N 바로 왼쪽</span><span><i class="dot c"></i>제어 레이어의 좌우 순환키</span><span>빈 자리 6개 제거 · 71위치</span></div></section>
<aside class="card detail"><div id="details"></div><hr class="divider"><h2>순환키 동작 예시</h2><div class="demo"><button id="demo-left">왼쪽 ↻</button><button id="demo-right">오른쪽 ↻</button></div><div id="demo-status" class="demo-status"></div><p class="sub">이 예시는 브라우저 안에서만 바뀝니다. 일반 모드에서 왼쪽 바깥 엄지(Win/Num)를 홀드 → 왼쪽 Ctrl도 홀드 → 원래 LANG1(왼쪽) 또는 Enter(오른쪽) 위치입니다.</p></aside></div>
<p class="footer">숫자줄: 기호키+1~0 → !@#$%^&*(), 겹모키+1~0 → F1~F10. 겹모키+Bspc/Tab → F11/F12. Esc 위치는 기본 ~ / 기호+` / 겹모+Esc. 기호·겹모를 동시에 누르면 Fn 우선. 공통 조건: 기본 모드는 원래 Base 레이어에서 편집합니다. 순환키는 실행 모드를 바꾸며 중앙 칸의 기준값을 실시간 상태로 갱신하지 않습니다. 실제 장치 적용·저장은 펌웨어 설치 후 공식 Studio에서 확인해야 합니다.</p>
</main><script>
const DATA=__DATA__;const unit=62;let layer=0,selected=69;let profiles=[0,0],manual=[null,null];
const modes=['Mouse','Wheel','Arrows','Disabled','Follow keys'];
const profileTokens=['MC_MOUSE','MC_SCROLL','MC_ARROWS','MC_OFF','MC_PROFILE_KEYS'];
const simple={ESC:'Esc',TAB:'Tab',CAPS:'Caps',LSHFT:'L Shift',LCTRL:'L Ctrl',LALT:'L Alt',LGUI:'L Win',RALT:'R Alt',RCTRL:'R Ctrl',SEMI:';',COMMA:',',DOT:'.',FSLH:'/',BACKSPACE:'Bksp',BSPC:'Bksp',RET:'Enter',ENTER:'Enter',SPACE:'Space',PG_UP:'PgUp',PG_DN:'PgDn',HOME:'Home',END:'End',UP:'↑',DOWN:'↓',LEFT:'←',RIGHT:'→'};
const shortMode={MC_MOUSE:'Mouse',MC_SCROLL:'Wheel',MC_ARROWS:'Arrows',MC_OFF:'Off'};
const STENO_LABELS={"&kp CAPSLOCK":"Caps","&kp LSHIFT":"L Shift","&kp RSHIFT":"R Shift","&ht200 LC(Y) LBKT":"[ / Ctrl+Y","&ht200 RCTRL RBKT":"] / RCtrl","&lt250 FN K_APP":"Menu / Fn","&st_i_b": "초ㅂ", "&st_i_j": "초ㅈ", "&st_i_d": "초ㄷ", "&st_i_g": "초ㄱ", "&st_i_s": "초ㅅ", "&st_i_m": "초ㅁ", "&st_i_n": "초ㄴ", "&st_i_ng": "초ㅇ", "&st_i_r": "초ㄹ", "&st_i_h": "초ㅎ", "&st_i_kh": "초ㅋ", "&st_i_t": "초ㅌ", "&st_i_ch": "초ㅊ", "&st_i_p": "초ㅍ", "&st_i_double": "쌍초", "&st_f_b": "종ㅂ", "&st_f_j": "종ㅈ", "&st_f_d": "종ㄷ", "&st_f_g": "종ㄱ", "&st_f_s": "종ㅅ", "&st_f_m": "종ㅁ", "&st_f_n": "종ㄴ", "&st_f_ng": "종ㅇ", "&st_f_r": "종ㄹ", "&st_f_h": "종ㅎ", "&st_f_kh": "종ㅋ", "&st_f_t": "종ㅌ", "&st_f_ch": "종ㅊ", "&st_f_p": "종ㅍ", "&st_f_double": "쌍종", "&st_v_o": "ㅗ", "&st_v_eu": "ㅡ", "&st_vu_enter": "ㅜ / Enter", "&st_veo_space": "ㅓ / Space", "&st_v_i": "ㅣ", "&st_v_a": "ㅏ", "&st_mode": "일반 ↔ 속기", "&st_lang_return": "한/영·복귀", "&st_abbr_l": "약어 L", "&st_abbr_r": "약어 R", "&st_vext_l": "겹모 L / Fn", "&st_vext_r": "겹모 R / Fn", "&st_symbol_l": "기호 L", "&st_symbol_r": "기호 R", "&select_shift": "Shift 선택", "&mxesc": "~ / ` / Esc", "&mxbsp": "Bksp / F11", "&mxtab": "Tab / F12", "&lang_ht RCTRL 0": "한/영 / RCtrl", "&kp LC(A)": "Ctrl+A", "&lt250 NUM LGUI": "Win / Num", "&lt250 MOUSE MINUS": "− / Mouse", "&lt250 NAV EQUAL": "= / Nav", "&lt250 FN K_MENU": "Menu / Fn", "&ht150 LC(Y) LBKT": "[ / Ctrl+Y", "&ht150 RCTRL RBKT": "] / RCtrl", "&ht300 SQT DQT": "\" / '", "&ht200 FSLH QUESTION": "? / /", "&mx0": "0", "&mx1": "1", "&mx2": "2", "&mx3": "3", "&mx4": "4", "&mx5": "5", "&mx6": "6", "&mx7": "7", "&mx8": "8", "&mx9": "9"};
function label(binding){if(STENO_LABELS[binding])return STENO_LABELS[binding];const t=binding.split(/\s+/);if(t[0]==='&kp'){let k=t[1];return simple[k]||k.replace(/^KP_/,'KP ').replace(/^N([0-9])$/,'$1');}if(t[0]==='&trans')return '▽';if(t[0]==='&none')return '';if(t[0]==='&mo')return 'Fn '+t[1];if(t[0]==='&bootloader')return 'Boot';if(t[0]==='&studio_unlock')return 'Studio\nUnlock';if(t[0]==='&out')return 'USB';if(t[0]==='&modu_sync')return 'CPI\nSync';if(t[0]==='&bt')return t[1]==='BT_CLR'?'BT Clear':'BT '+t[2];if(t[0]==='&mkp')return ({MCLK:'Middle',RCLK:'R Click',LCLK:'L Click'})[t[1]]||t[1];let m=t[0].match(/^&([lrb])(mode|hold|cpi|ptr|scroll|rate|arrow|reset|tx|cycle)$/);if(m){let s=m[1].toUpperCase(),k=m[2],v=t[1];if(k==='cycle')return s+' ↻\nMode';if(k==='reset')return s+' Reset';if(k==='mode'||k==='hold')return s+(k==='hold'?' Hold':'')+'\n'+shortMode[v];let name={cpi:'CPI',ptr:'Speed',scroll:'Wheel',rate:'Rate',arrow:'Steps',reset:'Reset',tx:'RF'}[k];return s+' '+name+'\n'+({MC_INC:'+',MC_DEC:'−',MC_RESET:'Reset',MC_MAX:'Max'})[v];}return binding.replace(/^&/,'');}
function selectKey(i){selected=i;render();}
function render(){
  const root=document.querySelector('#keyboard');root.replaceChildren();
  root.style.width=Math.max(...DATA.layout.map(p=>p.x+(p.w||1)))*unit+'px';
  root.style.height=(Math.max(...DATA.layout.map(p=>p.y+(p.h||1)))+.35)*unit+'px';
  for(const [text,x,y] of [['LEFT',0,-.35],['RIGHT',8,-.35],['왼쪽\n트랙볼',DATA.layout[63].x,DATA.layout[61].y+.18],['오른쪽\n트랙볼',DATA.layout[68].x,DATA.layout[65].y+.18]]){
    const a=document.createElement('div');a.className='side-label'+(y>0?' sub-group-label':'');
    a.textContent=text;a.style.left=x*unit+'px';a.style.top=y*unit+'px';if(y>0){a.style.width=unit-5+'px';a.style.whiteSpace='pre-line';a.style.textAlign='center';a.style.lineHeight='1.4';a.style.fontSize='11px';}root.append(a);
  }
  DATA.layout.forEach((p,i)=>{
    const b=document.createElement('button');b.id='key-'+i;b.type='button';b.className='key';
    const binding=DATA.layers[layer][i];
    if(i===60)b.classList.add('extra');
    if(i>=61&&i<69)b.classList.add('virtual');
    if(layer===2&&(i===54||i===58))b.classList.add('cycle');
    if(layer===2&&(i===5||i===6))b.classList.add('boot');
    b.style.left=p.x*unit+'px';b.style.top=p.y*unit+'px';
    b.style.width=(p.w||1)*unit-5+'px';b.style.height=(p.h||1)*unit-5+'px';
    b.title='#'+i+' '+binding;b.setAttribute('aria-label',i>=69?(i===69?'왼쪽':'오른쪽')+' 트랙볼 모드 설정':('#'+i+' '+label(binding)));
    b.onclick=()=>selectKey(i);
    if(i>=69){
      b.classList.add('mode-setting');if(i===70)b.classList.add('right');
      if(layer!==0)b.classList.add('transparent');
      const display=layer===0?modes[profiles[i-69]]:'▽';
      for(const [c,text] of [['caption',i===69?'L 모드':'R 모드'],['mode',display]]){
        const span=document.createElement('span');span.className=c;span.textContent=text;b.append(span);
      }
    }else{
      b.textContent=label(binding);
      if(true){const small=document.createElement('small');small.textContent=i;b.append(small);}
    }
    if(i===selected)b.classList.add('selected');root.append(b);
  });
  document.querySelectorAll('[data-layer]').forEach(b=>b.classList.toggle('active',Number(b.dataset.layer)===layer));
  renderDetails();renderStatus();
}
function renderDetails(){
  const d=document.querySelector('#details');d.replaceChildren();
  const title=document.createElement('h2');title.textContent=selected>=69?(selected===69?'왼쪽':'오른쪽')+' 트랙볼 모드':'선택한 키 #'+selected;d.append(title);
  const raw=document.createElement('code');raw.textContent=DATA.layers[layer][selected];
  if(selected>=69&&layer===0){raw.textContent=(selected===69?'&lball ':'&rball ')+profileTokens[profiles[selected-69]];}
  d.append(raw);
  if(selected>=69){
    const text=document.createElement('p');text.textContent='중앙 칸은 실제 볼의 클릭 버튼이 아닌 설정 자리입니다. 기본 Studio에서 Base → 해당 Ball setting의 값 선택 → Save를 사용합니다.';d.append(text);
    const label=document.createElement('label');label.htmlFor='profile-choice';label.textContent='미리보기 기준 모드';d.append(label);
    const select=document.createElement('select');select.id='profile-choice';select.disabled=layer!==0;
    modes.forEach((m,i)=>{const o=document.createElement('option');o.value=i;o.textContent=m;o.selected=i===profiles[selected-69];select.append(o);});
    select.onchange=()=>{const side=selected-69,next=Number(select.value);if(next!==profiles[side]){profiles[side]=next;manual[side]=null;}render();};d.append(select);
    const inf=document.createElement('div');inf.className='info';
    inf.textContent=layer===0?'확장 없이 기본 Studio에서 이 칸을 선택·편집합니다. 별도 앱은 필요하지 않습니다. 이 HTML의 선택은 설명용 예시이며 기기에 전달되지 않습니다.':'모드 설정은 원래 Base 레이어에서 편집합니다. 다른 레이어의 중앙 칸은 투명(▽)으로 유지하세요.';d.append(inf);
  }else{
    const text=document.createElement('p');
    text.textContent=selected>=61?'트랙볼 방향키 모드에서 입력할 키입니다. 기본 배정은 화살표이고, Studio에서 WASD 등으로 바꿀 수 있도록 구성했습니다.':selected===60?'추가 B는 새 논리 번호 60으로, N 바로 왼쪽입니다. 이 키는 일반/속기 전환입니다. 왼쪽 B는 일반 B / 속기 쌍초입니다.':(selected===54||selected===58)?'제어 레이어에서는 좌우 모드 순환키입니다. 일반 모드의 이 엄지 위치는 Cornix 배정이며, 속기 모드에서는 모음입니다.':'표시값은 소스 기본 배정입니다. 기기에 저장된 Studio 배정은 다를 수 있습니다.';
    d.append(text);
  }
}
function renderStatus(){document.querySelector('#demo-status').textContent=['왼쪽','오른쪽'].map((name,s)=>name+': '+modes[manual[s]??(profiles[s]===4?0:profiles[s])]).join(' / ');}
function cycle(s){const old=manual[s]??(profiles[s]===4?0:profiles[s]);manual[s]=old===3?0:(old+1)%3;renderStatus();}
document.querySelectorAll('[data-layer]').forEach(b=>b.onclick=()=>{layer=Number(b.dataset.layer);render();});document.querySelector('#demo-left').onclick=()=>cycle(0);document.querySelector('#demo-right').onclick=()=>cycle(1);render();
</script></html>'''

def main():
    data={'layout':json.loads((ROOT/'config/modu.json').read_text())['layouts']['default_transform']['layout'],
          'layers':validate.bindings_with_parameters((ROOT/'config/modu.keymap').read_text())}
    if len(data['layout'])!=71 or any(len(x)!=71 for x in data['layers']):raise ValueError('expected 71 positions')
    output=TEMPLATE.replace('__DATA__',json.dumps(data,ensure_ascii=False).replace('</','<\\/'))
    (ROOT/'STUDIO_LAYOUT_PREVIEW_KO.html').write_text(output,encoding='utf-8')
    print('Generated source-derived STUDIO_LAYOUT_PREVIEW_KO.html (71 positions).')
if __name__=='__main__':main()
