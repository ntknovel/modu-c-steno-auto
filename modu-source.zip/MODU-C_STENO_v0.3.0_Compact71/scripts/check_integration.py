#!/usr/bin/env python3
"""Inspect compiler-produced EDT wiring; unit tests use explicitly synthetic EDT objects.

No physical sensor, USB host or radio is exercised by this checker.
"""
from __future__ import annotations
from layout_contract import POSITIONS, POPULATED
import re

class IntegrationError(ValueError):
    pass

def require(condition, message):
    if not condition:
        raise IntegrationError(message)

def value(node, prop, default=None):
    item=node.props.get(prop)
    return default if item is None else item.val

def compatible(node, name):
    return node is not None and name in node.compats

def enabled(node):
    return node is not None and node.status in ('okay', 'ok')

def exactly(nodes, message):
    nodes=list(nodes)
    require(len(nodes)==1, message+f' (found {len(nodes)})')
    return nodes[0]

def check_studio_config(cfg: str, side: str) -> None:
    require(side in ('left','right'), 'Unknown keyboard side')
    active=set(re.findall(r'^(CONFIG_\w+)=y$', cfg, re.M))
    if side=='left':
        for flag in ('CONFIG_ZMK_STUDIO','CONFIG_ZMK_STUDIO_RPC',
                     'CONFIG_ZMK_STUDIO_TRANSPORT_UART','CONFIG_ZMK_BEHAVIOR_METADATA',
                     'CONFIG_ZMK_KEYMAP_SETTINGS_STORAGE','CONFIG_ZMK_SPLIT_ROLE_CENTRAL'):
            require(flag in active, 'Required USB Studio option not active: '+flag)
        require('CONFIG_ZMK_STUDIO_LOCKING' not in active,
                'Studio locking is enabled; this build must not require an unlock key')
        require(re.search(r'^# CONFIG_ZMK_STUDIO_LOCKING is not set$', cfg, re.M) is not None,
                'Explicit compiler evidence for Studio locking disabled is missing')
        require('CONFIG_ZMK_STUDIO_TRANSPORT_BLE' not in active,
                'Studio GATT is enabled; this package requires USB-only Studio')
    else:
        for flag in ('CONFIG_ZMK_STUDIO','CONFIG_ZMK_STUDIO_RPC','CONFIG_ZMK_SPLIT_ROLE_CENTRAL'):
            require(flag not in active, 'Unexpected peripheral option: '+flag)

def check_graph(edt, side: str) -> dict:
    require(side in ('left','right'), 'Unknown keyboard side')
    all_nodes=list(edt.nodes)
    layout=edt.chosen_node('zmk,physical-layout')
    require(enabled(layout) and compatible(layout,'zmk,physical-layout'), 'No enabled selected physical layout')
    require(edt.chosen_node('zmk,matrix-transform') is None, 'Legacy chosen transform overrides Studio layout')
    keys=value(layout,'keys',[])
    require(len(keys)==71, 'Studio needs exactly 71 logical positions')
    transform=value(layout,'transform')
    require(enabled(transform) and compatible(transform,'zmk,matrix-transform'), 'Missing layout transform')
    expected=[(r<<8)|c for r,c in POSITIONS]
    require(value(transform,'map')==expected, 'Compiled transform changes original positions or virtual directions')
    require(value(transform,'rows')==7 and value(transform,'columns',0)>=12, 'Transform dimensions do not cover every key')
    scan=value(layout,'kscan')
    require(enabled(scan) and any('alt' in c for c in scan.compats), 'Original alternate-thumb scanner not retained')
    chosen_scan=edt.chosen_node('zmk,kscan')
    require(chosen_scan is None or chosen_scan is scan, 'Chosen scanner differs from physical layout scanner')
    hw=exactly((n for n in all_nodes if compatible(n,'modu,hardware') and enabled(n)), 'Missing local hardware descriptor')
    require(value(hw,'side')==(0 if side=='left' else 1), 'Hardware side does not match build side')
    sensor=value(hw,'sensor')
    require(enabled(sensor) and any('pmw3610' in c.lower() for c in sensor.compats), 'Local sensor is not enabled PMW3610')
    for parent in _ancestors(sensor):
        require(enabled(parent), 'A sensor bus/parent is disabled: '+parent.path)
    transport=exactly((n for n in all_nodes if compatible(n,'modu,hardware-command') and enabled(n)),
                      'Internal CPI/TX command behavior is missing or duplicated')
    require(transport.path.rsplit('/',1)[-1]=='modu_hw', 'Split command behavior name must be modu_hw')
    report={'side':side,'layout':layout.path,'positions':len(keys),'scan':scan.path,
            'sensor':sensor.path,'hardware_command':transport.path,'listeners':[]}
    if side=='left':
        own=exactly((n for n in all_nodes if compatible(n,'modu,trackball-processor') and enabled(n)),
                    'Missing or duplicated central trackball processor')
        devices=[]
        for index,name in enumerate(('trackball_listener','peripheral_trackball_listener')):
            listener=exactly((n for n in all_nodes if n.path=='/'+name), 'Missing '+name)
            require(enabled(listener) and compatible(listener,'zmk,input-listener'), 'Inactive '+name)
            device=value(listener,'device')
            require(enabled(device), 'Listener device missing or disabled: '+name)
            devices.append(device)
            for child in _descendants(listener):
                require(not enabled(child) or 'layers' not in child.props, 'Layer override bypasses MODU processor: '+child.path)
            chain=value(listener,'input-processors',[])
            matches=[(i,x) for i,x in enumerate(chain) if x.controller is own]
            require(len(matches)==1 and matches[0][0]==len(chain)-1, 'MODU processor must appear once at end: '+name)
            require(list(matches[0][1].data.values())==[index], 'Incorrect left/right processor argument: '+name)
            # A preceding code mapper can consume/remap REL_X/Y before the mode controller.
            for entry in chain[:-1]:
                require(not any('code-mapper' in c or 'behavior' in c for c in entry.controller.compats),
                        'Preceding processor needs explicit XY review: '+entry.controller.path)
            report['listeners'].append({'listener':listener.path,'device':device.path,'processor_side':index})
        require(devices[0] is sensor, 'Left listener is not connected to the local CPI sensor')
        require(devices[1] is not sensor and compatible(devices[1],'zmk,input-split'),
                'Right listener must use a distinct split-input device')
        uart=edt.chosen_node('zmk,studio-rpc-uart')
        require(enabled(uart) and compatible(uart,'zephyr,cdc-acm-uart'), 'Studio UART is not USB CDC ACM')
        for parent in _ancestors(uart):
            require(enabled(parent), 'Studio USB parent is disabled: '+parent.path)
        report['studio_usb']=uart.path
    else:
        split=exactly((n for n in all_nodes if enabled(n) and compatible(n,'zmk,input-split') and value(n,'device') is sensor),
                      'Right PMW3610 sensor is not wired to exactly one split-input sender')
        for listener in all_nodes:
            if compatible(listener,'zmk,input-listener') or compatible(listener,'zmk,input-split'):
                for entry in value(listener,'input-processors',[]):
                    require(not compatible(entry.controller,'modu,trackball-processor'),
                            'Right-side conversion would duplicate central processing')
        report['split_sender']=split.path
    return report

def _ancestors(node):
    parent=getattr(node,'parent',None)
    while parent is not None:
        yield parent
        parent=getattr(parent,'parent',None)

def _descendants(node):
    for child in node.children.values():
        yield child
        yield from _descendants(child)
