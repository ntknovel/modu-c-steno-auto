#!/usr/bin/env python3
"""Compact71 STENO keymap storage: isolated namespace, stable slot numbering.
Exact pinned ZMK source patch, fail closed on any unknown upstream input.
No settings reset, copy/delete migration, or staged destructive flash operation.
"""
from pathlib import Path
import hashlib, json
PINNED_SHA = '1d75f2da62bf1e1b284db3ca2074c3fdc3077fbac7da4a6059e9fefa5e8c7b1b'
MARKER = '/* MODU_COMPACT_STORAGE_V1: stable legacy NVS addresses */'
HELPERS = r"""
/* MODU_COMPACT_STORAGE_V1: stable legacy NVS addresses */
BUILD_ASSERT(ZMK_KEYMAP_LEN == 71, "MODU compact storage requires 71 key positions");
static int modu_storage_from_compact(uint32_t pos) {
    return pos < 51 ? (int)pos : (int)(pos + 6);
}
static int modu_compact_from_storage(uint32_t pos) {
    if (pos >= 77 || (pos >= 51 && pos <= 56)) { return -1; }
    return pos < 51 ? (int)pos : (int)(pos - 6);
}
"""
def once(text, before, after):
    if text.count(before) != 1:
        raise ValueError('Pinned keymap patch anchor differs: ' + before[:90])
    return text.replace(before, after, 1)

def transform_compact(text):
    # Original source must be exact; already patched file is checked byte-for-byte below.
    text = once(text, '#define LAYER_BINDING_SETTINGS_KEY "keymap/l/%d/%d"',
                '#define LAYER_BINDING_SETTINGS_KEY "keymap/l/%d/%d"\n' + HELPERS)
    text = once(text, 'LAYER_BINDING_SETTINGS_KEY, l, kp);',
                'LAYER_BINDING_SETTINGS_KEY, l, modu_storage_from_compact(kp));')
    text = once(text, 'LAYER_BINDING_SETTINGS_KEY, l, k);',
                'LAYER_BINDING_SETTINGS_KEY, l, modu_storage_from_compact(k));')
    text = once(text,
                '        WRITE_BIT((*state)[layer][key_position / 8], key_position % 8, 1);',
                """        int compact_pos = modu_compact_from_storage(key_position);
        if (compact_pos < 0 || layer >= ZMK_KEYMAP_LAYERS_LEN) { return 0; }
        key_position = (uint32_t)compact_pos;
        WRITE_BIT((*state)[layer][key_position / 8], key_position % 8, 1);""")
    text = once(text,
                '    uint8_t zmk_keymap_layer_changes[ZMK_KEYMAP_LAYERS_LEN][PENDING_ARRAY_SIZE];',
                '    uint8_t zmk_keymap_layer_changes[ZMK_KEYMAP_LAYERS_LEN][PENDING_ARRAY_SIZE] = {0};')
    text = once(text, '        if (len > sizeof(struct zmk_behavior_binding_setting)) {',
                """        int compact_pos = modu_compact_from_storage(key_position);
        if (compact_pos < 0) { return 0; } /* Removed placeholders have no key. */
        key_position = (uint32_t)compact_pos;

        if (len > sizeof(struct zmk_behavior_binding_setting)) {""")
    # Invalid stored names may not write outside the name array.
    text = once(text, '            LOG_WRN("Found layer name for invalid layer ID %d", layer);',
                '            LOG_WRN("Found layer name for invalid layer ID %d", layer);\n            return -EINVAL;')
    return text

STENO_NAMESPACE = 'modusteno1'
def transform(text):
    text = transform_compact(text)
    # Namespace all three setting keys and all read/reset registration paths.
    # Keep old ordinary-MODU NVS data untouched; never interpret it as STENO.
    text = text.replace('"keymap/', '"' + STENO_NAMESPACE + '/')
    text = text.replace('"keymap"', '"' + STENO_NAMESPACE + '"')
    return text

def apply(root, workspace):
    source = workspace/'zmk/app/src/keymap.c'
    original = (root/'tests/fixtures/pinned_keymap_641514.c').read_bytes()
    if hashlib.sha256(original).hexdigest() != PINNED_SHA:
        raise ValueError('Pinned keymap reference checksum differs')
    patched = transform(original.decode('utf-8')).encode('utf-8')
    current = source.read_bytes()
    legacy_compact = transform_compact(original.decode('utf-8')).encode('utf-8')
    if current not in (original, legacy_compact, patched):
        raise ValueError('Unknown ZMK keymap.c; refusing ambiguous saved-layout conversion')
    if current != patched:
        source.write_bytes(patched)
    return {'patch':'compact71-steno-namespace-v1', 'before_sha256':PINNED_SHA,
            'after_sha256':hashlib.sha256(patched).hexdigest(),
            'preserves_legacy_slot_addresses':True,'erases_settings':False,
            'keymap_namespace':STENO_NAMESPACE,'reads_old_normal_keymap':False}
