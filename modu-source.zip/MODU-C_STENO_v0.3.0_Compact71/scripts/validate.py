#!/usr/bin/env python3
"""Static checks for the modified wrapper. This is NOT a firmware compilation."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
ZMK_REVISION = "641514a97db345f499dd50b0360e594270f008fe"
MODU_REVISION = "bee0bb4b812f63f279eb67e928accc89600b5904"
BOARD = "ms88sf3/nrf52840"
from layout_contract import POSITIONS, NEW_TO_OLD, REMOVED
EXPECTED_COORDINATES = POSITIONS
PLACEHOLDER_INDICES = ()
REQUIRED_LICENSE_FILES = (
    "LICENSE",
    "NOTICE.md",
    "THIRD_PARTY_NOTICES.md",
    "LICENSES/MIT.txt",
    "LICENSES/MICROSOFT-UF2-MIT.txt",
    "LICENSES/ZMK-MIT.txt",
)


class DuplicateJsonKey(ValueError):
    """Raised when a JSON object repeats a key."""


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def _strict_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise DuplicateJsonKey(f"duplicate JSON key {key!r}")
        result[key] = value
    return result


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=_strict_object)
    except (OSError, json.JSONDecodeError, DuplicateJsonKey) as exc:
        fail(f"cannot parse {path.relative_to(ROOT)}: {exc}")


def check_metadata() -> None:
    generic = load_json(ROOT / "config/info.json")
    named = load_json(ROOT / "config/modu.json")
    if generic != named:
        fail("config/info.json and config/modu.json differ")
    if not isinstance(named, dict):
        fail("layout metadata root must be a JSON object")
    if named.get("id") != "modu" or named.get("name") != "MODU-C":
        fail("layout metadata must retain id='modu' and name='MODU-C'")
    if named.get("sensors") != []:
        fail("layout metadata sensors must be an empty array")

    try:
        layout = named["layouts"]["default_transform"]["layout"]
    except (KeyError, TypeError) as exc:
        fail(f"missing layout metadata key: {exc}")
    if not isinstance(layout, list):
        fail("default_transform.layout must be an array")

    coordinates: list[tuple[int, int]] = []
    for index, item in enumerate(layout):
        if not isinstance(item, dict):
            fail(f"layout item {index} is not an object")
        for key in ("row", "col"):
            if type(item.get(key)) is not int:
                fail(f"layout item {index} has a non-integer {key}")
        for key in ("x", "y"):
            value = item.get(key)
            if not isinstance(value, (int, float)) or isinstance(value, bool):
                fail(f"layout item {index} has a non-numeric {key}")
        for key in ("w", "h"):
            if key in item:
                value = item[key]
                if not isinstance(value, (int, float)) or isinstance(value, bool) or value <= 0:
                    fail(f"layout item {index} has an invalid {key}")
        coordinates.append((item["row"], item["col"]))

    if coordinates != EXPECTED_COORDINATES:
        fail("layout coordinate order must be 61 populated positions followed by 8 direction and 2 setting positions")
    if len(coordinates) != 71 or len(set(coordinates)) != 71:
        fail("layout must contain 71 unique matrix positions")

    if any((key["row"] == 4 and 3 <= key["col"] <= 8) for key in layout):
        fail("unused row-4 matrix slots must be omitted")


def check_trackball_cross(layout: list[dict[str, Any]]) -> None:
    """Screen geometry only: never reorder matrix/keymap positions to move a key."""
    if len(layout) != 71:
        fail("cross layout requires all 71 existing logical positions")
    for start, center_index in ((61, 69), (65, 70)):
        center = layout[center_index]
        offsets = ((0, -1), (0, 1), (-1, 0), (1, 0))  # Up, Down, Left, Right
        for index, dx, dy in [(center_index, 0, 0)] + [
            (start + offset, dx, dy) for offset, (dx, dy) in enumerate(offsets)
        ]:
            key = layout[index]
            if (key.get("w", 1), key.get("h", 1)) != (1, 1):
                fail(f"trackball position {index} must be a 1u square")
            if (key["x"], key["y"]) != (center["x"] + dx, center["y"] + dy):
                fail(f"trackball position {index} is not in the correct cross direction")
            if any(key.get(axis, 0) != 0 for axis in ("r", "rx", "ry")):
                fail(f"trackball position {index} must be unrotated")
    # Keep the crosses in the outer space below Ctrl/Alt, not below the thumb keys.
    # 49 = LAlt; 58 = RCtrl. Same logical positions, only x/y changes.
    for center_index, modifier_index in ((69, 49), (70, 52)):
        center, modifier = layout[center_index], layout[modifier_index]
        expected = (modifier["x"], modifier["y"] + modifier.get("h", 1) + 1)
        if (center["x"], center["y"]) != expected:
            fail(f"trackball center {center_index} must sit below its Alt/Ctrl group")
    # Repeated coordinates/overlap can make an ordinary Studio key unselectable.
    for i, a in enumerate(layout):
        for j, b in enumerate(layout[i + 1:], i + 1):
            if (min(a["x"] + a.get("w", 1), b["x"] + b.get("w", 1)) > max(a["x"], b["x"]) + 1e-6
                and min(a["y"] + a.get("h", 1), b["y"] + b.get("h", 1)) > max(a["y"], b["y"]) + 1e-6):
                fail(f"layout positions {i} and {j} overlap")


def _strip_comments(text: str) -> str:
    return re.sub(r"/\*.*?\*/|//[^\n]*", "", text, flags=re.DOTALL)


def _matching_brace(text: str, opening_index: int) -> int:
    depth = 0
    for index in range(opening_index, len(text)):
        if text[index] == "{":
            depth += 1
        elif text[index] == "}":
            depth -= 1
            if depth == 0:
                return index
    fail("unbalanced braces in config/modu.keymap")
    raise AssertionError("unreachable")


def _keymap_layers(text: str) -> list[tuple[str, list[str]]]:
    stripped = _strip_comments(text)
    match = re.search(r"\bkeymap\s*\{", stripped)
    if not match:
        fail("config/modu.keymap has no keymap node")
    opening = stripped.find("{", match.start())
    body = stripped[opening + 1 : _matching_brace(stripped, opening)]

    layers: list[tuple[str, list[str]]] = []
    node_pattern = re.compile(
        r"(?:[A-Za-z_][A-Za-z0-9_]*\s*:\s*)?"
        r"([A-Za-z_][A-Za-z0-9_,@-]*)\s*\{"
    )
    position = 0
    while True:
        node_match = node_pattern.search(body, position)
        if not node_match:
            break
        node_opening = body.find("{", node_match.start())
        node_closing = _matching_brace(body, node_opening)
        node_body = body[node_opening + 1 : node_closing]
        binding_match = re.search(r"\bbindings\s*=\s*<(.*?)>\s*;", node_body, re.DOTALL)
        if binding_match:
            behavior_names = re.findall(
                r"(?<![A-Za-z0-9_])&([A-Za-z_][A-Za-z0-9_]*)",
                binding_match.group(1),
            )
            layers.append((node_match.group(1), behavior_names))
        position = node_closing + 1
    return layers


def check_keymap() -> None:
    path = ROOT / "config/modu.keymap"
    text = path.read_text(encoding="utf-8")
    for include in (
        "#include <behaviors.dtsi>",
        "#include <dt-bindings/zmk/keys.h>",
        "#include <dt-bindings/zmk/bt.h>",
    ):
        if include not in text:
            fail(f"config/modu.keymap is missing {include}")

    pointing_include = "#include <dt-bindings/zmk/pointing.h>"
    uses_pointing = re.search(r"(?<![A-Za-z0-9_])&(mkp|mmv|msc)\b", text)
    if uses_pointing and pointing_include not in text:
        fail(f"config/modu.keymap uses a pointing behavior but is missing {pointing_include}")

    layers = _keymap_layers(text)
    if len(layers) < 2:
        fail(f"expected at least two keymap layers, found {len(layers)}")
    if layers[0][0] != "default_layer" or layers[1][0] != "lower_layer":
        fail("the first two keymap nodes must remain default_layer and lower_layer")

    wrong_sizes = [(name, len(bindings)) for name, bindings in layers if len(bindings) != 71]
    if wrong_sizes:
        fail(f"every keymap layer must contain 71 behavior bindings; found {wrong_sizes}")

    default_bindings = layers[0][1]
    none_indices = tuple(index for index, name in enumerate(default_bindings) if name == "none")
    if none_indices != PLACEHOLDER_INDICES:
        fail(
            "default-layer &none placeholders must be exactly zero-based indices "
            f"{PLACEHOLDER_INDICES}; found {none_indices}"
        )


def _manifest_project(text: str, name: str) -> dict[str, str]:
    match = re.search(
        rf"(?ms)^    - name:\s*{re.escape(name)}\s*$\n"
        r"(?P<body>(?:^      [^\n]*\n?)*)",
        text,
    )
    if not match:
        fail(f"config/west.yml has no project named {name!r}")
    values: dict[str, str] = {}
    for line in match.group("body").splitlines():
        item = re.match(r"^\s{6}([A-Za-z0-9_-]+):\s*(.*?)\s*$", line)
        if item:
            key, value = item.groups()
            if key in values:
                fail(f"config/west.yml repeats {key!r} in project {name!r}")
            values[key] = value
    return values



def bindings_with_parameters(text):
    stripped=_strip_comments(text)
    blocks=re.findall(r'\bbindings\s*=\s*<(.*?)>\s*;',stripped,re.S)
    result=[]
    for block in blocks:
        entries=[' '.join(x.split()) for x in re.findall(r'&[A-Za-z_]\w*[^&]*',block)]
        if len(entries)>=67:result.append(entries)
    return result

def check_preservation():
    before=bindings_with_parameters((ROOT/'docs/original-modu.keymap.txt').read_text())
    after=bindings_with_parameters((ROOT/'config/modu.keymap').read_text())
    if len(before)!=3 or len(after)!=9:fail('expected original 3 layers and MODU STENO 9 layers')
    contract=load_json(ROOT/'docs/steno-layout-contract.json')
    if after != [layer['bindings'] for layer in contract['layers']]:fail('STENO layout differs from the reviewed source contract')
    if after[0][41] != '&kp B' or after[7][41] != '&st_i_double':fail('left B must remain Base B / STENO initial double')
    for i in (0,1,3,4,5,6,7,8):
        if after[i][60] != '&st_mode':fail('right additional B must retain the mode toggle')
    if after[1][48] != '&mo MODU_CONTROLS':fail('Num+left Ctrl control access is missing')
    if after[2][5:7]!=before[2][5:7]:fail('original bootloader controls must remain at positions 5 and 6')
    current=load_json(ROOT/'config/modu.json')['layouts']['default_transform']['layout']
    original=load_json(ROOT/'docs/original-modu.json')['layouts']['default_transform']['layout']
    expected=[dict(k) for k in original]
    expected[66].update(x=7,y=3)
    if current[:61]!=[v for j,v in enumerate(expected) if j not in REMOVED]:fail('physical positions changed outside the requested extra-B relocation')
    controls=load_json(ROOT/'docs/control-bindings.json')
    for pos,binding in controls.items():
        if after[2][int(pos)]!=binding:fail(f'control map differs at {pos}')
    if after[2][48]!='&trans':fail('Fn-to-controls access key must stay transparent for reliable release')
    expected=['&kp '+s for s in ('UP','DOWN','LEFT','RIGHT')]*2
    if after[0][61:69]!=expected:fail('virtual directions default bindings differ')
    if after[0][69:]!=['&lball MC_MOUSE','&rball MC_MOUSE']:fail('missing ball configuration slots')
    for layer in after[1:]:
        if layer[69:]!=['&trans','&trans']:fail('ball settings belong on Base only')

def check_build_files():
    matrix=load_json(ROOT/'build.yaml')['include']
    if [(x['board'],x['shield'],x['artifact-name']) for x in matrix]!=[
        (BOARD,'modu_left','modu_left'),(BOARD,'modu_right','modu_right')]:fail('wrong board or sides')
    if matrix[0]['snippet']!='studio-rpc-usb-uart' or matrix[1]['snippet']:fail('USB Studio must be central-only')
    west=(ROOT/'config/west.yml').read_text()
    zmk=_manifest_project(west,'zmk');modu=_manifest_project(west,'modu-c-firmware')
    if zmk.get('revision')!=ZMK_REVISION or zmk.get('import')!='app/west.yml':fail('ZMK pin changed')
    if modu.get('revision')!=MODU_REVISION or modu.get('path')!='modu-c-firmware':fail('MODU pin changed')
    if zmk.get('remote')!='zmkfirmware' or modu.get('remote')!='modu-c-upstream':fail('source remote changed')
    for token in ('url-base: https://github.com/zmkfirmware','url-base: https://github.com/22sh22','self:\n    path: config'):
        if token not in west:fail('manifest missing '+token)
    workflow=(ROOT/'.github/workflows/build.yml').read_text()
    for token in ('workflow_dispatch:','side: [left, right]','west update','scripts/build_firmware.py',
                  'if: always()','include-hidden-files: true','modu-diagnostics-','modu-c-studio-firmware','scripts/package_firmware.py',
                  '--family 0xADA52840','scripts/verify_uf2.py','cp LICENSE NOTICE.md THIRD_PARTY_NOTICES.md uf2/',
                  'cp -R LICENSES uf2/LICENSES','zmkfirmware/zmk-build-arm:stable',MODU_REVISION):
        if token not in workflow:fail('workflow missing '+token)
    if (ROOT/'BUILD_WORKFLOW_COPY.txt').read_text()!=workflow:fail('workflow copy is stale')
    if re.search(r'^\s+path: config\s*$',workflow,re.M):fail('checkout root mismatch: manifest is config/west.yml')
    for required in REQUIRED_LICENSE_FILES:
        p=ROOT/required
        if not p.is_file() or not p.stat().st_size:fail('missing license/notice '+required)
    for p in list((ROOT/'scripts').glob('*.py'))+list((ROOT/'tests').glob('*.py')):
        compile(p.read_text(),str(p),'exec')
    for name in ('core.c','runtime.c','behavior.c','hardware.c','input_processor.c','studio_profile.c'):
        if not (ROOT/'modules/modu-control/src'/name).is_file():fail('missing module source '+name)
    internal=(ROOT/'modules/modu-control/src/behavior.c').read_text()
    if not re.search(r'hw_api\s*=\s*\{[^}]*\.locality=BEHAVIOR_LOCALITY_EVENT_SOURCE', internal, re.S):
        fail('hardware commands must use addressed EVENT_SOURCE delivery')
    source=(ROOT/'config/modu-controls.dtsi').read_text()
    # Addressed split behavior names are sent over the protocol: <=8 characters.
    if 'modu_hw: modu_hw {' not in source:fail('internal split behavior name changed')
    for token in ('PMW3610_ALT_ATTR_CPI','sensor_attr_set','bt_hci_cmd_send_sync'):
        if token not in (ROOT/'modules/modu-control/src/hardware.c').read_text():fail('hardware control absent '+token)
    if (ROOT/'config/generated/modu-hardware.dtsi').exists():
        print('NOTE: generated hardware exists locally; never copy it between left/right builds.')

def main():
    check_metadata()
    check_trackball_cross(load_json(ROOT/'config/modu.json')['layouts']['default_transform']['layout'])
    check_keymap();check_preservation();check_build_files()
    print('PASS: 71 logical positions; physical matrix geometry preserved; Cornix Base/STENO and auxiliary rules on 9 layers.')
    print('PASS: two native 1u square crosses with center settings; separate controls and USB-only Studio.')
    print('PASS: packaging safeguards, license notices and build diagnostics remain wired in.')
    print('NOT PERFORMED by this checker: Zephyr compilation, USB/BLE or hardware testing.')
if __name__=='__main__':main()
