#include <errno.h>
/* MODIFIED / unofficial MODU-C extension. See repository LICENSE. */
#include <zephyr/device.h>
#include <zephyr/kernel.h>
#include <zephyr/logging/log.h>
#include <drivers/behavior.h>
#include <zmk/behavior.h>
#include <modu/runtime.h>
LOG_MODULE_DECLARE(zmk, CONFIG_ZMK_LOG_LEVEL);
struct control_config { uint8_t side, kind; };

#if IS_ENABLED(CONFIG_ZMK_BEHAVIOR_METADATA)
#define VAL(text,n) {.display_name=text,.type=BEHAVIOR_PARAMETER_VALUE_TYPE_VALUE,.value=n}
#define RANGE(text,lo,hi) {.display_name=text,.type=BEHAVIOR_PARAMETER_VALUE_TYPE_RANGE,.range={.min=lo,.max=hi}}
static const struct behavior_parameter_value_metadata mode_values[]={
    VAL("Mouse",MC_MOUSE),VAL("Scroll",MC_SCROLL),VAL("Arrow keys",MC_ARROWS),VAL("Disabled",MC_OFF)};
static const struct behavior_parameter_value_metadata profile_values[]={
    VAL("Mouse",MC_MOUSE),VAL("Wheel / scroll",MC_SCROLL),VAL("Arrow keys",MC_ARROWS),
    VAL("Disabled",MC_OFF),VAL("Follow mode keys (last saved)",MC_PROFILE_KEYS)};
static const struct behavior_parameter_value_metadata cycle_values[]={
    VAL("Mouse > Wheel > Arrows",MC_CYCLE_NEXT),
    VAL("Mouse > Arrows > Wheel",MC_CYCLE_PREVIOUS),
    VAL("Mouse <> Wheel",MC_CYCLE_MOUSE_SCROLL)};
static const struct behavior_parameter_value_metadata bool_values[]={VAL("Off",0),VAL("On",1)};
static const struct behavior_parameter_value_metadata zero_values[]={VAL("Execute",0)};
static const struct behavior_parameter_value_metadata operation_values[]={
    VAL("Increase / faster",MC_INC),VAL("Decrease / slower",MC_DEC),
    VAL("Reset to default",MC_RESET),VAL("Maximum / fastest",MC_MAX)};
static const struct behavior_parameter_value_metadata set_values[]={VAL("Set exact value",MC_SET)};
static const struct behavior_parameter_value_metadata cpi_values[]={
    VAL("200 CPI",200),VAL("400 CPI",400),VAL("600 CPI",600),VAL("800 CPI",800),
    VAL("1000 CPI",1000),VAL("1200 CPI",1200),VAL("1400 CPI",1400),VAL("1600 CPI",1600),
    VAL("1800 CPI",1800),VAL("2000 CPI",2000),VAL("2200 CPI",2200),VAL("2400 CPI",2400),
    VAL("2600 CPI",2600),VAL("2800 CPI",2800),VAL("3000 CPI",3000),VAL("3200 CPI",3200)};
static const struct behavior_parameter_value_metadata pointer_values[]={RANGE("Percent (100 = original)",25,400)};
static const struct behavior_parameter_value_metadata scroll_values[]={RANGE("Counts per notch (smaller = faster)",1,200)};
static const struct behavior_parameter_value_metadata arrow_values[]={RANGE("Counts per key tap (smaller = faster)",1,500)};
static const struct behavior_parameter_value_metadata rate_values[]={RANGE("Milliseconds per tap (smaller = faster)",20,500)};
static const struct behavior_parameter_value_metadata tx_values[]={
    VAL("-20 dBm",0),VAL("-16 dBm",1),VAL("-12 dBm",2),VAL("-8 dBm",3),VAL("-4 dBm",4),
    VAL("0 dBm",5),VAL("+2 dBm",6),VAL("+4 dBm",7),VAL("+6 dBm",8),VAL("+8 dBm (default / maximum)",9)};
#define ONE_SET(values) {.param1_values=values,.param1_values_len=ARRAY_SIZE(values)}
#define TWO_SETS(name,values) \
    static const struct behavior_parameter_metadata_set name##_sets[]={ \
        {.param1_values=operation_values,.param1_values_len=ARRAY_SIZE(operation_values)}, \
        {.param1_values=set_values,.param1_values_len=ARRAY_SIZE(set_values), \
         .param2_values=values,.param2_values_len=ARRAY_SIZE(values)}}
static const struct behavior_parameter_metadata_set mode_sets[]={ONE_SET(mode_values)};
static const struct behavior_parameter_metadata_set profile_sets[]={ONE_SET(profile_values)};
static const struct behavior_parameter_metadata_set cycle_sets[]={ONE_SET(cycle_values)};
static const struct behavior_parameter_metadata_set bool_sets[]={ONE_SET(bool_values)};
static const struct behavior_parameter_metadata_set zero_sets[]={ONE_SET(zero_values)};
TWO_SETS(cpi,cpi_values); TWO_SETS(pointer,pointer_values); TWO_SETS(scroll,scroll_values);
TWO_SETS(arrow,arrow_values); TWO_SETS(rate,rate_values); TWO_SETS(tx,tx_values);
#define META(name) {.sets=name##_sets,.sets_len=ARRAY_SIZE(name##_sets)}
static const struct behavior_parameter_metadata metadata[]={
    [MC_KIND_MODE]=META(mode),[MC_KIND_HOLD]=META(mode),[MC_KIND_CPI]=META(cpi),
    [MC_KIND_POINTER]=META(pointer),[MC_KIND_SCROLL]=META(scroll),[MC_KIND_ARROW]=META(arrow),
    [MC_KIND_RATE]=META(rate),[MC_KIND_INVERT]=META(bool),[MC_KIND_DIAGONAL]=META(bool),
    [MC_KIND_TX]=META(tx),[MC_KIND_RESET]=META(zero),[MC_KIND_SYNC]=META(zero),
    [MC_KIND_CYCLE]=META(cycle),[MC_KIND_PROFILE]=META(profile)};
#define INSTANCE_METADATA(n) .parameter_metadata=&metadata[DT_INST_PROP(n,kind)],
#else
#define INSTANCE_METADATA(n)
#endif

static uint64_t key_token(struct zmk_behavior_binding_event e) {
    uint64_t source=0;
#if IS_ENABLED(CONFIG_ZMK_SPLIT)
    source=e.source;
#endif
    return (source<<32)|e.position;
}
static int pressed(struct zmk_behavior_binding *b,struct zmk_behavior_binding_event e) {
    const struct device *dev=zmk_behavior_get_binding(b->behavior_dev);
    if(!dev) return -ENODEV;
    const struct control_config *cfg=dev->config;
    int ret;
    switch(cfg->kind) {
    case MC_KIND_HOLD: ret=modu_hold(cfg->side,key_token(e),b->param1,true); break;
    case MC_KIND_PROFILE: return ZMK_BEHAVIOR_OPAQUE; /* Configuration marker, no key action. */
    case MC_KIND_CYCLE: case MC_KIND_MODE: case MC_KIND_INVERT: case MC_KIND_DIAGONAL:
        ret=modu_change(cfg->side,cfg->kind,MC_SET,b->param1); break;
    case MC_KIND_RESET: ret=modu_change(cfg->side,cfg->kind,MC_RESET,0); break;
    case MC_KIND_SYNC: ret=modu_sync(); break;
    case MC_KIND_TX: ret=modu_tx_change(cfg->side,b->param1,b->param2); break;
    default: ret=modu_change(cfg->side,cfg->kind,b->param1,b->param2); break;
    }
    if(ret<0) LOG_WRN("MODU command %u side %u failed: %d",cfg->kind,cfg->side,ret);
    return ret<0 ? ret : ZMK_BEHAVIOR_OPAQUE;
}
static int released(struct zmk_behavior_binding *b,struct zmk_behavior_binding_event e) {
    const struct device *dev=zmk_behavior_get_binding(b->behavior_dev);
    if(!dev) return -ENODEV;
    const struct control_config *cfg=dev->config;
    if(cfg->kind==MC_KIND_HOLD) return modu_hold(cfg->side,key_token(e),0,false);
    return ZMK_BEHAVIOR_OPAQUE;
}
#define DT_DRV_COMPAT modu_control_one
#define DEFINE_ONE(n) \
    static const struct control_config cfg_one_##n={.side=DT_INST_PROP(n,side),.kind=DT_INST_PROP(n,kind)}; \
    static const struct behavior_driver_api api_one_##n={.binding_pressed=pressed,.binding_released=released, \
        .locality=BEHAVIOR_LOCALITY_CENTRAL,INSTANCE_METADATA(n)}; \
    BEHAVIOR_DT_INST_DEFINE(n,NULL,NULL,NULL,&cfg_one_##n,POST_KERNEL, \
        CONFIG_KERNEL_INIT_PRIORITY_DEFAULT,&api_one_##n);
DT_INST_FOREACH_STATUS_OKAY(DEFINE_ONE)
#undef DT_DRV_COMPAT
#define DT_DRV_COMPAT modu_control_two
#define DEFINE_TWO(n) \
    static const struct control_config cfg_two_##n={.side=DT_INST_PROP(n,side),.kind=DT_INST_PROP(n,kind)}; \
    static const struct behavior_driver_api api_two_##n={.binding_pressed=pressed,.binding_released=released, \
        .locality=BEHAVIOR_LOCALITY_CENTRAL,INSTANCE_METADATA(n)}; \
    BEHAVIOR_DT_INST_DEFINE(n,NULL,NULL,NULL,&cfg_two_##n,POST_KERNEL, \
        CONFIG_KERNEL_INIT_PRIORITY_DEFAULT,&api_two_##n);
DT_INST_FOREACH_STATUS_OKAY(DEFINE_TWO)
#undef DT_DRV_COMPAT
#define DT_DRV_COMPAT modu_hardware_command
static int hw_pressed(struct zmk_behavior_binding *b,struct zmk_behavior_binding_event e) {
    ARG_UNUSED(e);
    unsigned side=b->param1&0xff,kind=b->param1>>8;
    if(side>1 || kind>1) return -EINVAL;
    if(side!=DT_PROP(DT_NODELABEL(modu_hw_info),side)) return ZMK_BEHAVIOR_OPAQUE;
    if(kind==0) {
        if(b->param2<200 || b->param2>3200 || b->param2%200) return -ERANGE;
        modu_remote_cpi(side,(uint16_t)b->param2);
    } else {
        if(b->param2>9) return -ERANGE;
        modu_local_tx(b->param2);
    }
    return ZMK_BEHAVIOR_OPAQUE;
}
static int hw_released(struct zmk_behavior_binding *b,struct zmk_behavior_binding_event e) {
    ARG_UNUSED(b); ARG_UNUSED(e); return ZMK_BEHAVIOR_OPAQUE;
}
static const struct behavior_driver_api hw_api={.binding_pressed=hw_pressed,.binding_released=hw_released,
    .locality=BEHAVIOR_LOCALITY_EVENT_SOURCE};
BEHAVIOR_DT_INST_DEFINE(0,NULL,NULL,NULL,NULL,POST_KERNEL,CONFIG_KERNEL_INIT_PRIORITY_DEFAULT,&hw_api);
