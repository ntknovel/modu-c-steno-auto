#include <errno.h>
/* Stateful controls; persistent trackball settings, session-only RF power. */
#include <zephyr/device.h>
#include <zephyr/kernel.h>
#include <zephyr/init.h>
#include <zephyr/settings/settings.h>
#include <zephyr/logging/log.h>
#include <zmk/behavior.h>
#include <modu/runtime.h>
#include <string.h>
#if IS_ENABLED(CONFIG_ZMK_SPLIT_ROLE_CENTRAL)
#include <zmk/event_manager.h>
#include <zmk/events/position_state_changed.h>
#endif
LOG_MODULE_DECLARE(zmk,CONFIG_ZMK_LOG_LEVEL);
#define LOCAL_SIDE DT_PROP(DT_NODELABEL(modu_hw_info),side)
#define MC_STORE_VERSION_V1 0x4d430100u
#define MC_STORE_VERSION 0x4d430200u
#define MC_STORE_KEY "modu_control/v2"
static struct mc_core core;
K_MUTEX_DEFINE(state_lock);
static unsigned tx_index[2]={MC_TX_DEFAULT,MC_TX_DEFAULT};
/* Versioned runtime settings; ZMK's keymap/settings namespace is untouched.
 * Keep mode memory in the SAME record as its selected mode, not two independent
 * flash writes. The old v1 record remains readable for migration/rollback. */
struct stored_profile { uint8_t seen, mode, manual, reserved; };
struct stored_config_v1 { uint32_t version; struct mc_config sides[2]; };
struct stored_config {
    uint32_t version;
    struct mc_config sides[2];
    struct stored_profile profiles[2];
};
static struct stored_profile mode_memory[MC_SIDES];
static bool loaded_v2, loaded_legacy;
static void save_later(void);
static void save_work_fn(struct k_work *work);
static void start_work_fn(struct k_work *work);
static void sync_work_fn(struct k_work *work);
K_WORK_DELAYABLE_DEFINE(save_work,save_work_fn);
K_WORK_DELAYABLE_DEFINE(start_work,start_work_fn);
K_WORK_DELAYABLE_DEFINE(sync_work,sync_work_fn);
static unsigned sync_attempts;

/* Every new desired value starts a fresh bounded resynchronization burst. */
static void request_sync_retry(void) {
    k_mutex_lock(&state_lock,K_FOREVER);
    sync_attempts=3;
    k_mutex_unlock(&state_lock);
    k_work_reschedule(&sync_work,K_MSEC(1500));
}

/* No timer polling: inspect Studio settings on input/control use, and before
 * releasing/draining pending arrow taps. Studio writes retain normal save/discard.
 * Mode markers affect runtime only; do not auto-save unrelated pending keymap edits.
 */
static void refresh_profile(unsigned side) {
#if IS_ENABLED(CONFIG_ZMK_SPLIT_ROLE_CENTRAL)
    if(side>=MC_SIDES) return;
    int mode=modu_read_studio_profile(side);
    if(mode<0) return;
    bool committed=modu_studio_keymap_saved(), changed=false;
    k_mutex_lock(&state_lock,K_FOREVER);
    mc_profile(&core,side,(unsigned)mode);
    struct stored_profile *p=&mode_memory[side];
    if(committed) {
        if(!p->seen) {
            /* First observation adopts the saved Base value. Migrated v1 mode
             * (or a physical action before the first read) remains authoritative. */
            p->seen=1; p->mode=(uint8_t)mode;
            changed=loaded_legacy;
        } else if(p->mode!=(uint8_t)mode) {
            /* An explicitly changed AND saved Studio baseline is a new choice.
             * It replaces an older physical override, but unrelated saves do not. */
            p->mode=(uint8_t)mode; p->manual=0; changed=true;
        }
        mc_restore_manual(&core,side,p->manual!=0);
    }
    /* While Studio has a draft, preview it without changing stored mode memory.
     * Discard returns to the prior baseline/manual preference on the next read.
     * This module never calls keymap_save_changes or writes a key binding. */
    k_mutex_unlock(&state_lock);
    if(changed) save_later();
#else
    ARG_UNUSED(side);
#endif
}

#if IS_ENABLED(CONFIG_ZMK_SPLIT_ROLE_CENTRAL)
struct pulse_lane {
    uint8_t pending[4], next_direction;
    int active_direction;
    uint32_t generation;
    int64_t release_at, next_at;
};
static struct pulse_lane lanes[2]={{.active_direction=-1},{.active_direction=-1}};
static void pulse_work_fn(struct k_work *work);
K_WORK_DELAYABLE_DEFINE(pulse_work,pulse_work_fn);
static void emit_virtual(unsigned side,unsigned direction,bool down) {
    /* Use the standard position event path, so keymap layers and Studio remaps apply. */
    raise_zmk_position_state_changed((struct zmk_position_state_changed){
        .source=ZMK_POSITION_STATE_CHANGE_SOURCE_LOCAL,
        .position=MC_VIRTUAL_START+side*4+direction,.state=down,.timestamp=k_uptime_get()});
}
static void pulse_work_fn(struct k_work *work) {
    ARG_UNUSED(work);
    refresh_profile(0); refresh_profile(1);
    struct pulse_event {uint8_t side,dir;bool down;};
    struct pulse_event events[4];
    unsigned count=0; int64_t delay=INT64_MAX, now=k_uptime_get();
    k_mutex_lock(&state_lock,K_FOREVER);
    for(unsigned s=0;s<2;s++) {
        struct pulse_lane *l=&lanes[s];
        bool stale=l->generation!=core.motion[s].generation || mc_mode(&core,s)!=MC_ARROWS;
        if(stale) {
            memset(l->pending,0,sizeof(l->pending));
            l->generation=core.motion[s].generation;
            l->next_at=now;
            l->next_direction=0;
        }
        if(l->active_direction>=0 && (stale || now>=l->release_at)) {
            events[count++]=(struct pulse_event){s,(uint8_t)l->active_direction,false};
            l->active_direction=-1;
        }
        if(l->active_direction<0 && !stale && now>=l->next_at) {
            for(unsigned i=0;i<4;i++) {
                unsigned d=(l->next_direction+i)%4;
                if(!l->pending[d]) continue;
                l->pending[d]--; l->active_direction=(int)d;
                l->next_direction=(d+1)%4; l->release_at=now+12;
                l->next_at=now+core.config[s].arrow_ms;
                events[count++]=(struct pulse_event){s,d,true}; break;
            }
        }
        if(l->active_direction>=0) delay=MIN(delay,MAX(1,l->release_at-now));
        else for(unsigned d=0;d<4;d++) if(l->pending[d]) delay=MIN(delay,MAX(1,l->next_at-now));
    }
    k_mutex_unlock(&state_lock);
    /* Never call ZMK behavior/event code while holding our state mutex. */
    for(unsigned i=0;i<count;i++) emit_virtual(events[i].side,events[i].dir,events[i].down);
    if(delay!=INT64_MAX) k_work_schedule(&pulse_work,K_MSEC(delay));
}
static void kick_pulses(void) { k_work_reschedule(&pulse_work,K_NO_WAIT); }
#else
static void kick_pulses(void) {}
#endif

static void save_work_fn(struct k_work *work) {
    ARG_UNUSED(work); struct stored_config snapshot={.version=MC_STORE_VERSION};
    k_mutex_lock(&state_lock,K_FOREVER);
    memcpy(snapshot.sides,core.config,sizeof(snapshot.sides));
    memcpy(snapshot.profiles,mode_memory,sizeof(snapshot.profiles));
    k_mutex_unlock(&state_lock);
    int ret=settings_save_one(MC_STORE_KEY,&snapshot,sizeof(snapshot));
    if(ret<0) LOG_WRN("MODU settings save failed: %d",ret);
    else {
        k_mutex_lock(&state_lock,K_FOREVER);
        loaded_v2=true; loaded_legacy=false;
        k_mutex_unlock(&state_lock);
    }
}
static void save_later(void) { k_work_reschedule(&save_work,K_MSEC(1200)); }
static bool profile_valid(const struct stored_profile *p) {
    return p->seen<=1 && p->mode<=MC_PROFILE_KEYS && p->manual<=1 && p->reserved==0;
}
static int settings_set(const char *name,size_t len,settings_read_cb read_cb,void *arg) {
    if(!strcmp(name,"v1")) {
        struct stored_config_v1 in;
        if(len!=sizeof(in)) return -EINVAL;
        int ret=read_cb(arg,&in,sizeof(in));
        if(ret<0) return ret;
        if((size_t)ret!=sizeof(in) || in.version!=MC_STORE_VERSION_V1 ||
           !mc_config_valid(&in.sides[0]) || !mc_config_valid(&in.sides[1])) return -EINVAL;
        k_mutex_lock(&state_lock,K_FOREVER);
        /* Settings iteration order must not let legacy data overwrite v2. */
        if(!loaded_v2) {
            memcpy(core.config,in.sides,sizeof(core.config));
            memset(mode_memory,0,sizeof(mode_memory));
            /* v1 did not record whether Mouse was an explicit choice or just
             * the default. Recover non-default choices; keep the Studio baseline
             * when the old saved mode was the indistinguishable Mouse default. */
            for(unsigned s=0;s<MC_SIDES;s++)
                mode_memory[s].manual=in.sides[s].mode!=mc_defaults.mode;
            loaded_legacy=true;
        }
        k_mutex_unlock(&state_lock);
        return 0;
    }
    if(strcmp(name,"v2")) return -ENOENT;
    struct stored_config in;
    if(len!=sizeof(in)) return -EINVAL;
    int ret=read_cb(arg,&in,sizeof(in));
    if(ret<0) return ret;
    if((size_t)ret!=sizeof(in) || in.version!=MC_STORE_VERSION ||
       !mc_config_valid(&in.sides[0]) || !mc_config_valid(&in.sides[1]) ||
       !profile_valid(&in.profiles[0]) || !profile_valid(&in.profiles[1])) return -EINVAL;
    k_mutex_lock(&state_lock,K_FOREVER);
    memcpy(core.config,in.sides,sizeof(core.config));
    memcpy(mode_memory,in.profiles,sizeof(mode_memory));
    for(unsigned s=0;s<MC_SIDES;s++) {
        /* Restore the last SAVED baseline/override, not held keys or motion. */
        core.motion[s].profile_seen=mode_memory[s].seen!=0;
        core.motion[s].profile_mode=mode_memory[s].mode;
        core.motion[s].manual_mode=mode_memory[s].manual!=0;
    }
    loaded_v2=true;
    k_mutex_unlock(&state_lock);
    return 0;
}
SETTINGS_STATIC_HANDLER_DEFINE(modu_control,"modu_control",NULL,settings_set,NULL,NULL);

static int send_hardware(unsigned side,unsigned kind,uint32_t value) {
    if(side>=MC_SIDES || kind>1) return -EINVAL;
#if IS_ENABLED(CONFIG_ZMK_SPLIT_ROLE_CENTRAL)
    struct zmk_behavior_binding binding={
        .behavior_dev=DEVICE_DT_NAME(DT_NODELABEL(modu_hw)),.param1=(kind<<8)|side,.param2=value};
    /* MODU-C has one peripheral: right is source 0, NOT logical side number 1.
     * EVENT_SOURCE returns the addressed transport's status; GLOBAL masks it. */
    struct zmk_behavior_binding_event event={.position=0,.timestamp=k_uptime_get(),
        .source=side==MC_LEFT ? ZMK_POSITION_STATE_CHANGE_SOURCE_LOCAL : 0};
    int ret=zmk_behavior_invoke_binding(&binding,event,true);
    return ret>0 ? -EIO : ret;
#else
    if(side!=LOCAL_SIDE) return -ENOTCONN;
    if(kind==0) modu_remote_cpi(side,(uint16_t)value); else modu_local_tx(value);
    return 0;
#endif
}
void modu_remote_cpi(unsigned side,uint16_t cpi) {
    if(side!=LOCAL_SIDE || cpi<200 || cpi>3200 || cpi%200) return;
#if IS_ENABLED(CONFIG_ZMK_SPLIT_ROLE_CENTRAL)
    /* The central owns desired settings. An older in-flight sync snapshot must
     * never write them back or overwrite a newer CPI key press. Apply latest. */
    k_mutex_lock(&state_lock,K_FOREVER);
    cpi=core.config[side].cpi;
    k_mutex_unlock(&state_lock);
    modu_local_cpi(cpi);
#else
    k_mutex_lock(&state_lock,K_FOREVER);
    bool changed=core.config[side].cpi!=cpi;
    int ret=mc_change(&core,side,MC_KIND_CPI,MC_SET,cpi);
    k_mutex_unlock(&state_lock);
    if(ret<0) return;
    modu_local_cpi(cpi);
    if(changed) save_later();
#endif
}
int modu_change(unsigned side,unsigned kind,unsigned command,uint32_t value) {
    if(side>=2) return -EINVAL;
    if(kind==MC_KIND_MODE || kind==MC_KIND_CYCLE || kind==MC_KIND_RESET) refresh_profile(side);
    uint16_t cpi; int ret; bool changed;
    k_mutex_lock(&state_lock,K_FOREVER);
    struct mc_config before=core.config[side];
    ret=mc_change(&core,side,kind,command,value);
    cpi=core.config[side].cpi;
    changed=memcmp(&before,&core.config[side],sizeof(before))!=0;
    if(ret==0 && (kind==MC_KIND_MODE || kind==MC_KIND_CYCLE || kind==MC_KIND_RESET)) {
        /* Preserve physical choices even when Base still says Mouse and even
         * when the numeric mode itself equals the previously stored value. */
        if(!mode_memory[side].manual) changed=true;
        mode_memory[side].manual=1;
    }
    k_mutex_unlock(&state_lock);
    if(ret<0) return ret;
    kick_pulses();
    if(changed) save_later();
    if(kind==MC_KIND_CPI || kind==MC_KIND_RESET) {
        /* Absolute values: retries cannot increment the remote a second time. */
        int hwret=send_hardware(side,0,cpi);
        if(hwret<0) LOG_WRN("MODU CPI stored; remote apply pending: %d",hwret);
        request_sync_retry();
    }
    return 0;
}
int modu_hold(unsigned side,uint64_t token,unsigned mode,bool pressed) {
    refresh_profile(side);
    k_mutex_lock(&state_lock,K_FOREVER);
    int ret=mc_hold(&core,side,token,mode,pressed);
    k_mutex_unlock(&state_lock);
    kick_pulses(); return ret;
}
int modu_motion(unsigned side,unsigned axis,int32_t value,bool sync,struct mc_result *out) {
    refresh_profile(side);
    k_mutex_lock(&state_lock,K_FOREVER);
    int ret=mc_feed(&core,side,axis,value,sync,out);
#if IS_ENABLED(CONFIG_ZMK_SPLIT_ROLE_CENTRAL)
    bool queued=false;
    if(ret==0 && out->mode==MC_ARROWS) {
        struct pulse_lane *l=&lanes[side];
        if(l->generation!=core.motion[side].generation) {
            memset(l->pending,0,sizeof(l->pending));
            /* If a key is active, the worker must release it before adopting the new generation. */
            if(l->active_direction<0) {
                l->generation=core.motion[side].generation;
                l->next_at=0;
                l->next_direction=0;
            }
        }
        if(l->generation==core.motion[side].generation) for(unsigned d=0;d<4;d++) {
            if(out->arrows[d]) {
                /* Do not alternate new motion with stale opposite-direction taps. */
                l->pending[d^1]=0;
                if(!core.config[side].diagonal)
                    for(unsigned other=0;other<4;other++) if(other!=d) l->pending[other]=0;
                l->pending[d]=MIN(4,l->pending[d]+out->arrows[d]);
                queued=true;
            }
        }
    }
#endif
    k_mutex_unlock(&state_lock);
#if IS_ENABLED(CONFIG_ZMK_SPLIT_ROLE_CENTRAL)
    if(queued) kick_pulses();
#endif
    return ret;
}
int modu_tx_change(unsigned side,unsigned command,uint32_t value) {
    if(side>MC_BOTH || command>MC_MAX || (command==MC_SET && value>MC_TX_MAX_INDEX)) return -EINVAL;
    int status=0;
    for(unsigned s=0;s<2;s++) {
        if(side!=MC_BOTH && side!=s) continue;
        k_mutex_lock(&state_lock,K_FOREVER);
        int n=tx_index[s];
        switch(command) {
        case MC_SET:n=value;break;case MC_INC:n++;break;case MC_DEC:n--;break;
        case MC_RESET:n=MC_TX_DEFAULT;break;case MC_MAX:n=MC_TX_MAX_INDEX;break;
        }
        tx_index[s]=CLAMP(n,0,MC_TX_MAX_INDEX); n=tx_index[s];
        k_mutex_unlock(&state_lock);
        int ret=send_hardware(s,1,n); if(ret<0) status=ret;
    }
    request_sync_retry();
    return status;
}
int modu_sync(void) {
    uint16_t cpi[2];
    k_mutex_lock(&state_lock,K_FOREVER);
    for(unsigned s=0;s<2;s++) cpi[s]=core.config[s].cpi;
    k_mutex_unlock(&state_lock);
    int first=send_hardware(0,0,cpi[0]);
    int second=send_hardware(1,0,cpi[1]);
    return first<0 ? first : second;
}
static void sync_work_fn(struct k_work *work) {
    ARG_UNUSED(work);
#if IS_ENABLED(CONFIG_ZMK_SPLIT_ROLE_CENTRAL)
    int ret=modu_sync();
    unsigned recover_tx[2];
    k_mutex_lock(&state_lock,K_FOREVER);
    recover_tx[0]=tx_index[0]; recover_tx[1]=tx_index[1];
    k_mutex_unlock(&state_lock);
    int left_tx=send_hardware(0,1,recover_tx[0]);
    int right_tx=send_hardware(1,1,recover_tx[1]);
    if(!ret) ret=left_tx<0 ? left_tx : right_tx;
    if(ret<0) LOG_DBG("MODU hardware sync not ready: %d",ret);
    k_mutex_lock(&state_lock,K_FOREVER);
    bool again=sync_attempts>0; if(again) sync_attempts--;
    k_mutex_unlock(&state_lock);
    if(again) k_work_reschedule(&sync_work,K_MSEC(2000));
    else if(ret<0) LOG_WRN("MODU hardware sync still unavailable: %d; reconnect or resend settings",ret);
#endif
}
void modu_link_changed(void) {
    /* Recover maximum TX: manual RF reductions do not survive disconnect/reboot. */
    k_mutex_lock(&state_lock,K_FOREVER);
    tx_index[0]=tx_index[1]=MC_TX_DEFAULT;
    mc_cancel_holds(&core); /* A disconnected key cannot send its release. */
    sync_attempts=3;
    k_mutex_unlock(&state_lock);
    kick_pulses();
    modu_local_tx(MC_TX_DEFAULT);
    k_work_reschedule(&sync_work,K_MSEC(1500));
}
static void start_work_fn(struct k_work *work) {
    ARG_UNUSED(work);
    k_mutex_lock(&state_lock,K_FOREVER);
    uint16_t cpi=core.config[LOCAL_SIDE].cpi; sync_attempts=3;
    k_mutex_unlock(&state_lock);
    modu_local_cpi(cpi); modu_local_tx(MC_TX_DEFAULT);
    k_work_reschedule(&sync_work,K_MSEC(2000));
}
static int initialize(void) {
    mc_init(&core);
    memset(mode_memory,0,sizeof(mode_memory));
    loaded_v2=false; loaded_legacy=false;
    modu_hw_init();
    k_work_schedule(&start_work,K_MSEC(1500));
    return 0;
}
SYS_INIT(initialize,APPLICATION,80);
