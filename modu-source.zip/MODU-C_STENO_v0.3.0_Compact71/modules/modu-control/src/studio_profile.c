/* Unofficial MODU-C extension. See root LICENSE.
 * A settings slot is NOT a synthetic key press. Read ONLY known mode markers.
 * Base layer ID 0 remains stable when its display name/order changes.
 */
#include <errno.h>
#include <string.h>
#include <zephyr/device.h>
#include <modu/runtime.h>
#if IS_ENABLED(CONFIG_ZMK_SPLIT_ROLE_CENTRAL)
#include <zmk/behavior.h>
#include <zmk/keymap.h>
bool modu_studio_keymap_saved(void) {
    /* A negative result is not permission to persist a draft. */
    return zmk_keymap_check_unsaved_changes()==0;
}
int modu_read_studio_profile(unsigned side) {
    if(side>=MC_SIDES) return -EINVAL;
    const struct zmk_behavior_binding *p=
        zmk_keymap_get_layer_binding_at_idx(0,MC_PROFILE_START+side);
    if(!p) return MC_PROFILE_KEYS;
    struct zmk_behavior_binding b=*p;
    const char *expected=side==MC_LEFT ? DEVICE_DT_NAME(DT_NODELABEL(lball))
                                             : DEVICE_DT_NAME(DT_NODELABEL(rball));
    if(!b.behavior_dev || strcmp(b.behavior_dev,expected) ||
       b.param1>MC_PROFILE_KEYS || b.param2!=0) return MC_PROFILE_KEYS;
    return (int)b.param1;
}
#else
bool modu_studio_keymap_saved(void) { return true; }
int modu_read_studio_profile(unsigned side) {
    return side<MC_SIDES ? MC_PROFILE_KEYS : -EINVAL;
}
#endif
