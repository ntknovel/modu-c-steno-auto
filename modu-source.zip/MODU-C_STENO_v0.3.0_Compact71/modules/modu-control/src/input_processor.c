#include <errno.h>
/* Conversion happens only on the central: left local input and right forwarded input. */
#define DT_DRV_COMPAT modu_trackball_processor
#include <zephyr/device.h>
#include <zephyr/input/input.h>
#include <zephyr/dt-bindings/input/input-event-codes.h>
#include <drivers/input_processor.h>
#include <modu/runtime.h>
static int process(const struct device *dev,struct input_event *event,uint32_t side,uint32_t unused,
                    struct zmk_input_processor_state *state) {
    ARG_UNUSED(dev); ARG_UNUSED(unused); ARG_UNUSED(state);
    if(side>=2) return -EINVAL;
    if(event->type!=INPUT_EV_REL || (event->code!=INPUT_REL_X && event->code!=INPUT_REL_Y))
        return ZMK_INPUT_PROC_CONTINUE;
    bool y=event->code==INPUT_REL_Y;
    struct mc_result result;
    int ret=modu_motion(side,y,event->value,event->sync,&result);
    if(ret<0) return ZMK_INPUT_PROC_STOP;
    if(result.mode==MC_OFF || result.mode==MC_ARROWS) return ZMK_INPUT_PROC_STOP;
    event->value=result.value;
    if(result.mode==MC_SCROLL) event->code=y ? INPUT_REL_WHEEL : INPUT_REL_HWHEEL;
    /* A zero-valued synchronized event still flushes the other axis in this frame. */
    return ZMK_INPUT_PROC_CONTINUE;
}
static const struct zmk_input_processor_driver_api api={.handle_event=process};
DEVICE_DT_INST_DEFINE(0,NULL,NULL,NULL,NULL,POST_KERNEL,CONFIG_KERNEL_INIT_PRIORITY_DEFAULT,&api);
