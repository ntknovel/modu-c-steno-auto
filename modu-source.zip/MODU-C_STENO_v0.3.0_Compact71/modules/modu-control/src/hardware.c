#include <errno.h>
/* Sensor CPI uses upstream attr_set; no direct SPI/register rewrite in this module. */
#include <zephyr/device.h>
#include <zephyr/kernel.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/hci.h>
#include <zephyr/bluetooth/hci_vs.h>
#include <zephyr/sys/byteorder.h>
#include <zephyr/logging/log.h>
#include <modu/runtime.h>
#include "modu-upstream.h"
LOG_MODULE_DECLARE(zmk,CONFIG_ZMK_LOG_LEVEL);
static const int8_t tx_dbm[]={-20,-16,-12,-8,-4,0,2,4,6,8};
static uint16_t requested_cpi=600;
static unsigned requested_tx=MC_TX_DEFAULT,cpi_attempts;
K_MUTEX_DEFINE(hw_lock);
static void cpi_worker(struct k_work *work);
static void tx_worker(struct k_work *work);
K_WORK_DELAYABLE_DEFINE(cpi_work,cpi_worker);
K_WORK_DELAYABLE_DEFINE(tx_work,tx_worker);
static int cpi_to_sensor(uint16_t cpi,struct sensor_value *out) {
    /* The upstream driver defines its own sensor_value unit. Verify encoding rather than guess. */
    struct sensor_value candidates[]={ {.val1=cpi,.val2=0},
        {.val1=cpi/1000,.val2=(cpi%1000)*1000} };
    for(unsigned i=0;i<ARRAY_SIZE(candidates);i++) {
        if(PMW3610_SVALUE_TO_CPI(candidates[i])==cpi) {*out=candidates[i];return 0;}
    }
    return -ENOTSUP;
}
static void cpi_worker(struct k_work *work) {
    ARG_UNUSED(work);
    const struct device *sensor=DEVICE_DT_GET(DT_PHANDLE(DT_NODELABEL(modu_hw_info),sensor));
    uint16_t desired;
    k_mutex_lock(&hw_lock,K_FOREVER); desired=requested_cpi; k_mutex_unlock(&hw_lock);
    struct sensor_value value; int ret=cpi_to_sensor(desired,&value);
    if(!ret) ret=device_is_ready(sensor) ? sensor_attr_set(sensor,SENSOR_CHAN_ALL,
        (enum sensor_attribute)PMW3610_ALT_ATTR_CPI,&value) : -ENODEV;
    k_mutex_lock(&hw_lock,K_FOREVER);
    bool retry=ret<0 && ++cpi_attempts<20;
    k_mutex_unlock(&hw_lock);
    if(ret<0) {
        if(retry) k_work_reschedule(&cpi_work,K_MSEC(500));
        else LOG_WRN("MODU sensor CPI could not be applied: %d (sensor may be absent)",ret);
    } else LOG_INF("MODU sensor CPI applied: %u",desired);
}
void modu_local_cpi(uint16_t cpi) {
    if(cpi<200 || cpi>3200 || cpi%200) return;
    k_mutex_lock(&hw_lock,K_FOREVER);requested_cpi=cpi;cpi_attempts=0;k_mutex_unlock(&hw_lock);
    k_work_reschedule(&cpi_work,K_MSEC(1));
}
static int set_power(uint8_t type,uint16_t handle,int8_t power) {
    struct bt_hci_cp_vs_write_tx_power_level *cp;
    struct net_buf *rsp=NULL;
    struct net_buf *cmd=MODU_HCI_CMD_CREATE(BT_HCI_OP_VS_WRITE_TX_POWER_LEVEL,sizeof(*cp));
    if(!cmd) return -ENOMEM;
    cp=net_buf_add(cmd,sizeof(*cp));
    cp->handle_type=type; cp->handle=sys_cpu_to_le16(handle); cp->tx_power_level=power;
    int ret=bt_hci_cmd_send_sync(BT_HCI_OP_VS_WRITE_TX_POWER_LEVEL,cmd,&rsp);
    if(!ret && rsp && rsp->len>=sizeof(struct bt_hci_rp_vs_write_tx_power_level)) {
        const struct bt_hci_rp_vs_write_tx_power_level *reply=(void *)rsp->data;
        if(reply->status) ret=-EIO;
        else LOG_INF("MODU TX role %u handle %u: requested %d, selected %d dBm",
            type,handle,power,reply->selected_tx_power);
    } else if(!ret) ret=-EIO;
    if(rsp) net_buf_unref(rsp);
    return ret;
}
static void set_connection_power(struct bt_conn *conn,void *context) {
    uint16_t handle;
    if(bt_hci_get_conn_handle(conn,&handle)) return;
    int ret=set_power(BT_HCI_VS_LL_HANDLE_TYPE_CONN,handle,*(int8_t *)context);
    if(ret<0) LOG_WRN("MODU connection TX failed: %d",ret);
}
static void tx_worker(struct k_work *work) {
    ARG_UNUSED(work);
    k_mutex_lock(&hw_lock,K_FOREVER);int8_t p=tx_dbm[requested_tx];k_mutex_unlock(&hw_lock);
    bt_conn_foreach(BT_CONN_TYPE_LE,set_connection_power,&p);
    /* Discovery/recovery stays at the maximum default even when connected links
     * are manually reduced. Passive scanning RX sensitivity is not changed. */
    int8_t discovery=MAX(tx_dbm[MC_TX_DEFAULT],p);
    (void)set_power(BT_HCI_VS_LL_HANDLE_TYPE_ADV,0,discovery);
#if IS_ENABLED(CONFIG_BT_CENTRAL)
    (void)set_power(BT_HCI_VS_LL_HANDLE_TYPE_SCAN,0,discovery);
#endif
}
void modu_local_tx(unsigned index) {
    if(index>=ARRAY_SIZE(tx_dbm)) return;
    k_mutex_lock(&hw_lock,K_FOREVER); requested_tx=index; k_mutex_unlock(&hw_lock);
    k_work_reschedule(&tx_work,K_MSEC(100));
}
static void connected(struct bt_conn *conn,uint8_t error) {
    ARG_UNUSED(conn);if(!error) modu_link_changed();
}
static void disconnected(struct bt_conn *conn,uint8_t reason) {
    ARG_UNUSED(conn);ARG_UNUSED(reason);modu_link_changed();
}
static void secured(struct bt_conn *conn,bt_security_t level,enum bt_security_err error) {
    ARG_UNUSED(conn);ARG_UNUSED(level);if(!error) modu_link_changed();
}
static struct bt_conn_cb callbacks={.connected=connected,.disconnected=disconnected,.security_changed=secured};
void modu_hw_init(void) { bt_conn_cb_register(&callbacks); }
