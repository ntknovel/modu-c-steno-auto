/* Unofficial modification. See root LICENSE; this file has no RTOS dependency. */
#include <modu/core.h>
#include <errno.h>
#include <limits.h>
#include <string.h>
const struct mc_config mc_defaults = {
    .cpi=600, .pointer_pct=100, .scroll_div=24, .arrow_div=40,
    .arrow_ms=40, .mode=MC_MOUSE, .scroll_invert=0, .diagonal=0, .reserved=0
};
static int64_t clamp64(int64_t x, int64_t lo, int64_t hi) {
    return x < lo ? lo : (x > hi ? hi : x);
}
static int64_t abs64(int64_t x) { return x < 0 ? -x : x; }
static void clear_motion(struct mc_core *c, unsigned s) {
    memset(c->motion[s].rem, 0, sizeof(c->motion[s].rem));
    memset(c->motion[s].arrow, 0, sizeof(c->motion[s].arrow));
    c->motion[s].generation++;
}
void mc_init(struct mc_core *c) {
    memset(c, 0, sizeof(*c));
    for (unsigned s=0;s<2;s++) c->config[s]=mc_defaults;
}
bool mc_config_valid(const struct mc_config *c) {
    return c->cpi >= 200 && c->cpi <= 3200 && c->cpi % 200 == 0 &&
           c->pointer_pct >= 25 && c->pointer_pct <= 400 &&
           c->scroll_div >= 1 && c->scroll_div <= 200 &&
           c->arrow_div >= 1 && c->arrow_div <= 500 &&
           c->arrow_ms >= 20 && c->arrow_ms <= 500 &&
           c->mode <= MC_OFF && c->scroll_invert <= 1 &&
           c->diagonal <= 1 && c->reserved == 0;
}
static int base_mode(const struct mc_core *c, unsigned s) {
    const struct mc_motion *m=&c->motion[s];
    return m->profile_seen && m->profile_mode<MC_PROFILE_KEYS && !m->manual_mode
               ? m->profile_mode : c->config[s].mode;
}
int mc_mode(const struct mc_core *c, unsigned s) {
    if (s>=2) return -EINVAL;
    unsigned n=c->motion[s].held;
    return n ? c->motion[s].holds[n-1].mode : base_mode(c,s);
}
int mc_profile(struct mc_core *c,unsigned s,unsigned mode) {
    if(s>=2 || mode>MC_PROFILE_KEYS) return -EINVAL;
    struct mc_motion *m=&c->motion[s];
    if(m->profile_seen && m->profile_mode==mode) return 0;
    int before=mc_mode(c,s);
    m->profile_seen=true; m->profile_mode=(uint8_t)mode; m->manual_mode=false;
    if(before!=mc_mode(c,s)) clear_motion(c,s);
    return 0;
}
int mc_restore_manual(struct mc_core *c, unsigned s, bool manual) {
    if(s>=MC_SIDES) return -EINVAL;
    int before=mc_mode(c,s);
    c->motion[s].manual_mode=manual;
    if(before!=mc_mode(c,s)) clear_motion(c,s);
    return 0;
}
int mc_hold(struct mc_core *c, unsigned s, uint64_t token,
            unsigned mode, bool pressed) {
    if (s>=2 || (pressed && mode>MC_OFF)) return -EINVAL;
    struct mc_motion *m=&c->motion[s];
    int before=mc_mode(c,s); unsigned i;
    for (i=0;i<m->held;i++) if(m->holds[i].token==token) break;
    if (pressed) {
        if (i<m->held) return m->holds[i].mode==mode ? 0 : -EALREADY;
        if (m->held==MC_HOLD_SLOTS) return -ENOSPC;
        m->holds[m->held++]=(struct mc_hold){.token=token,.mode=(uint8_t)mode};
    } else if (i<m->held) {
        memmove(&m->holds[i], &m->holds[i+1], (m->held-i-1)*sizeof(m->holds[0]));
        m->held--;
    }
    if (before!=mc_mode(c,s)) clear_motion(c,s);
    return 0;
}
static int change_number(uint16_t *dst, unsigned command, uint32_t value,
                          unsigned low, unsigned high, unsigned step,
                          unsigned def, bool inverse) {
    int64_t v=*dst;
    switch(command) {
    case MC_SET: if(value<low || value>high) return -ERANGE; v=value; break;
    case MC_INC: v+=inverse ? -(int)step : (int)step; break;
    case MC_DEC: v+=inverse ? (int)step : -(int)step; break;
    case MC_RESET: v=def; break;
    case MC_MAX: v=inverse ? low : high; break;
    default: return -EINVAL;
    }
    *dst=(uint16_t)clamp64(v,low,high); return 0;
}
int mc_change(struct mc_core *c, unsigned s, unsigned kind,
              unsigned command, uint32_t value) {
    if(s>=2) return -EINVAL;
    struct mc_config next=c->config[s]; int ret=0;
    int before=mc_mode(c,s);
    bool manual=false;
    switch(kind) {
    case MC_KIND_MODE:
        if(value>MC_OFF) return -ERANGE;
        next.mode=(uint8_t)value; manual=true; break;
    case MC_KIND_CYCLE: {
        if(command!=MC_SET || value>MC_CYCLE_MOUSE_SCROLL) return -EINVAL;
        int mode=base_mode(c,s); /* Cycle the base, not a held temporary override. */
        if(value==MC_CYCLE_NEXT) mode=mode==MC_OFF ? MC_MOUSE : (mode+1)%3;
        else if(value==MC_CYCLE_PREVIOUS) mode=mode==MC_OFF ? MC_ARROWS : (mode+2)%3;
        else mode=mode==MC_MOUSE ? MC_SCROLL : MC_MOUSE;
        next.mode=(uint8_t)mode; manual=true; break;
    }
    case MC_KIND_CPI:
        if(command==MC_SET && value%200) return -ERANGE;
        ret=change_number(&next.cpi,command,value,200,3200,200,600,false); break;
    case MC_KIND_POINTER:
        ret=change_number(&next.pointer_pct,command,value,25,400,25,100,false); break;
    case MC_KIND_SCROLL:
        ret=change_number(&next.scroll_div,command,value,1,200,2,24,true); break;
    case MC_KIND_ARROW:
        ret=change_number(&next.arrow_div,command,value,1,500,4,40,true); break;
    case MC_KIND_RATE:
        ret=change_number(&next.arrow_ms,command,value,20,500,5,40,true); break;
    case MC_KIND_INVERT:
        if(value>1) return -ERANGE;
        next.scroll_invert=(uint8_t)value; break;
    case MC_KIND_DIAGONAL:
        if(value>1) return -ERANGE;
        next.diagonal=(uint8_t)value; break;
    case MC_KIND_RESET: next=mc_defaults; manual=true; break;
    default: return -ENOTSUP;
    }
    if(ret) return ret;
    bool changed=memcmp(&next,&c->config[s],sizeof(next))!=0;
    c->config[s]=next;
    if(manual) c->motion[s].manual_mode=true;
    if(changed || before!=mc_mode(c,s)) clear_motion(c,s);
    return 0;
}
static int32_t scaled(int64_t *rem, int64_t add, int divisor, int limit) {
    int64_t total=clamp64(*rem+add,-(int64_t)divisor*limit*2,(int64_t)divisor*limit*2);
    int64_t quotient=total/divisor;
    /* Limit one report without retaining a runaway backlog. Keep sub-unit precision. */
    *rem=total%divisor;
    return (int32_t)clamp64(quotient,-limit,limit);
}
int mc_feed(struct mc_core *c,unsigned s,unsigned axis,int32_t value,
            bool sync,struct mc_result *out) {
    if(s>=2 || axis>1 || !out) return -EINVAL;
    memset(out,0,sizeof(*out));
    const struct mc_config *cfg=&c->config[s]; struct mc_motion *m=&c->motion[s];
    out->mode=(uint8_t)mc_mode(c,s);
    if(out->mode==MC_MOUSE) {
        out->value=scaled(&m->rem[axis],(int64_t)value*cfg->pointer_pct,100,32767);
    } else if(out->mode==MC_SCROLL) {
        int sign=(axis==1 ? -1 : 1)*(cfg->scroll_invert ? -1 : 1);
        out->value=sign*scaled(&m->rem[axis],value,cfg->scroll_div,127);
    } else if(out->mode==MC_ARROWS) {
        m->arrow[axis]=clamp64(m->arrow[axis]+value,-(int64_t)cfg->arrow_div*4,
                              (int64_t)cfg->arrow_div*4);
        if(!sync) return 0;
        int chosen=abs64(m->arrow[0])>=abs64(m->arrow[1]) ? 0 : 1;
        for(unsigned a=0;a<2;a++) {
            if(!cfg->diagonal && a!=(unsigned)chosen) continue;
            int64_t steps=m->arrow[a]/cfg->arrow_div;
            if(!steps) continue;
            unsigned dir=a==0 ? (steps<0 ? 2:3) : (steps<0 ? 0:1);
            out->arrows[dir]=(uint8_t)abs64(steps);
            m->arrow[a]%=cfg->arrow_div;
            if(!cfg->diagonal) m->arrow[1-a]=0;
        }
    }
    return 0;
}

void mc_cancel_holds(struct mc_core *c) {
    for (unsigned s=0;s<2;s++) {
        c->motion[s].held=0;
        clear_motion(c,s);
    }
}
