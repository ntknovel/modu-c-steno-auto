/* Unofficial MODU-C extension; see repository LICENSE. */
#pragma once
#define MC_MOUSE 0
#define MC_SCROLL 1
#define MC_ARROWS 2
#define MC_OFF 3
#define MC_SET 0
#define MC_INC 1
#define MC_DEC 2
#define MC_RESET 3
#define MC_MAX 4
#define MC_KIND_MODE 0
#define MC_KIND_HOLD 1
#define MC_KIND_CPI 2
#define MC_KIND_POINTER 3
#define MC_KIND_SCROLL 4
#define MC_KIND_ARROW 5
#define MC_KIND_RATE 6
#define MC_KIND_INVERT 7
#define MC_KIND_DIAGONAL 8
#define MC_KIND_TX 9
#define MC_KIND_RESET 10
#define MC_KIND_SYNC 11
#define MC_LEFT 0
#define MC_RIGHT 1
#define MC_BOTH 2
/* TX values are indexed, not unsigned representations of negative dBm. */
#define MC_TX_MINUS_20 0
#define MC_TX_MINUS_16 1
#define MC_TX_MINUS_12 2
#define MC_TX_MINUS_8 3
#define MC_TX_MINUS_4 4
#define MC_TX_0 5
#define MC_TX_PLUS_2 6
#define MC_TX_PLUS_4 7
#define MC_TX_PLUS_6 8
#define MC_TX_PLUS_8 9
/* Default/recovery policy for MODU-C nRF52840; keep MC_TX_0 as actual 0 dBm. */
#define MC_TX_MAX_INDEX MC_TX_PLUS_8
#define MC_TX_DEFAULT MC_TX_MAX_INDEX

/* v0.1.4: on-key cycling; two nonphysical Studio configuration slots. */
#define MC_KIND_CYCLE 12
#define MC_KIND_PROFILE 13
#define MC_CYCLE_NEXT 0
#define MC_CYCLE_PREVIOUS 1
#define MC_CYCLE_MOUSE_SCROLL 2
#define MC_PROFILE_KEYS 4
