#pragma once
#include <modu/core.h>
int modu_change(unsigned side,unsigned kind,unsigned command,uint32_t value);
int modu_hold(unsigned side,uint64_t token,unsigned mode,bool pressed);
int modu_motion(unsigned side,unsigned axis,int32_t value,bool sync,struct mc_result *out);
int modu_tx_change(unsigned side,unsigned command,uint32_t value);
int modu_sync(void);
void modu_link_changed(void);
void modu_remote_cpi(unsigned side,uint16_t cpi);
void modu_local_cpi(uint16_t cpi);
void modu_local_tx(unsigned index);
void modu_hw_init(void);

/* Returns a validated Base-layer sensor setting; never invokes arbitrary bindings. */
int modu_read_studio_profile(unsigned side);
bool modu_studio_keymap_saved(void);
