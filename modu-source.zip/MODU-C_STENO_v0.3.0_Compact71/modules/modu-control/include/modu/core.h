/* Platform-independent logic, exercised by tests/test_core.c. */
#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <dt-bindings/zmk/modu_control.h>
#define MC_SIDES 2
#define MC_HOLD_SLOTS 16
#define MC_VIRTUAL_START 61
#define MC_VIRTUAL_COUNT 8
#define MC_PROFILE_START 69
#define MC_PROFILE_COUNT 2
#define MC_KEY_COUNT 71
struct mc_config {
    uint16_t cpi, pointer_pct, scroll_div, arrow_div, arrow_ms;
    uint8_t mode, scroll_invert, diagonal, reserved;
};
struct mc_hold { uint64_t token; uint8_t mode; };
struct mc_motion {
    int64_t rem[2], arrow[2];
    struct mc_hold holds[MC_HOLD_SLOTS];
    uint32_t generation;
    uint8_t held;
    uint8_t profile_mode;
    bool profile_seen, manual_mode;
};
struct mc_core { struct mc_config config[2]; struct mc_motion motion[2]; };
struct mc_result { uint8_t mode; int32_t value; uint8_t arrows[4]; };
extern const struct mc_config mc_defaults;
void mc_init(struct mc_core *core);
bool mc_config_valid(const struct mc_config *config);
int mc_profile(struct mc_core *core, unsigned side, unsigned mode);
int mc_mode(const struct mc_core *core, unsigned side);
int mc_restore_manual(struct mc_core *core, unsigned side, bool manual);
int mc_change(struct mc_core *core, unsigned side, unsigned kind,
              unsigned command, uint32_t value);
int mc_hold(struct mc_core *core, unsigned side, uint64_t token,
            unsigned mode, bool pressed);
int mc_feed(struct mc_core *core, unsigned side, unsigned axis,
            int32_t value, bool sync, struct mc_result *out);

void mc_cancel_holds(struct mc_core *core);
