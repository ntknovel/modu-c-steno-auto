/* SPDX-License-Identifier: MIT
 * MODU physical (Compact71) -> immutable Cornix engine coordinate.
 * Only switch positions 0..60 are STENO inputs. 61..70 are trackball controls.
 */
#pragma once
#include <stdint.h>
static inline uint32_t modu_steno_engine_position(uint32_t physical) {
    static const uint32_t positions[71] = {
        50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 32, 33, 34, 35, 36, 37, 38, 39, 40, 47, 48, 49, 41, 42, 43, 44, 45, 46, 30, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX
    };
    return physical < 71 ? positions[physical] : UINT32_MAX;
}
