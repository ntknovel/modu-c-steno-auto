# v0.1.4 검사 결과 — 2026-09-08

> v0.1.4 당시 기록입니다. 현재 v0.1.5에서는 원형 확장을 제거하고 기본 Studio용 사각 십자 배치를 사용합니다. 현재 안내: `REVIEW_v0.1.5_KO.md`.

**소스·호스트/브라우저 모의 검사 통과. 전체 ZMK 컴파일 및 실제 Studio/USB/BLE/센서 검증 미실시.**

| 검사 | 결과 |
|---|---|
| Python unittest | 115개 통과 (기존 93 + profile/cycle host 14 + 소스 계약 8) |
| 순수 C 상태/변환 | 180,378 assertion, 엄격 경고·ASan/UBSan 통과 |
| 원형 확장 Chromium DOM | 12개 통과 |
| 별도 소스 미리보기 Chromium | 9개 통과 |
| 원본 보존·기하·77위치 | 통과. 추가 B의 표시 위치만 원본 보존 예외 |
| 기존 HEX/UF2 selftest | 합성 파일로 통과. 장치용 UF2 생성 아님 |
| 라이선스/워크플로 | 기존 보존 검사 통과 |

모의 검사에서는 실제 core/runtime/input_processor/studio_profile C를 컴파일하지만 Zephyr API, keymap getter, 전송, 장치는 대역입니다. behavior.c/hardware.c를 실제 Zephyr 헤더로 컴파일한 결과가 아닙니다. 원형 확장은 실제 Studio 구조를 모사한 DOM에서만 클릭/렌더 재생성 등을 검사했고 기기에 연결하지 않았습니다.

115개 외 180,378은 조건 확인 횟수이며 독립 테스트 수가 아닙니다. 브라우저 총 21개를 펌웨어 테스트라고 합산하지 않습니다. 확인한 현재 main API 문서는 정확한 pinned 소스 검증이 아닙니다.

이번 실제 기록: `docs/review_logs/v0.1.4_final_tests.txt`, `docs/review_logs/v0.1.4_browser.txt`, `docs/LOCAL_TEST_LOG.txt`.
설계/제한: `docs/REVIEW_v0.1.4_KO.md`. 기존 검증 문서는 `VALIDATION_v0.1.3_ARCHIVE.md` 등으로 보존했습니다.

남은 확인: Actions 양쪽 전체 compile/link·generated EDT·용량·UF2 생성, 실제 Studio keymap 77위치/marker 편집/저장/Discard, 기존 저장 키맵 이전, 좌우 CPI/RF/트랙볼/재연결. 빌드 성공 후에도 실기 확인이 필요합니다.
