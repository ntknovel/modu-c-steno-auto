# MODU-C v0.1.2 — 기본 무선 송신 출력 최대

날짜: 2026-09-08  
기준: 제공한 v0.1.1 소스 ZIP

## 적용한 변경

**좌우 BLE 송신 출력 기본 요청을 +8 dBm(최대)으로 통일했습니다.** 키맵·USB Studio·트랙볼 센서 CPI·스크롤/방향키 설정은 변경하지 않았습니다.

| 상황 | v0.1.2 소스의 처리 |
|---|---|
| 왼쪽/오른쪽 부팅 | 공통 빌드 설정에서 `CONFIG_BT_CTLR_TX_PWR_PLUS_8=y` 선택 |
| 제어 모듈 초기 상태·지연 시작 작업 | `MC_TX_DEFAULT` = `MC_TX_PLUS_8` |
| 재연결·연결 해제·보안 상태 변경 | 각 장치가 최대 기본값 복구를 요청, 중앙에서 좌우 재동기화 |
| RF 기본값 복원 키 | 해당 장치 또는 양쪽에 최대 요청 |
| 광고·능동 검색 송신 | 연결 출력이 수동으로 낮아져도 최대 기본 요청 유지 |
| RF 수동 감소·증가·직접 지정 | 기존 방식 유지. 최대에서 증가는 최대에 머묾 |
| 수동 지정 0 dBm | `MC_TX_0`의 의미는 그대로 0 dBm. 기본값 상수와 분리 |
| 수동 출력 변경의 저장 | 세션 한정 유지. 재연결·재부팅 시 최대로 복구 |

단순히 설명의 기본값만 바꾼 것이 아닙니다. 빌드 시작 기본값과 런타임 초기값, 기본값 복원, 재연결 복구, 검색·광고 출력, Studio 매개변수 표시를 함께 바꿨습니다.

## 변경한 주요 파일

- `modules/modu-control/modu.conf`: 좌우 공통 컨트롤러 기본값 +8 dBm.
- `modules/modu-control/include/dt-bindings/zmk/modu_control.h`: `MC_TX_MAX_INDEX`, `MC_TX_DEFAULT` 상수 추가. 기존 숫자 매핑 보존.
- `modules/modu-control/src/runtime.c`: 초기화·시작·연결 복구·RF RESET에서 최대 사용. 최대 범위 상수로 제한.
- `modules/modu-control/src/hardware.c`: 초기 요청과 광고/검색 송신 하한을 최대 기본값에 맞춤.
- `modules/modu-control/src/behavior.c`: Studio의 기본값 표기를 +8 dBm으로 이동.
- `scripts/check_built.py`: 실제 컴파일 결과의 `.config`에서 `CONFIG_BT_CTLR_TX_PWR_PLUS_8=y`와 `CONFIG_BT_CTLR_TX_PWR=8` 확인. 둘 중 하나가 빠지면 설치용 포장 전에 실패 처리.
- `tests/test_runtime_host.c`, `tests/test_runtime_host.py`, `tests/test_tx_defaults.py`: 최대 기본값 회귀 검사 추가.
- 현재 README·HTML 가이드·제어 설명·기술 문서·검사 결과 갱신. 이전 버전 검토 문서는 과거 기록으로 보존.

## 실제 실행한 검사

| 검사 | 결과 | 범위 |
|---|---|---|
| 런타임 호스트 검사 | 20개 통과 | 기존 12개 + 최대 기본값 관련 8개. 실제 runtime.c/core.c, 모의 스케줄러·전송·저장 |
| 최대값 정책·컴파일 설정 검사기 | 8개 통과 | 소스의 기본값·Studio 표시·검색 하한, 합성 `.config` 정상/실패 사례 |
| DTS 생성기 회귀 검사 | 18개 통과 | 합성 장치 트리 fixture, 기존 검사 유지 |
| Python unittest 합계 | **46개 통과** | 실제 무선 하드웨어 검사가 아님 |
| 순수 C 핵심 검사 | **180,378 assertions 통과** | C11 엄격 경고, ASan+UBSan 사용. 독립 테스트 18만 개라는 의미 아님 |
| 기존 정적 보존 검사 | 통과 | 원래 67위치·Base/Fn, 가상 키, 보드/의존 버전, 라이선스·워크플로 |
| HEX/UF2 자체 검사 | 통과 | 합성 파일의 안전 검사. 설치용 UF2 생성 아님 |
| Python/YAML·워크플로 사본 | 통과 | 문법, YAML 파싱, HTML/텍스트 워크플로 복사본 동일성 |
| v0.1.1 대비 키맵/보드 보존 | 통과 | `config/` 전체, `build.yaml`, 기존 빌드 워크플로 바이트 보존 |

실행 기록은 `docs/LOCAL_TEST_LOG.txt`에 있습니다. 이전 v0.1.1 기록은 `docs/review_logs/v0.1.1_local_tests.txt`에 보존했습니다.

## 검증하지 않은 범위

이번에도 전체 ZMK/Zephyr ARM 컴파일·GitHub Actions 실행·UF2 생성·USB Studio 연결·실제 RF 출력 측정을 수행하지 않았습니다. 모든 출력 숫자는 **설정/요청값**이며 컨트롤러의 실제 적용과 무선 연결 안정성을 실측한 것이 아닙니다.

특히 hardware.c를 실제 Zephyr에 연결해 컴파일한 것이 아니며, HCI 명령 실패/지원 여부는 빌드 및 장치에서 확인해야 합니다. 광고·검색에 대한 검사는 소스 정책 검사이지 실제 전파 측정이 아닙니다. 수신기 감도나 USB 신호 세기를 변경하는 기능도 아닙니다.

## Codespaces 없이 적용

이번 ZIP은 전체 소스 패키지입니다. 압축을 푼 후 **바깥 포장 폴더가 아닌 내부 파일 전체**를 기존 개인 시험용 GitHub 저장소의 같은 경로에 올립니다. 삭제할 소스는 없습니다. 커밋 메시지 예:

```text
Set both halves to maximum default TX power (v0.1.2)
```

기존 `Build MODU-C Studio` 워크플로로 빌드합니다. 양쪽 Compile 및 Package까지 성공한 후 생성되는 `modu_left.uf2`, `modu_right.uf2`를 각각 설치해야 합니다. 이 ZIP 자체는 UF2가 아닙니다. 출력 최대화를 위해 Studio에서 별도 키를 새로 배정할 필요는 없으며 기존 키맵을 초기화할 필요도 없습니다. 기존 정상 좌우 UF2를 보관하고 업데이트하세요.

## 공식 설정 근거

ZMK 공식 Connection Issues 문서의 Unreliable/Weak Connection 절은 nRF52840의 `CONFIG_BT_CTLR_TX_PWR_PLUS_8=y` 설정과 분할 키보드 양쪽 연결에서의 사용을 안내합니다. 이 문서를 확인한 것은 제공된 펌웨어 전체 컴파일을 대신하지 않습니다.

https://zmk.dev/docs/troubleshooting/connection-issues#unreliableweak-connection
