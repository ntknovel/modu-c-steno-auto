# Compact71 / v0.3.0

61개 물리 위치 + 방향 출력 8개 + Ball setting 2개를 유지합니다. 좌표는 v0.2.0과 같습니다. `docs/STENO_MAPPING_KO.md`와 루트 미리보기가 현재 배정입니다. 예전 저장 키맵은 삭제하지 않고, 이 버전의 keymap 설정만 `modusteno1` 이름으로 분리했습니다. 자세한 내용은 README.md와 VALIDATION.md를 참조하세요.
