# MODU-C v0.1.4 — B 배치·Studio 트랙볼 설정·좌우 모드 순환

> v0.1.4 당시 기록입니다. 현재 v0.1.5에서는 원형 확장을 제거하고 기본 Studio용 사각 십자 배치를 사용합니다. 현재 안내: `REVIEW_v0.1.5_KO.md`.

검토/수정일: 2026-09-08. 기준: 첨부된 v0.1.3 소스 ZIP.

**수정 소스와 브라우저 보조 확장입니다. UF2, 전체 ZMK 빌드 성공, 실제 Studio/센서 작동 검증을 뜻하지 않습니다.**

## 1. 요청과 결과

| 요청 | 소스에 반영한 변경 |
|---|---|
| 추가 B를 N 옆으로 | 논리 66 표시를 (7,3), N(42)의 바로 왼쪽으로 이동. 일반 B(41)와 원래 행렬·Base/Fn 배정 보존 |
| 방향키 외 볼 설정 항목 | 가상 방향 67..74 유지, 센서 모드 설정 자리 75/76 추가. 총 77 논리 위치 |
| 클릭하여 Mouse/Wheel/Arrows 선택 | Base의 전용 `Ball setting` 동작 값으로 읽는 펌웨어 경로 추가 |
| 볼을 원형으로 표시 | 공식 웹 Studio용 선택적 로컬 브라우저 확장. 기본 Studio 단독이면 사각형 |
| 좌우 물리 모드 토글 | `lcycle`/`rcycle` 동작, 기본 3단계 순환, 역순·2단계 옵션 |

기존 67개 안에 빈 자리 6개가 있습니다. 77개의 물리 스위치가 생기는 것은 아닙니다. 75/76은 볼의 클릭 스위치나 방향 이벤트가 아니라 **설정 전용 위치**입니다. 화면에 위치를 표시했다고 지원하지 않던 센서/핀/유닛을 새로 지원하는 것은 아닙니다.

## 2. 정확한 사용 방법

원래 Base(layer ID 0)를 열고 75(왼쪽), 76(오른쪽)를 선택합니다. 값은 각각 `MODU Left/Right: Ball setting (Base only)`의 Mouse, Wheel / scroll, Arrow keys, Disabled, Follow mode keys (last saved) 중 하나입니다. Studio Save로 유지합니다. Fn/Controls 쪽 두 자리는 `&trans`를 유지합니다. 원래 Base를 삭제하지 마세요. 표시 이름이나 순서를 바꿔도 읽는 ID는 0입니다.

실제 Studio에서 값이 변경되어 펌웨어 키맵에 전달되면 다음 볼 이동/모드 조작 또는 대기 방향 입력 작업에서 반영됩니다. 센서 모드 설정 키를 따로 물리적으로 누를 필요는 없습니다. 편집 초안도 일시 적용될 수 있지만 이 모듈이 Studio의 다른 미저장 키맵까지 자동 저장하지 않습니다. 저장은 Studio Save, 초안 복원은 Studio Discard를 그대로 사용합니다.

잘못된 동작(예: &kp, bootloader, 반대쪽 Ball setting), 범위 밖 값, 불필요한 두 번째 인수는 임의 실행하지 않고 Follow mode keys로 취급합니다. 이 두 자리에는 일반 키/CPI/모드 명령을 배정하지 마세요. 실제 CPI/무선값을 바꾸는 키는 기존 전용 제어 동작입니다.

기본 순환키는 **Fn을 먼저 누른 채 왼쪽 Ctrl 위치 유지 → LANG1(왼쪽) 또는 Enter(오른쪽)**입니다. 논리 위치 60/64이며 실제 Base의 LANG1/Enter는 보존했습니다. Studio에서 다른 편한 물리 키로 재배정할 수 있습니다.

| 순환 매개변수 | 실행 순서 |
|---|---|
| `Mouse > Wheel > Arrows` (기본) | 마우스 → 휠 → 방향키 → 마우스 |
| `Mouse > Arrows > Wheel` | 마우스 → 방향키 → 휠 → 마우스 |
| `Mouse <> Wheel` | 마우스 ↔ 휠 |

기본 3단계 순환에는 Disabled를 끼우지 않았습니다. Disabled에서 정방향을 누르면 Mouse, 역방향이면 Arrows로 복귀합니다. 한쪽 순환키는 반대 센서 모드를 바꾸지 않습니다.

## 3. Studio와 물리키가 서로 덮어쓰지 않는 규칙

우선순위는 **현재 눌린 임시 모드 → 마지막 물리 모드/순환키의 세션 선택 → Studio 기준 모드**입니다.

Studio 기준값은 변경을 감지했을 때만 수용합니다. 따라서 볼을 굴릴 때마다 같은 Mouse 값이 재적용되어 순환키로 고른 Wheel이 되돌아가는 문제가 없습니다. 다른 Studio 기준값을 고르면 새 기준이 적용됩니다. 임시 Hold 중 순환은 임시 모드가 아닌 뒤의 기본 실행 모드를 바꾸며, Hold를 놓으면 새 선택으로 돌아갑니다.

**원형 키는 실시간 모드 계기판이 아닙니다.** 물리 키로 Wheel로 바꾸어도 원형에는 저장/편집한 Mouse 기준값이 남을 수 있습니다. 같은 기준값을 다시 클릭하는 것만으로는 물리 선택을 재설정하지 않습니다. 즉시 같은 모드로 되돌리려면 기존 직접 모드 지정키를 쓰거나 Studio에서 다른 기준값으로 바꾼 후 원하는 값으로 돌리세요.

명시적으로 Mouse/Wheel/Arrows를 지정하면 재부팅 후 그 모드가 우선합니다. 물리 순환키의 마지막 모드를 이어 쓰려면 Follow mode keys를 고릅니다. 이때 기존 `modu_control/v1`의 mode 값과 약 1.2초 지연 저장을 사용합니다. 새 Studio 기준값 때문에 이 레코드의 mode를 덮어쓰지 않습니다. 임시 상태/기준 캐시는 저장하지 않고 기존 저장 형식과 버전은 보존했습니다.

CPI는 항상 기존 좌우 센서 설정 경로이고, 모드 기준과 무관하게 유지됩니다. 양쪽 RF 최대 +8 dBm 시작/복원 정책은 변경하지 않았습니다.

## 4. 구현 경로

`config/modu.json` 및 `config/info.json`: 66 기하 변경, 방향키 기하 재배치, 75/76 기하 추가. 원래 스캔의 행/열 번호는 변경하지 않았습니다.

`config/modu.keymap`: Base/Fn 첫 67바인딩 보존. Base에 &lball MC_MOUSE / &rball MC_MOUSE 추가. 제어 레이어 60/64에 &lcycle MC_CYCLE_NEXT / &rcycle MC_CYCLE_NEXT.

`config/modu-controls.dtsi` 및 `behavior.c`: 좌우 Ball setting/Cycle 네 동작과 metadata. 공개 동작은 24→28개. Ball setting의 key-pressed는 부작용 없는 marker이며 임의 키 이벤트를 만들지 않습니다.

`studio_profile.c`: 중앙에서 `zmk_keymap_get_layer_binding_at_idx(0, 75+side)`로 실제 keymap binding을 읽고 대상 동작/인수 검증. 주변 장치는 getter를 호출하지 않는 stub. keymap setter나 save 호출이 없습니다.

`core.c`: profile cache/manual override를 motion 상태에 분리. 기존 persistent config 구조 불변. mode cycle/hold 중첩/설정 변경 시 오래된 이동량 해제.

`runtime.c`: 이동·모드 키·방향 펄스 처리 전에 profile refresh. 읽기 후 상태 mutex 안에서 전환. 새 profile 때문에 유지 중인 방향 키가 남지 않도록 기존 generation/pulse release 처리 사용. 센서 polling용 타이머를 추가하지 않았습니다.

`prepare_build.py`/`check_integration.py`/`validate.py`: 77위치 transform/레이아웃 검사, 원본 보존 예외는 추가 B 기하 하나만 허용. 왼쪽 preflight에서 실제 pinned keymap header의 getter 존재 여부 확인. 실제 컴파일 시 센서 경로 검사는 그대로 유지합니다.

## 5. 원형 브라우저 확장

표준 물리 레이아웃 프로토콜은 w/h/x/y/r/rx/ry 기하를 전달하고 개별 원형 속성은 없습니다. 따라서 firmware에 존재하지 않는 shape 속성을 넣거나 가짜 screenshot을 실제 Studio라고 하지 않았습니다.

`studio-extension/`는 Manifest V3 로컬 확장으로 공식 웹 Studio의 77위치+고유 MODU 좌표가 일치할 때만 75/76번 버튼을 원형으로 스타일링합니다. 본래 버튼을 새 가짜 버튼으로 바꾸거나 클릭 이벤트를 가로채지 않습니다. 편집기, WebSerial, Save/Discard, 키맵은 원래 Studio가 처리합니다. 확장은 장치/네트워크/저장소 API를 사용하지 않습니다. zmk.studio 페이지 DOM 접근은 선언되어 있습니다.

Chrome/Edge에서 확장 관리 → 개발자 모드 → 압축해제된 확장 로드로 `manifest.json`이 들어 있는 폴더를 선택합니다. 이것은 브라우저 개발자 모드이지 GitHub Codespaces가 아닙니다. 확장을 끄면 같은 설정이 사각형으로 보입니다. 데스크톱 네이티브 앱에는 적용되지 않습니다. 원형으로 안 보이면 무리하게 DOM 선택 조건을 풀지 말고 기본 사각형 설정으로 사용하세요.

공식 웹 UI 구조 변경 시 미적용될 수 있습니다. 현재 main의 PhysicalLayout/Key 소스 구조와 합성 DOM에 맞춘 코드이며 실제 배포 사이트 + 키보드 연결 시험은 아닙니다. HTML/PNG의 전체 색상·한글·오른쪽 패널은 설명용 미리보기로, 이 확장이 Studio 전체를 그 디자인으로 바꾸지는 않습니다.

## 6. 실행한 검사

| 검사 | 결과 | 범위 |
|---|---:|---|
| Python unittest | 115개 통과 | 기존 93 + 실제 core/runtime/profile reader를 사용하는 호스트 14 + 소스/패키지 계약 8 |
| 순수 C core | 180,378 assertion 통과 | GCC C11, 엄격 경고, ASan/UBSan. 독립 테스트 케이스 수가 아님 |
| 확장 DOM | 12개 통과 | 두 원형, 원래 클릭 전달, 클래스/레이아웃 재생성, 배율 변경, 불일치 거부, 무오류/무네트워크 |
| 독립 미리보기 | 9개 통과 | 77키, 원형 2개, B 위치, 좌우 선택, 순환과 기준 분리, 탭/배정 표시 |
| 기존 파일 검사 | 통과 | 원본 행렬/Base/Fn 보존, RF 설정, HEX/UF2 합성 검사, 라이선스·워크플로 |

신규 host 14개는 정/역/2단계 순환, 좌우 분리, 임시 모드 중 순환, Disabled 복귀, Mouse/Wheel/Arrow 기준 적용, 잘못된 marker 무시, 편집 복원, 수동 모드와 기준 충돌 방지, 재부팅/Follow 복원, Hold 중 기준 수정, pending arrow 해제, 무단 저장·실행 없음, Base ID 제한을 다룹니다. OS/키맵 getter/RTOS/전송/센서는 대역입니다.

명령: `python scripts/validate.py`; `python scripts/selftest.py`; `python -m unittest discover -s tests -p 'test_*.py' -v`; workflow의 native core 명령. 브라우저 검사는 Playwright+Chromium이 있는 환경에서 `python scripts/test_studio_extension_browser.py`를 별도 실행했습니다. 브라우저 도구는 Actions의 펌웨어 필수 의존성이 아닙니다.

## 7. 남은 검증과 사용 제한

정확한 고정 upstream/Zephyr 소스의 전체 compile/link, 펌웨어 크기, 실제 getter ABI/저장된 keymap의 75→77 마이그레이션, 실제 Studio marker metadata 편집/저장/Discard, USB 연결, 센서 CPI·RF 적용·좌우 재연결·장착 방향은 미검증입니다. pinned 커밋은 바꾸지 않았고 조회 가능한 현재 main을 pinned와 같은 것으로 간주하지 않습니다.

기존 Studio 저장 키맵을 쓰는 경우 새 Controls 기본 순환키가 자동으로 덮어써진다고 보장하지 않습니다. 75/76의 전용 동작과 60/64 순환 배정을 확인하고 필요한 위치만 편집하세요. 전체 초기화를 무조건 요구하지 않습니다.

설정 슬롯은 Base 전용입니다. 레이어별 센서 모드 편집기는 아니며 현재 CPI/RF 상태 표시·슬라이더도 추가하지 않았습니다. 방향키 모드는 기존 짧은 키 누름/해제 방식이며 연속 hold 방식은 아닙니다.

Codespaces 없이 이번 소스 전체를 본인의 시험 저장소에 업로드하고 기존 Build MODU-C Studio를 실행합니다. Static/native뿐 아니라 양쪽 Compile와 Package 모두 성공해야 합니다. 기존 정상 UF2를 보관하고 좌우 모두 업데이트합니다. 이 소스 ZIP에 설치용 UF2는 없습니다.

## 확인한 공개 원문

- Physical key geometry: https://zmk.dev/docs/hardware-integration/physical-layouts
- Studio supported functions/save: https://zmk.dev/docs/features/studio
- Current renderer (not an installed device test): https://github.com/zmkfirmware/zmk-studio/blob/main/src/keyboard/PhysicalLayout.tsx
- Button renderer: https://github.com/zmkfirmware/zmk-studio/blob/main/src/keyboard/Key.tsx
- Current keymap getter implementation, NOT pinned verification: https://github.com/zmkfirmware/zmk/blob/main/app/src/keymap.c
- Local extension loading: https://developer.chrome.com/docs/extensions/get-started/tutorial/hello-world
