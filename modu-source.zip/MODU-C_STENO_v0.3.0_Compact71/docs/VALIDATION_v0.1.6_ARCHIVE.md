# v0.1.6 검사 결과 — 2026-09-08

**Alt·Ctrl 아래 십자 배치에 대한 소스·호스트·합성 DTS·독립 HTML 검사 통과. 전체 ZMK 빌드·기기 연결은 미실시.**

| 검사 | 결과 |
|---|---|
| Python unittest | 132개 통과; 그중 십자 배치/생성 DTS 검사17개 |
| 순수 C core | 180,378 assertion, 엄격 경고·ASan/UBSan 통과 |
| 독립 HTML Chromium | 23개 통과; 실제 Studio 연결 시험 아님 |
| 정적/기존 HEX·UF2 합성 검사 | 통과 |
| v0.1.5 주요 파일 보존 | 39개 바이트 동일, 첫67 JSON 항목/전체77 행렬주소 보존 |
| 워크플로·HTML 복사본 | 일치 |

전체 높이10u→8u, 폭14u 유지. 실제 JSON에서 생성되는 key_physical_attrs의77개 순서·기하를 좌우 합성입력으로 확인했습니다. 모듈 C코드와 키맵은 수정하지 않았습니다.

명령:
```text
python scripts/validate.py
python scripts/selftest.py
python -m unittest discover -s tests -p 'test_*.py' -v
cc -std=c11 -Wall -Wextra -Werror -pedantic -fsanitize=undefined,address -fno-omit-frame-pointer -I modules/modu-control/include modules/modu-control/src/core.c tests/test_core.c -o /tmp/modu-core-test
/tmp/modu-core-test
python scripts/test_studio_preview_browser.py --screenshots
```

현재 로그: `docs/review_logs/v0.1.6_final_tests.txt`, `docs/review_logs/v0.1.6_preview_browser.txt` 및 `docs/LOCAL_TEST_LOG.txt`. 변경/보존 목록과 한계: `docs/REVIEW_v0.1.6_KO.md`.

호스트 검사에는 모의 RTOS, 센서·전송·키맵 getter가 포함됩니다. 전체 Zephyr API 컴파일, 고정 upstream 대상 펌웨어 빌드, 실제 센서·USB Studio·무선·기존 저장 키맵 유지 시험은 수행하지 않았습니다. PNG/HTML은 실제 연결 화면이 아닙니다. Playwright/Chromium은 미리보기 검사 전용이며 펌웨어 Actions 필수 의존성이 아닙니다.
