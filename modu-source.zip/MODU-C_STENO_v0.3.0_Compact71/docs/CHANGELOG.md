# v0.3.0 (2026-09-09)

- Cornix v2.2.6 STENO and Base ported to MODU Compact71, right B mode switch.
- Added 13 auxiliary digit/symbol/F-key behaviors with exact release tracking.
- Preserved canonical43/quick12, mirrored onset and 500ms direct-input rules.
- Kept MODU trackball module and pinned hardware; used isolated modusteno1 keymap settings.
- Added native integration/source contracts and nine-layer source preview.
- No full Zephyr build or hardware testing performed for this source release.

## Previous release history

# v0.1.9 — 2026-09-09

USB Studio 잠금 off, 실제 설정 확인 추가. Base가 Mouse인 채 토글한 모드와 우선순위를 v2 레코드로 기억. v1 읽기/초안 구분/재부팅 회귀 검사 추가. 키맵·레이아웃·센서·무선 설정은 보존. 새 전체 ARM 빌드와 실기 확인은 미실시. 자세한 내용: REVIEW_v0.1.9_KO.md.

# v0.1.7 — 2026-09-08

트랙볼 런타임/키맵/레이아웃은 v0.1.6 그대로. 원본 CMake-only EDT 기반 연결 생성으로 변경하고, 최종 원본 센서/스캔/split 속성 대조와 실패 진단을 보강했다. 자세한 내용은 REVIEW_v0.1.7_KO.md. 장치용 전체 빌드/실기 검증 미실시.

# v0.1.6 — compact crosses below Alt/Ctrl (2026-09-08)

- Move only screen x/y for trackball directions 67..74 and mode centers 75/76.
- Left center (1,6) below LAlt; right center (12,6) below RCtrl. Top arrows at y5.
- Keep 1u square crosses, all first67 coordinates, all77 matrix addresses, keymap and modules unchanged.
- Source geometry height 10u -> 8u; width stays14u. No thumb-key relocation.
- Update JSON-derived preview and add compact-layout/source-to-DTS/browser checks.
- No Codespaces, extension or separate settings page needed. Full ZMK/device tests remain unperformed.

# v0.1.5 — native square cross layout (2026-09-08)

- Position67..74 form two true Up/Down/Left/Right crosses, with profile slots75/76 centered.
- Ten1u squares; all77 matrix positions and all keymap bindings unchanged. Extra B remains next to N.
- No browser extension in the release. Default Studio geometry/behavior editing only.
- Validate source geometry and generated DTS; retain core/runtime/input/profile/CPI/RF regression tests.
- New source-derived HTML/PNG and optional browser tests; no actual Studio, ARM build or device claim.

# v0.1.4 — 2026-09-08

- Relocate extra B66 next to N without matrix or original Base/Fn changes.
- Add Base-only sensor mode settings75/76; firmware reads markers, no phantom input.
- Add independent physical cycle controls and metadata; preserve held overrides.
- Separate Studio baseline from manual override/persisted mode, no implicit keymap save.
- Add optional official-web-Studio circle styling extension, no USB or keymap writes.
- Update generation/compiled checks to77 entries and check keymap getter availability.
- 115 host/source tests; 180378 core assertions; 12 extension DOM +9 preview checks.
- No full Zephyr build, UF2, live Studio or hardware validation.

# v0.1.3 — 2026-09-08

- Audit fix: accept bare/bracketed single phandles; ignore string-literal node/braces.
- Reject missing, duplicated or disabled central trackball routes instead of silently generating a partial integration.
- Explicit USB-only Studio GATT opt-out; keyboard BLE and max +8 dBm preserved.
- Add compiler-EDT input/sensor/layout/USB guard and diagnostic integration JSON.
- Add actual input-processor host scenarios and synthetic graph/config checks: 93 Python cases total.
- Include a clearly labeled source-layout preview; no claimed live Studio screenshot.
- Keymap, control definitions, hardware pins/driver/dependency commits and runtime C code unchanged from v0.1.2.
- No actual ZMK/ARM build or hardware test performed.

# v0.1.2 — Maximum default RF power (2026-09-08)

- Set both halves' controller build default to +8 dBm; verify the effective selection in compiler-generated .config.
- Unify initial runtime TX, startup, reconnect/security recovery and MC_RESET at MC_TX_DEFAULT = MC_TX_PLUS_8.
- Keep advertising/active-scan TX at the maximum recovery default even when connected-link power is manually reduced.
- Keep MC_TX_0 as an explicit selectable 0 dBm level; preserve increase/decrease/set/max controls and all keymap positions.
- Update Studio metadata default label and current Korean instructions. Historical review reports remain historical.
- Add 8 runtime-host cases and 8 policy/config checks; all 46 Python tests and the existing pure-C checks pass locally. No full ZMK/Zephyr build, UF2 or RF measurement is claimed.

# v0.1.1 — Host-reviewed corrections (2026-09-08)

- Added deterministic runtime tests that compile actual runtime/core source with host doubles (not Zephyr). Six regression scenarios fail on v0.1.0 and pass after the fixes.
- Keep central desired CPI authoritative; reject stale local command echoes as configuration writes.
- Address private commands via EVENT_SOURCE (left=local, right=peripheral index 0), preserve transport errors, and rearm CPI/RF bounded retries for new changes.
- Reset arrow repeat deadlines on generation transitions and discard stale opposite-direction queued taps.
- Respect ordered DTS property deletions; preserve quoted text and do not expand commented includes. Added seven preflight fixture tests (18 total).
- Include generated .config in diagnostic uploads; collect zmk.map as well as zephyr.map. Synchronize workflow fallback copies.
- Preserve all keymap assignments, source pins, board/shield names, external vendor drivers, licenses and original four packaging safeguard scripts.
- All 30 Python/runtime-fixture scenarios and original pure-C 180,378 assertions pass locally. No full ZMK build, Actions run, USB connection or hardware verification is claimed.

# v0.1.0 — Unofficial experimental integration

- Original uploaded configuration is the baseline; ZMK and MODU revision pins are unchanged.
- Added a local runtime module and metadata for USB Studio, independent trackball modes, momentary controls, actual CPI commands and RF output requests.
- Added 8 virtual direction key positions while preserving the original first 67.
- Extended the third layer with controls; retained the original Base/Fn assignments and bootloader positions.
- Added conservative, source-resolving hardware integration generation before compilation.
- Replaced the reusable workflow with an explicit Actions build/test/package pipeline; Codespaces is not involved.
- Preserved original HEX/UF2 safeguards and attribution. Added compiler-output flash bounds checking and failure diagnostics.
- Added native tests, synthetic preflight tests and Korean browser-upload instructions.
- No actual Zephyr build, GitHub Actions run, Studio connection or hardware test has been completed for this version.
