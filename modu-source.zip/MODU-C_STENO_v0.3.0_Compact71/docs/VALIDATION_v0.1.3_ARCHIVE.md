# v0.1.3 검사 결과 — 2026-09-08

**소스/호스트/합성 구조 검사 통과 · 실제 ZMK 컴파일 및 실기 미검증. UF2 없음.**

| 검사 | 결과 |
|---|---|
| DTS 생성기 합성 fixture | 26개 통과 |
| 실제 runtime/core 및 추가 input_processor 호스트 경로 | 28개 통과 |
| 합성 EDT/config·USB 전용 빌드 명령 검사 | 31개 통과 |
| RF 최대 기본값 정책 및 합성 설정 검사 | 8개 통과 |
| Python unittest 총계 | **93개 통과** |
| 순수 C, 엄격 경고, ASan+UBSan | **180,378 assertion 통과** |
| 기존 정적 검사·HEX/UF2 합성 자체 검사 | 통과 |
| Python/YAML 파싱·워크플로 사본 일치 | 통과 |
| 키맵·C runtime·의존 버전·원본 안전 스크립트 보존 | 통과 |
| 소스 배치 HTML 탭/키 상세 브라우저 검사 | 통과 |

93개는 호스트·합성 테스트 수이고 assertion 수는 독립 테스트 수가 아닙니다. 입력 처리 C는 대역 헤더와 연결했으며, 실제 Zephyr 헤더/driver/HID/USB/BLE를 실행하지 않았습니다. `hardware.c`/`behavior.c` 등록부의 실제 ABI 호환은 미검증입니다.

새 compiled-EDT 검사를 작성했지만 실행한 것은 합성 객체입니다. 실제 compiler output 검사, firmware memory size, Studio 연결/저장, 좌우 실제 센서 CPI 변화/장착 방향, RF 실제 적용, 재연결/키해제 시험은 수행하지 않았습니다. 컴파일 성공 이후에도 기기 시험이 필요합니다.

새 16개 parser/input 경로 검사를 포함한 62개 suite는 수정 전 v0.1.2에서 5 failure + 4 error(한 method의 subtest 포함)를 보였고 수정 후 통과했습니다. 새 input 경로 8개 자체는 수정 전에도 통과했습니다. 이후 EDT/USB 검사 31개를 추가하여 총 93개입니다.

상세: `docs/REVIEW_v0.1.3_KO.md`. 기록: `docs/LOCAL_TEST_LOG.txt`, `docs/review_logs/v0.1.3_*.txt`. 이전 v0.1.2 기록은 archive 파일에 보존했습니다. PNG/HTML은 실제 Studio 화면이 아니라 소스 기반 미리보기입니다.
