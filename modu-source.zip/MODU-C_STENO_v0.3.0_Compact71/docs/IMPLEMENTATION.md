# MODU STENO integration notes

The board manifest, matrix/scan, split transport, PMW3610 sensor paths and the entire modu-control module are retained from the uploaded v0.2.0. The original baseline keymap remains immutable for EDT hardware derivation.

The Cornix v2.2.6 decoder and dictionaries are copied without changes. A physical-to-canonical adapter in modu_position.h feeds the existing engine coordinates; the engine's limit is 64, with virtual trackball positions rejected for steno roles. Original regression fixtures deliberately keep canonical Cornix coordinates. Active MODU source-contract tests separately verify the hardware mapping.

modu_aux borrows physically held symbol/vowel-extension markers for 13 extra keys. prepare_aux ends an ordinary pending chord, suppresses consumed selector taps, and restores still-held selectors when another real steno role arrives. Vowel dual-role pending taps follow the same 500ms rule at this boundary. Key encodings are latched at press and released by physical position.

The output FIFO now has TAP/DOWN/UP items. Each accepted DOWN reserves one future UP slot. Generated sequences are rejected atomically if insufficient space remains. The queue is mutex protected and flush releases actual held keys. Standard Quick macros still use the original ZMK macro dispatcher; the host auxiliary tests do not simulate its entire asynchronous queue or Bluetooth transport.

Mode/language changes reset the auxiliary ledger and flush queued/held auxiliary output. A generic layer toggle alone is not equivalent to the steno mode behavior. Essential layer IDs are fixed in this package. Local source overlays are bound to these nine existing node names, and custom combos are restricted away from STENO/Select Nav.

The pinned keymap.c patch uses a new modusteno1 namespace for save, load, reorder/name keys and reset paths. It never reads the legacy keymap namespace or erases Bluetooth/trackball settings. Legacy compact numeric slot mapping is retained inside the new namespace. Unknown upstream source is rejected; both the exact original and known v0.2.0 compact patch can be upgraded. This is host-tested, not real NVS migration tested.

Build guard verifies the effective STENO Kconfig and compiled EDT 9 x 71 layout. The full ARM/Zephyr build is not performed locally; the GitHub workflow must pass before flashing. No UF2 binary is included in this source archive.
