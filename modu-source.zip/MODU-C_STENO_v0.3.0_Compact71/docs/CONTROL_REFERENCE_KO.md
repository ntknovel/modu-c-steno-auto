# MODU-C v0.3.0 트랙볼 제어

일반 모드에서 왼 바깥 엄지(Win/Num)를 홀드하고 왼 Ctrl도 홀드하면 레이어 2입니다. 제어 코드는 업로드된 v0.2.0을 유지했습니다. Base Ball setting은 69/70, 방향 출력은 61~68입니다.

|번호|원래 위치|제어 바인딩|
|---:|---|---|
|0|Esc|`&studio_unlock`|
|1|1|`&out OUT_USB`|
|2|2|`&lmode MC_MOUSE`|
|3|3|`&lmode MC_SCROLL`|
|4|4|`&lmode MC_ARROWS`|
|5|5|`&bootloader`|
|6|6|`&bootloader`|
|7|7|`&rmode MC_MOUSE`|
|8|8|`&rmode MC_SCROLL`|
|9|9|`&rmode MC_ARROWS`|
|10|0|`&lmode MC_OFF`|
|11|Backspace|`&rmode MC_OFF`|
|12|Tab|`&lhold MC_MOUSE`|
|13|Q|`&lhold MC_SCROLL`|
|14|W|`&lhold MC_ARROWS`|
|15|E|`&lhold MC_OFF`|
|16|R|`&lcpi MC_INC 0`|
|17|T|`&lcpi MC_DEC 0`|
|18|Y|`&rcpi MC_INC 0`|
|19|U|`&rcpi MC_DEC 0`|
|20|I|`&rhold MC_MOUSE`|
|21|O|`&rhold MC_SCROLL`|
|22|P|`&rhold MC_ARROWS`|
|23|Home|`&rhold MC_OFF`|
|24|Caps|`&lscroll MC_INC 0`|
|25|A|`&lscroll MC_DEC 0`|
|26|S|`&lptr MC_INC 0`|
|27|D|`&lptr MC_DEC 0`|
|28|F|`&lrate MC_INC 0`|
|29|G|`&lrate MC_DEC 0`|
|30|H|`&rrate MC_INC 0`|
|31|J|`&rrate MC_DEC 0`|
|32|K|`&rptr MC_INC 0`|
|33|L|`&rptr MC_DEC 0`|
|34|;|`&rscroll MC_INC 0`|
|35|PgUp|`&rscroll MC_DEC 0`|
|36|LShift|`&ltx MC_INC 0`|
|37|Z|`&ltx MC_DEC 0`|
|38|X|`&ltx MC_MAX 0`|
|39|C|`&ltx MC_RESET 0`|
|40|V|`&lcpi MC_RESET 0`|
|41|B|`&lreset 0`|
|42|N|`&rreset 0`|
|43|M|`&rcpi MC_RESET 0`|
|44|,|`&rtx MC_INC 0`|
|45|.|`&rtx MC_DEC 0`|
|46|/|`&rtx MC_MAX 0`|
|47|PgDn|`&rtx MC_RESET 0`|
|49|LAlt|`&modu_sync 0`|
|50|LGUI|`&btx MC_RESET 0`|
|51|RAlt|`&larrow MC_INC 0`|
|52|RCtrl|`&rarrow MC_INC 0`|
|53|End|`&btx MC_MAX 0`|
|54|왼 엄지 바깥(LANG1)|`&lcycle MC_CYCLE_NEXT`|
|58|오른 엄지 가운데(Enter)|`&rcycle MC_CYCLE_NEXT`|
|69|가상 출력|`&trans`|
|70|가상 출력|`&trans`|


순환키는 54(왼쪽), 58(오른쪽), 부트로더 키는 5/6입니다. 기기와 실제 Studio 통신은 이 작업 환경에서 시험하지 않았습니다.
