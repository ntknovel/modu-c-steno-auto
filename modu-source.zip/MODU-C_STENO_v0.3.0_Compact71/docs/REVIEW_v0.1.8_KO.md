# v0.1.8 — 실제 Actions 실패 수정

기준: 사용자가 첨부한 좌/우 진단 ZIP, 펌웨어 v0.1.7.

## 실제 실패
양쪽 build.log에서 `modules/modu-control/modu.conf:5`의 `CONFIG_BT_HCI_VS_EXT=y`가
정의되지 않은 설정이라는 경고로 Kconfig 단계가 중단되었습니다. C 코드 컴파일 이전이며
토큰/업로드/산출물 다운로드 오류가 아닙니다. original-configure.log, original-config,
original-hardware.json, preflight.json은 양쪽 모두 생성되어 원본 구성과 연결 해석은 진행됐습니다.

## 수정
1. `CONFIG_BT_HCI_VS_EXT=y`를 실제 원본 .config에 있는 `CONFIG_BT_HCI_VS=y`로 수정.
2. 최대 출력 검사의 숫자 항목을 잘못된 `CONFIG_BT_CTLR_TX_PWR=8`에서 실제 원본 .config의
   숫자 항목인 `CONFIG_BT_CTLR_TX_PWR_DBM=8`로 수정. PLUS_8 및 동적 제어 선택은 계속 요구.
   원본 .config 값은 0이고, 최종 수정 빌드에서 요구하는 값은 8입니다.
   원본의 0을 8로 바꾼 시험 입력은 **변형 fixture**이지 실제 수정 빌드 출력이 아닙니다.
3. 실패 진단에 Zephyr Bluetooth 헤더/Kconfig와 보드 *_defconfig를 추가로 수집.

Kconfig 경고를 무시하거나 최대 출력 검사를 제거하지 않았습니다. API/핀/드라이버/키맵/레이아웃/
트랙볼 C 코드 6개/저장 형식/좌우 최대 출력 기본 정책은 변경하지 않았습니다.

## 검증 구분
실제 실패 로그를 확인했고, 원본 .config에서 설정 이름을 확인했습니다. 새 회귀 테스트는
그 원본 설정의 발췌와 의도적으로 변형한 입력을 사용합니다. 전체 Zephyr/ARM 빌드 또는
Windows GitHub 왕복, 센서·USB·BLE 실기는 이 환경에서 실행하지 않았습니다.

자동 빌더 v1.0.4는 이 소스와 새 체크섬을 묶습니다. 이전 실패 기록을 이어받으면 같은 실패 자료만
다시 받으므로 **새 빌드(N)**를 선택합니다. 저장소·토큰 재생성이나 키맵 초기화는 필요 없습니다.
