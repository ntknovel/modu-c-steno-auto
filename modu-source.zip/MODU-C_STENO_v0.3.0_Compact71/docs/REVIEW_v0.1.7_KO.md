# MODU-C v0.1.7 — 트랙볼 원본 대비 확인과 빌드 경로 보완

검토일: 2026-09-08. 기준: 대화에 올라온 원본 `modu-c-zmk-config-main(1).zip` 및 수정본 v0.1.6.

## 결론

**기존 트랙볼 동작 코드와 요청한 키 배치는 변경하지 않았다. 원본 배정 대조와 호스트 검사는 통과했다. 실제 센서 동작·전체 ARM 컴파일은 아직 시험하지 않았다.**

이번 산출물은 GitHub Actions로 빌드할 소스 v0.1.7이다. UF2를 포함하지 않는다. 기존 전처리기의 정상적인 오른쪽 분할 구성/조건부 DTS 오판을 피하기 위해, 이제 **원본을 Zephyr로 먼저 구성한 결과(EDT)에서 하드웨어 연결을 읽는다.** 단순 문자열 파서를 고쳐 원본인 것처럼 추정하는 방식은 사용하지 않는다.

## 1. 원본 대비 트랙볼 관련 차이

| 구분 | 원본 대비 수정본 |
|---|---|
| 센서 드라이버·보드·썸 스캔 | 같은 MODU 고정 커밋을 참조. 별도 드라이버로 교체하지 않음 |
| 원래 Base/Fn 67개 | 동작과 인수까지 동일 |
| 원래 행렬 주소·입력 순서 | 동일. 가상 방향 8개와 설정 칸 2개만 뒤에 추가 |
| 기본 마우스 처리 | 100% 포인터 배율. 기본 CPI 요청 600. 모드별 변환기를 추가 |
| 왼쪽 센서 | 기존 로컬 센서 입력 뒤에서 왼쪽 상태 적용 |
| 오른쪽 센서 | 기존 split 송신을 유지하고 중앙 수신 후 오른쪽 상태 적용. 주변 장치에서 이중 변환하지 않음 |
| 새 기능 | 좌우 독립 마우스/휠/방향키, 누르는 동안 임시 모드, 물리 모드 순환, 좌우 센서 CPI 제어 |
| CPI | 포인터 배율 대체가 아니라 대상 MCU에서 `sensor_attr_set()` 호출 |
| RF | 기본/복구 요청 +8 dBm. 수동 출력 변경은 세션 한정 |
| Studio | 왼쪽 USB 전용 설정 통신, Alt/Ctrl 아래 사각 십자와 중앙 Base 모드 칸 |

이 환경에서는 정확한 외부 고정 소스를 내려받지 못했다. 따라서 '원본 센서 드라이버 전체를 확보하여 실기 정상 확인했다'고 주장하지 않는다. 실제 고정 소스를 사용한 설정 대조는 아래 Actions에서 수행한다.

## 2. v0.1.6에서 v0.1.7로 변경한 범위

`modules/` 전체 **19개 파일**, `config/`의 키맵·제어 동작·레이아웃·west.yml 및 `build.yaml`은 바이트 동일하다. `hardware.c`, `input_processor.c`, `runtime.c`, `core.c`, `behavior.c`, `studio_profile.c`에 기능 변경은 없다. 추가 B의 N 왼쪽 위치, 좌우 모드 토글, CPI 키, 부트로더 5/6, RF 기본 최대도 유지했다.

바뀐 것은 빌드 연결 처리와 진단이다.

### 이전의 확인된 약점

`prepare_build.py`가 DTS 문자열을 직접 읽어 양쪽 모두 로컬 `trackball_listener` 활성화를 요구했다. 오른쪽은 그 리스너가 비활성이어도 센서 → `zmk,input-split`으로 전송하는 구성이 정상일 수 있다. 또한 문자열 해석은 `#if 0` 등의 실제 전처리 결과와 달랐다. 이전 보고서에서 이것은 합성 입력으로 재현된 제약이며, 정확한 원본에서 빌드 실패를 관측한 것은 아니었다.

### 변경 후 빌드 순서

1. 업로드된 원본 키맵의 SHA-256을 확인하고 별도 원본 구성 폴더에 복사한다.
2. **원본 하드웨어 모듈 두 개만 사용해 `west build --cmake-only`를 실행한다.** Studio/새 제어 모듈은 이 기준 구성에 넣지 않는다. 원본 UF2를 만드는 단계는 아니다.
3. Zephyr가 생성한 `.config`와 `edt.pickle`에서 원래 행렬·스캔·센서·split 연결을 읽는다. 실제 include/조건부 분기/장치 덮어쓰기는 Zephyr가 해석한다.
4. 왼쪽에는 기존 두 입력 리스너 뒤로 좌우 제어 처리기를 붙인다. 오른쪽 센서는 **활성 split 송신 노드의 device**에서 찾으므로 비활성/없는 로컬 HID 리스너에 의존하지 않는다.
5. 원본 센서·SPI 부모·스캔·split 속성을 기록하고, 레이아웃/가상 입력과 Studio 설정을 더한 최종 펌웨어를 컴파일한다.
6. 최종 EDT의 원본 속성과 원래 입력 처리 체인을 비교한다. MCU/센서/스캔/split 경로가 바뀌면 포장을 중단한다. 기존 USB Studio·ELF 영역·HEX/UF2 검사는 유지한다.

구현: `scripts/prepare_from_edt.py`, `build_firmware.py`, `check_built.py`. `prepare_build.py`는 공용 API 검증 함수와 예전 합성 시험용 문자열 해석 유틸리티만 유지한다. **실제 빌드는 문자열 해석기나 fallback을 사용하지 않는다.**

실제 원본에 예상 밖의 입력 코드 변환/레이어별 처리 등이 있으면 여전히 확인을 위해 중단한다. 이는 안전 검사를 제거하여 억지로 빌드를 통과시키는 수정이 아니다.

## 3. 실행한 검증

| 검사 | 실제 결과 |
|---|---|
| 원본 Base/Fn, 행렬, 부트로더, west.yml 독립 비교 | 통과 |
| v0.1.6 대비 제어 모듈·키맵·화면 배치 바이트 비교 | 통과 |
| Python/호스트 회귀 검사 | **160개 통과** |
| 이 중 새 EDT/빌드 흐름 검사 | **28개**: 오른쪽 비활성/없는 리스너, 실제 송신 대상 선택, 속성 보존/변경 거부, 단계별 실패 시 미게시 등 |
| 기존 순수 C core 검사 | **180,378회 assertion 통과**, ASan/UBSan·엄격 경고 |
| 기존 HEX/UF2 selftest·정적 검사 | 통과. 합성 바이너리 검사이지 UF2 생성 아님 |
| 실제 원본 CMake 구성·Zephyr ARM compile/link | **미실시** |
| 센서 CPI·HID·USB Studio·무선 실기 | **미실시** |

호스트 검사는 실제 core/runtime/input/profile 코드와 대역 API를 사용한다. hardware.c의 실제 SPI/HCI 호출 및 behavior.c의 실제 Zephyr 등록/metadata ABI는 장치용 컴파일과 실기에서 확인해야 한다. 새 EDT 검사는 합성 객체다. 실제 컴파일된 EDT를 여기서 얻어 통과했다는 의미가 아니다.

로그: `docs/review_logs/v0.1.7_host_tests.txt`, `v0.1.7_comparison.json`, `v0.1.7_uf2_selftest.txt`, `v0.1.7_build_changes.diff`. 이전 버전 로그는 과거 기록이며 이번 시험으로 중복 계산하지 않았다.

## 4. 빌드와 진단

**Codespaces를 사용하지 않는다.** 소스 배포본은 기존 `Build MODU-C Studio` Actions로 실행한다. 별도 'GitHub Build Pack'은 소스 ZIP 한 개 업로드와 워크플로 파일 생성만으로 같은 소스를 빌드하는 편의 포장이다. 두 방식의 센서/트랙볼 소스는 같다.

성공 조건: `Static and native tests`, `Compile left`, `Compile right`, `Package both UF2 files`가 모두 성공해야 한다. 최종 산출물은 `modu-c-studio-firmware`. 진단용/중간 HEX/UF2는 설치하지 않는다.

실패 시 `modu-diagnostics-left` 또는 `modu-diagnostics-right`에는 가능한 단계까지 다음을 수집한다.

- 원본 CMake 로그와 원본 DTS/.config
- 원본 센서 연결 기록 `original-hardware.json`
- 고정 MODU 센서/스캐너 C·헤더·Kconfig·보드 정의, 관련 ZMK API
- 최종 빌드 로그·DTS/.config·링크맵

해당 버전으로 양쪽을 같이 업데이트하고 정상 UF2를 먼저 보관한다. 저장된 Studio 키맵을 확인하려고 무조건 초기화하지 않는다.

## 5. 설치 후 최소 확인

1. Base 중앙 두 설정을 Mouse로 두고 좌우 공을 각각 굴린다. Ctrl/Alt 아래 배치와 일반키/썸키도 확인한다.
2. 한쪽만 Wheel로 변경하여 반대쪽이 계속 Mouse인지 확인한다.
3. 순환키 및 누르는 동안 전환 → 해제 후 복귀를 확인한다.
4. 방향키 모드에서 네 방향 입력과 키를 놓은 뒤 눌림 잔류가 없는지 확인한다.
5. 왼쪽 CPI만 600→1200으로 바꾸고 오른쪽은 그대로인지 확인한 뒤 반대로 시험한다. 재연결 후 오른쪽 설정 유지도 확인한다.

이 순서는 앞으로 할 실기 시험이며 수행 완료 목록이 아니다.

공식 구현 참고: ZMK 포인팅 통합 https://zmk.dev/docs/hardware-integration/pointing ; Zephyr CMake-only 구성 https://docs.zephyrproject.org/latest/build/dts/howtos.html ; GitHub 워크플로 실행 https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow . 현재 공식 문서와 정확한 pinned 소스의 직접 검증은 구분했다.
