# Current runtime: v0.1.9

The live build now disables Studio locking explicitly on the central and verifies the compiler output.
All keymap bindings and physical layout coordinates remain unchanged from v0.1.8 (77 positions).
The six tiny &none positions51..56 are retained for compatibility; no hidden-key claim is made.

Mode settings now use an atomic 40-byte `modu_control/v2` record containing both configs and committed
baseline/manual priority per side. The32-byte v1 record is accepted for migration. Unsaved Studio edits
are distinguished by the actual pinned `zmk_keymap_check_unsaved_changes()` API. No keymap setters,
implicit keymap Save or settings deletion are added. The1.2-second debounce is unchanged.

The following notes describe historical v0.1.4-6 behavior. Persistence/locking details are superseded
by REVIEW_v0.1.9_KO.md; actual build preparation uses prepare_from_edt.py since v0.1.7.

---

# Current layout: v0.1.6 native square crosses

The 77 logical IDs and all firmware module code are unchanged from v0.1.5. Only screen geometry for67..76 changed (outer modifier area, not below the thumbs): left center75=(1,6) under LAlt, right center76=(12,6) under RCtrl; each direction is one unit above/below/left/right. All ten keys are1u squares. No custom Studio renderer, extension, shape field or device settings window is required. The ordinary Studio keymap editor edits the existing Base-only lball/rball profile markers.

The former cosmetic extension is no longer distributed. Old extension files in an updated repository are not dependencies and do not affect builds. Historical v0.1.1–4 implementation notes below remain useful for mode/CPI/RF/profile logic; UI instructions are superseded by REVIEW_v0.1.6_KO.md. New source geometry validation and generated-DTS fixture tests ensure no index swaps, cross distortion or overlaps. Existing hardware/source API limitations remain unchanged.

# Integration notes — uncompiled v0.1.4

## Boundaries

`config/west.yml` and the board/shield IDs are unchanged. The vendor hardware and PMW3610 driver are not copied or edited. The original first 67 matrix coordinates and Base/Fn bindings are tested against snapshots in `docs/`; only extra B position 66 has an explicit visual x/y relocation exception. The original three populated layers remain; layer 2 is expanded with controls, five extra Studio layers are reserved, and 8 direction positions plus 2 configuration positions are appended.

`prepare_build.py` runs AFTER west update and BEFORE west build. It verifies Git revisions, resolves the alternate-thumb scanner and local PMW3610 device, verifies the full 67-entry transform, then extends the existing transform to 77 positions without replacing its column offset. It supplies a fixed physical layout and removes only the obsolete chosen matrix-transform selection. On the central, it appends a side-tagged input processor to both existing input listeners. Existing layer-specific listener overrides cause a deliberate preflight failure instead of silently bypassing the new processor. Unsupported/missing labels also stop the build. This procedure has only been exercised on synthetic fixtures locally.

`modu-upstream.h` references the actual downloaded sensor API header and the HCI command-buffer API. There is no handwritten replacement sensor driver. CPI encoding is checked against the upstream conversion macro before invoking its attr_set.

## Split controls

Public left/right controls use CENTRAL locality. The internal `modu_hw` behavior uses EVENT_SOURCE locality. Left is addressed as the local source; the only peripheral (right) is source index 0, not logical side number 1. The explicit side ID is retained as a receiver-side check. Its node name is <=8 characters. Only the addressed MCU applies the command. Commands transmit absolute CPI/TX-index values, not increments, so reconnect retries cannot double increment the sensor. Both halves must use this firmware. Routing returns the addressed transport status rather than masking remote errors behind local success. A successful transport enqueue is NOT an end-to-end sensor acknowledgement. The central keeps the authoritative desired CPI; a delayed local command echo does not rewrite it.

CPI requests are retained; each new CPI/reset/RF request rearms a bounded retry burst, as do connection/security callbacks; sensor readiness also has a bounded local retry. Reconnect restores desired CPI from the central. Requested sensor values are not proof that a sensor is physically present or accepted the command. This remains a hardware test requirement.

## Trackball conversion

`core.c` is RTOS-independent. A bounded 16-entry hold stack per side preserves non-top releases, duplicate-key handling and momentary/persistent separation. Small movement remainder is accumulated for mouse/scroll; it cannot recover movement already rounded away in the vendor driver. Mouse output is saturated to +/-32767, wheel to +/-127. Arrow movement accumulates by axis and emits up to four pending steps per direction per side. Dominant-axis mode clears cross-axis drift; diagonal mode allows both axes.

`runtime.c` schedules 12ms press/release pairs at a minimum configured 20ms interval through ZMK's normal position events at positions 67..74. Generation changes discard stale pending taps, release an active virtual key, and reset the repeat deadline. Confirmed motion reversals discard opposite-direction queued taps; dominant-axis mode also clears other-axis pending taps. No ZMK event is raised while the settings mutex is held. BLE connection changes cancel momentary state to avoid a stuck mode when release packets cannot arrive.

## Persistence and RF recovery

A versioned 32-byte settings record stores the two trackball configs under `modu_control/v1`, after a 1200ms debounce. Invalid length/version/ranges are rejected. This data is separate from Studio's keymap settings. RF indices and momentary holds are never written to settings.

RF changes use controller vendor HCI commands for active local connections. Both halves select CONFIG_BT_CTLR_TX_PWR_PLUS_8=y before runtime work starts. Runtime initialization, explicit RF reset, and connect/disconnect/security recovery use MC_TX_DEFAULT (MC_TX_PLUS_8). Advertising/active-scan transmission stays at this +8 dBm maximum default even when connected-link power is manually reduced. Passive scanning receiver sensitivity is unchanged. This is a deliberate session-only recovery policy, not durable RF configuration or receiver-sensitivity control. Hardware-selected TX level may differ from the requested table entry. No claim is made that every request value is supported by the exact radio or that these changes eliminate link problems.

## Build and artifact paths

Checkout is at GITHUB_WORKSPACE. The manifest is GITHUB_WORKSPACE/config/west.yml; west init -l config places dependencies next to it at GITHUB_WORKSPACE/zmk, zephyr and modu-c-firmware. The separate local control module is at GITHUB_WORKSPACE/modules/modu-control. The config argument passed to build_firmware.py is the repository root; its ZMK_CONFIG argument is root/config.

The custom workflow uses the official ZMK build image, with separate matrix jobs so generated left/right DTS files cannot overwrite each other. It verifies compiler configuration and ELF flash-load ranges against the chosen code partition before publishing an intermediate binary. The original HEX/UF2 checks remain unchanged. Binary checks do not constitute hardware/bootloader compatibility testing. Pinning source commits does not pin the mutable build container or GitHub action major-version tags.

## Host review coverage in v0.1.1

The 12 host runtime tests compile the actual `runtime.c` and `core.c` against deterministic test doubles. Scheduling, mutex assertions, transport return values and settings callbacks are simulated; real Zephyr headers and ABI are not involved. Both central/peripheral branches are exercised. This extends, but does not replace, the original core tests. Six of these scenarios failed against v0.1.0 and pass against v0.1.1.

The source preflight parser has 18 synthetic tests; ordered property deletions, string/comment boundaries and disabled includes were added. It is a conservative source resolver, NOT a complete DTS preprocessor/compiler. It cannot establish actual pinned-source compatibility until Actions fetches those sources.

Diagnostic artifacts explicitly include hidden files only within the dedicated diagnostics directory so generated `.config` survives upload. Both `zmk.map` and `zephyr.map`, when present, are collected. The HTML fallback workflow and `BUILD_WORKFLOW_COPY.txt` match the real workflow.

## Remaining integration risks

The actual pinned hardware definitions and Zephyr headers were inaccessible from the creation environment. Full module compile/link, generated devicetree compatibility, HID/Studio memory size, split behavior delivery, runtime settings initialization, radio controller support, sensor orientation and real key-release behavior all require the first Actions build and subsequent hardware testing. A green native/mock test does not verify those real interfaces. Flash checks inspect ELF PT_LOAD ranges and UF2 structure separately; this is not byte-for-byte equivalence verification of the final flash image against the ELF. The build container and action major tags remain mutable, as in v0.1.0.

Never bypass a preflight error by guessing pins or swapping board IDs. The diagnostics artifacts retain the exact small hardware source definitions, headers, generated files and available build logs for evidence-based fixes. Never distribute the synthetic UF2 fixtures used by selftest.py as device firmware.

## References

- ZMK behavior metadata/locality: https://zmk.dev/docs/development/new-behavior
- ZMK Studio/physical layout requirements: https://zmk.dev/docs/features/studio
- Physical layouts: https://zmk.dev/docs/development/hardware-integration/physical-layouts
- Input processors: https://zmk.dev/docs/keymaps/input-processors
- The uploaded repository's original notices and pinned manifest.

## Maximum-default coverage in v0.1.3

Added 8 actual-runtime host cases and 8 static/config-check cases. Runtime cases cover startup, RF reset and reconnect on each role, both-side reset, manual independence, saturation at maximum, explicit 0 dBm, and retry preservation. Static assertions check the hardware discovery floor and Studio label. They do not compile hardware.c against Zephyr or measure RF. The post-build checker now requires both CONFIG_BT_CTLR_TX_PWR_PLUS_8=y and CONFIG_BT_CTLR_TX_PWR=8 in the generated .config.

## Full-source audit changes in v0.1.3

The source resolver now accepts both bare and bracketed single-label phandles, masks string literals while parsing node syntax, rejects missing/duplicate central input devices and inactive critical nodes. Eight new parser methods are synthetic regression cases; they do not establish that the pinned vendor tree contained these exact patterns. This remains a conservative partial source parser.

The build wrapper explicitly passes `CONFIG_ZMK_STUDIO_TRANSPORT_BLE=n` only for the left Studio build. BLE keyboard/split functionality is NOT disabled. Exact pinned Studio Kconfig symbols are checked during preflight. No Studio runtime transport was exercised here.

`check_integration.py` checks real compiler-produced EDT/config in CI: 75-position geometry/map count and ordering, original scan wrapper, local PMW node and enabled ancestry, internal command behavior, side-tagged central listeners, one right sensor-to-split sender, no duplicate peripheral conversion, and USB CDC RPC. It refuses layer overrides and known preceding code-remapping/behavior processors that need separate XY review. The checker is tested using fake EDT nodes, not real compiler output. The explicit `--zephyr-base` uses the same checked-out Python devicetree module as compilation (the workflow already also sets PYTHONPATH).

Eight new host scenarios compile the actual `input_processor.c` alongside runtime/core against test doubles: per-side scaling, temporary wheel/hwheel conversion and restoration, right virtual directions, synchronized frames, off-versus-buttons, inverted fractional scroll, diagonal sequential taps and persistent changes under a temporary hold. These are not Zephyr-header, Bluetooth, USB HID or driver tests.

`modu_hw` has an internal warning display name but no special proven Studio hide mechanism; it is not a user control. The 24 public control definitions expose English metadata labels. Virtual arrow events are deliberately central/local sources. Assigning source-locality reset/bootloader behaviors to a right virtual direction would therefore target the central, not automatically the right MCU; use the physical bootloader keys instead.

Studio receives key geometry, not the preview's static L/R annotations, colors, circles or a custom theme. The preview does not query or configure a connected keyboard. Analogue ball state/live CPI/live RF sliders remain outside this implementation. Diagonal output means alternating short taps, not simultaneous held WASD keys. Off disables relative ball movement, not separate click inputs. Encoder rotations or previously unsupported module hardware are not added by showing extra key positions.

## v0.1.4 Studio configuration markers and cycle keys

Physical geometry: extra B 66 is now x=7,y=3, adjacent to N42 at x=8,y=3. Existing matrix order and Base/Fn first67 stay unchanged. Direction positions67..74 are unchanged logical IDs. Slots75/76 are distinct settings-only markers, not input events. The compiled layout checker now requires77 entries. Public controls increase from24 to28.

The central compiles studio_profile.c and reads zmk_keymap_get_layer_binding_at_idx(layer ID0,75+side) from runtime.c before motion/mode controls and pulse draining. Only the correct lball/rball device-name and allowed enum with param2=0 are accepted. Invalid/absent values fall back to Follow-mode-keys. The peripheral stub does not import the keymap getter. Preflight now checks the exact fetched header for that API; main documentation was not treated as pinned verification.

Profile fields live in mc_motion; mc_config storage ABI/version stays unchanged. No keymap setter/save is called. A new profile resets manual override once, not every movement. Unchanged profiles allow physical mode cycling to persist for the session. Held modes take precedence and cycling targets the underlying mode rather than the temporary held mode. Explicit profile on reboot overrides previously saved physical mode; Follow mode keys selects the previous persisted mode. A mode-key change still saves its existing config record after the usual1200ms debounce. Studio drafts never overwrite that record's mode.

Default control bindings: position60=lcycle NEXT,64=rcycle NEXT. New MC_KIND_CYCLE metadata supports forward3, reverse3 and mouse/wheel2. Profile behavior pressed handler is a no-op marker: assigning it to a physical key does not reconfigure that ball. All configuration-slot reads stay Base ID0, not currently active layer. No sensor sampling timer was added.

The v0.1.4 cosmetic extension has been removed in v0.1.5. Both profile markers are ordinary square Studio keys and sit at the centers of the two native cross layouts. The preview is a local non-connecting illustration, not a fork of Studio.

Tests:115 Python/host methods,180378 core assertions,12 extension DOM checks plus9 preview checks. Refer to REVIEW_v0.1.4_KO.md and current logs for the exact boundaries. Historic v0.1.1–3 sections above describe their original test counts and UI limitations at that time.
