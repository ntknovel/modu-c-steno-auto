# MODU-C v0.2.0 — Compact 71 + Local Mapper source export

비공식 수정 소스. 설치용 UF2가 아니며 새 버전의 전체 ZMK/ARM 빌드·실기 시험은 아직 하지 않았습니다.

## 이번 변경
- 사용하지 않는 논리 51~56을 실제 키맵/행렬 transform/Studio 표시에서 제외: 77 → 71.
- 일반·썸 입력 61 + 방향 8 + 중앙 모드 2. 새 방향 61~68, 중앙 69/70.
- 기존 NVS 키 배정 저장 주소는 유지하는 정확한 pinned keymap.c 호환 패치 적용.
  화면·입력 번호는 줄지만 저장 이름 keymap/l/<layer>/<old_position>는 그대로 사용합니다.
  빈 자리의 예전 저장값은 무시합니다. 전체 settings reset 또는 저장 파일 삭제를 하지 않습니다.
- USB Studio 잠금 해제, 수동 토글 모드의 v2 기억, 좌우 CPI, RF 기본 +8 dBm 요청 유지.
- 추가 B는 N 왼쪽, 두 십자는 Ctrl/Alt 아래. 부트로더의 물리 5/6 위치 유지.
- UART 연결·자동 전원/배터리 전환은 추가하지 않았습니다.

## 먼저 백업
기존 기기에 저장한 키맵은 로컬 매퍼의 USB 연결 → 장치 백업으로 PC에 보관하세요.
이 버전은 공식 Studio의 같은 단일 MODU 레이아웃에서 사용한 이전 77위치 배정을 대상으로
저장 주소 호환을 구현했습니다. 관련 C 저장/읽기 함수를 호스트에서 시험했지만 실제 NVS
업그레이드·정전 복원은 확인 전입니다. 백업 없이 무조건 초기화하지 마세요.
기존 원본 67위치 펌웨어나 다른 제작자의 레이아웃에 대한 자동 변환을 보장하지 않습니다.

## Codespaces 없이 일반 소스 빌드
1. 이 ZIP을 풀고 **내부 파일/폴더 전체**를 본인 GitHub 저장소 루트에 업로드합니다.
2. `.github/workflows/build.yml`도 같이 교체합니다. 압축된 payload를 읽는 옛 자동 빌더용
   workflow와 다릅니다. 다른 프로젝트가 없는 별도 소스 저장소 사용을 권합니다.
3. Actions → Build MODU-C Studio → Run workflow.
4. Static and native tests, Compile left, Compile right, Package both UF2 files 모두 성공한
   실행의 `modu-c-studio-firmware`를 받습니다.
5. 이전 정상 UF2를 보관하고 새 좌우 UF2를 각각 맞는 쪽에 설치합니다.

이 ZIP을 기존 자동 빌더의 payload/modu-source.zip에 단독 덮어쓰면 고정 해시 검사 때문에
작동하지 않습니다. 이번 배포는 **일반 소스 업로드용**입니다.
브라우저 업로드 제한 때문에 폴더별로 나누어 올릴 수 있습니다. workflow는 마지막에
등록하고 전체 업로드를 마친 뒤 수동 실행하면 중간 자동 빌드를 줄일 수 있습니다.

## 로컬 매퍼에서 만든 고급 설정
로컬 매퍼에서 소스 ZIP으로 내보내면 `config/local-mapper.json`이 추가됩니다.
Actions는 `scripts/compile_mapper.py`로 이 파일을 검증하고 `config/local-custom.dtsi`를
생성해 컴파일합니다. 콤보/매크로/탭댄스 규칙은 재빌드 후 키보드 자체에서 실행됩니다.
실시간 고급 설정 엔진을 넣은 것이 아닙니다.

기존 Studio 저장 키맵은 새 소스의 기본 배정보다 우선할 수 있습니다. 새 규칙을 설치한 뒤
로컬 매퍼에서 장치를 읽고 같은 프로젝트 JSON을 열어 새 동작을 필요한 키에 배정하세요.
원래 사용한 프로젝트 JSON은 고급 규칙의 원본입니다. 기본 Studio RPC는 그 정의를 읽어
내보내지 않으므로 장치 백업만으로 고급 규칙까지 복원되지 않습니다.

원본 제조사 라이선스/고지를 보존했습니다. `docs/COMPACT_71_KO.md`, `VALIDATION.md` 참고.
