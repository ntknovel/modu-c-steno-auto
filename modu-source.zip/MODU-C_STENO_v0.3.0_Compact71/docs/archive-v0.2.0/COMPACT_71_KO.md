# MODU-C v0.2.0 / Local Mapper v0.1.0 변경·검사 기록

## 제공물과 범위
빈 위치를 제거한 일반 펌웨어 소스 ZIP과 Windows CMD 실행형 로컬 웹 매퍼입니다.
매퍼는 원격 ZMK Studio를 iframe으로 여는 것이 아니고, 자체 동봉 UI/프로토콜 코드입니다.
별도 브라우저 확장, GitHub 토큰, Node/Python 설치는 실행에 필요하지 않습니다.
Chrome/Edge와 Windows PowerShell 5.1을 사용합니다. 설치형 네이티브 EXE는 아닙니다.

## 71위치와 기존 저장 키맵
기존77 중51~56 제거. 0~50은 유지,57~76은6 감소. 물리 row/col 주소는 살아 있는 키마다
이전과 같습니다. 가상 방향61~68, 중앙 모드69/70. 일반·썸 입력61개와 모드/방향10개입니다.
5/6 부트로더, Ctrl48은 번호와 기본 동작이 불변입니다. 기존 썸 Fn은 새56/59,
Controls 순환키는 새54/58입니다. 실제 손으로 누르는 위치는 바꾸지 않았습니다.

단순히 기존 저장 레코드를 새 번호로 읽으면 오른쪽 수정키와 썸키가 틀어질 수 있으므로,
고정 커밋의 `app/src/keymap.c`를 정확한 체크섬·텍스트 기준으로 패치합니다.
- 저장/삭제 때 compact>=51은+6을 한 기존 주소 사용.
- 읽기와 초기화 대상 추적에서 기존51~56은 제외,57이상은-6.
- 저장된 레코드 이동·삭제·초기화를 자동 실행하지 않음.
- 예상하지 않은 upstream 소스는 변경하지 않고 빌드 중단.
- 실제 pinned save_bindings/keymap_handle_set을 추출한 C 호스트 검사에서
  8개 레이어의 모든71위치 저장/읽기, 남겨진 구 빈자리 레코드 불변을 확인.
실제 장치 플래시 저장·재설치 시험을 대신하지 않습니다. 설치 전 장치 백업 필수입니다.

## 유지한 트랙볼·무선
v0.1.9의 core/runtime/hardware/behavior/input_processor/studio_profile C 파일은 동일합니다.
core.h에서 가상 입력·중앙 슬롯 시작 번호와 총키수만 변경했습니다.
USB Studio 잠금 off, BLE Studio off, 수동 토글 우선순위의 v2 저장, 좌우 CPI,
기존 센서·스캔·분할 BLE 경로, RF +8dBm 기본 요청 유지. UART/배터리 제어 추가 없음.

## 로컬 매퍼의 실제 구현
- 71위치 그림, 레이어 선택·키 클릭·키코드/수정키/사용자 동작 인수 편집.
- 기본 Studio 공개 protobuf를 구현한 원본 JS codec + AB/AC/AD framing + Web Serial.
- 장치 이름/잠금/물리 레이아웃/키맵/동작 목록/매개변수 정보를 실제 요청하는 코드.
- 알려진 MODU 71/77 좌표 외의 장치 쓰기 거부. 실제 기기의 동작 ID를 읽고 사용.
- 77위치 장치에서는 보이는71위치를 실제구번호로 변환해 읽고 씀.
- 저장 전에 최신 장치 상태 비교, 다른 미저장 초안 보호, 바뀐 키만 순차 적용.
- 적용 실패 때 시도한 위치의 RAM 초안을 복원 요청. Save는 성공 시 한번만 호출.
  Save 타임아웃은 결과 불명으로 표시하며 성공/롤백을 단정하거나 자동 재시도하지 않음.
- 저장 후 다시 읽어 배정 비교. 쓰기 전 장치 백업 JSON 다운로드.
- PC 프로젝트 JSON 저장/열기,71/77 프로젝트 변환, 기본 키+고급 규칙 소스 ZIP 내보내기.
- 포트 하나를 점유하므로 공식 Studio와 동시에 연결하지 않음.

## 고급 기능은 지금 어떻게 적용되나
콤보(물리키2~5개,레이어,판정시간),매크로(키/마우스 탭·누름·해제·지연,최대24단계),
탭댄스(1~8회 탭,판정시간)를 폼으로 편집합니다. 종류별 최대32개는 편집기 상한이며
해당 조합을 모두 장치에 실었을 때 메모리가 충분하다는 보장은 아닙니다.
매크로 기본 대기/탭40ms; 동시에 여러 긴 매크로를 실행하는 사용은 피하세요.

정의는 `config/local-mapper.json` → 검증된 생성기 → DTS → Actions 재빌드입니다.
규칙 생성/내부 수정의 USB 실시간 저장과 읽기는 아직 없습니다. 새 동작을 넣어 빌드한 뒤
그 동작을 다른 키에 배정하는 것은 일반 USB 키맵 저장으로 처리합니다.
Tap Dance는 ZMK의 탭 횟수별 동작이며 Vial의 모든 hold/tap-hold 규칙을 복제하지 않았습니다.

## 실행한 검사
- 펌웨어 Python/호스트 검사 214개: 기존193 + 저장주소5 + 소스생성16.
- 실제 추가 C helper와 pinned 저장/읽기 함수는 GCC/ASan/UBSan 호스트로 실행.
- 기존 core C 검사 및 HEX/UF2 합성 selftest: 별도 로그 참조.
- JS codec/모델/쓰기 안전성/ZIP 검사31개. 독립적인 protobuf golden bytes도 포함.
- 실제 앱 JS를 Chromium 테스트 문서에 주입한 UI/가짜 Web Serial 검사32개.
  71/77기기 각각 Client의 프레임 읽기→변경→Save→재조회·연결해제를 실행.
- 실제 앱에서 생성한 ZIP을 Python ZIP reader로 읽고 checksum 검증,
  고급 설정을 compile_mapper.py에 넘겨 DTS를 생성하는 교차 검사.

## 수행하지 않은 검사
새 펌웨어의 전체 Zephyr/ARM 컴파일·UF2 생성, 실제 기기 NVS 이행·USB·센서·BLE,
Windows CMD/PowerShell 서버 실행, 사용자 PC의 Chrome/Edge 포트 선택·USB 실제 쓰기.
이 환경의 Chromium은 loopback/file navigation이 제한되어, 동일 앱 자산을 테스트 문서에
주입해 검사했습니다. HTTP 서버/브라우저 권한 경로까지 통과한 것으로 표시하지 않습니다.
미리보기 이미지는 이 앱의 실제 로컬 UI 렌더이며 실제 장치 연결 화면은 아닙니다.

## 출처·라이선스
ZMK Studio messages/ts-client 공개 프로토콜과 ZMK 공식 behavior 문서 참고.
화면·클라이언트 코드는 이번 제작의 독립 구현이며 공식 Studio 수정판/공식 제조사 앱이 아닙니다.
기존 MODU 소스의 EKS/Ryu 비상업 라이선스와 고지는 보존합니다.

https://zmk.dev/docs/features/studio
https://github.com/zmkfirmware/zmk-studio-messages
https://github.com/zmkfirmware/zmk-studio-ts-client
https://zmk.dev/docs/keymaps/behaviors/macros
https://zmk.dev/docs/keymaps/behaviors/tap-dance
https://zmk.dev/docs/keymaps/combos
