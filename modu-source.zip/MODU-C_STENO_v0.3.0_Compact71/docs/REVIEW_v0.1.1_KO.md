# MODU-C v0.1.1 검토 보고서

검토일: 2026-09-08  
대상: 제공한 `MODU-C_Studio_Trackball_v0.1.0.zip`  
결과: 오류 수정 소스 v0.1.1 / ZMK 전체 컴파일 및 실기 검증은 미실시

## 결론

**v0.1.0은 수정할 문제가 있는 초기 통합본입니다. 다음 Actions 빌드는 v0.1.1로 진행하는 편이 맞습니다.** 기존 순수 C 검사와 정적 검사를 다시 실행하면 통과했지만, 실제 런타임에 모의 스케줄·전송을 연결한 회귀 검사에서 추가 문제가 드러났습니다. v0.1.1에는 그 수정과 검사 코드를 함께 포함했습니다.

이 검토는 문서만 읽고 내린 판단이 아닙니다. 실제 v0.1.0의 `runtime.c`/`core.c`를 호스트용 테스트 대역으로 컴파일해 실패 조건을 재현하고, 같은 검사를 수정본에 적용했습니다. 다만 이것은 Zephyr 자체, 센서나 BLE를 에뮬레이션한 결과가 아니며 정확한 pinned 헤더/ABI 호환성도 검증하지 않습니다.

## 1. 발견한 문제와 수정

### 1-1. 오래된 CPI 동기화 값이 최신 설정을 덮어씀 — 높음

**재현:** 중앙 장치의 동기화가 600 CPI를 복사해 둔 직후 새로운 키 입력으로 1200 CPI를 설정하는 순서를 모의했습니다. 이전 코드에서는 오래된 명령이 `modu_remote_cpi()`를 통해 중앙의 저장 대상 설정까지 600으로 다시 썼습니다. 테스트에서는 최종 설정이 1200이어야 한다는 조건이 실패했습니다.

**수정:** 중앙 장치가 원하는 CPI의 원본을 유지합니다. 중앙으로 돌아온 하드웨어 적용 호출은 설정을 재작성하지 않고 최신 설정을 읽어 로컬 센서 작업에 전달합니다. 주변 장치에서는 주소가 자기 쪽인 CPI 명령만 저장·적용합니다.

관련: `modules/modu-control/src/runtime.c:137`  
회귀: `test_stale_sync_does_not_rewrite_desired_cpi`

실제 장치 적용까지 원자적이라는 뜻은 아닙니다. 우측 전달 지연·선점 상황은 재전송을 통해 최신값으로 맞추는 구조이며, 센서 적용 완료 확인 응답을 새로 구현한 것은 아닙니다.

### 1-2. 오른쪽 전송 실패가 로컬 성공에 가려질 수 있음 — 높음

기존 private 동작은 `GLOBAL` locality였습니다. 공개 ZMK의 현재 `behavior.c`는 이 경로에서 주변 장치 호출의 반환값을 확인하지 않고 로컬 호출 결과를 반환합니다. 이 반환 정책을 모의해 우측 전달을 `-ENOTCONN`으로 실패시키면 v0.1.0의 호출은 성공으로 보였습니다.

**수정:** private `modu_hw`를 `EVENT_SOURCE`로 변경했습니다. 왼쪽은 로컬 source, 오른쪽은 MODU-C에서 유일한 peripheral source **0**을 사용합니다. 논리 방향 번호 right=1을 그대로 peripheral 번호로 쓰지 않습니다. 전송 함수의 오류를 호출부로 돌려줍니다. 원래 메시지의 대상 side 확인도 수신부에 유지했습니다.

관련: `modules/modu-control/src/runtime.c:120`, `modules/modu-control/src/behavior.c:124`  
회귀: `test_remote_failure_propagates`

**한계:** 참고한 ZMK 웹 소스는 현재 main입니다. 고정된 `641514...` 커밋의 파일을 직접 확보한 것으로 간주하지 않습니다. 실제 pinned API 존재는 Actions preflight로 확인하도록 구성했습니다. 전송 함수의 성공은 큐 등록/전달 요청 성공일 수 있으며, 실제 PMW3610 적용의 종단 간 확인과 다릅니다.

### 1-3. 새 CPI·RF 설정 뒤 재시도 횟수가 제대로 보충되지 않음 — 중간~높음

기존 초기 재동기화 횟수를 소진한 후 CPI를 새로 바꿔도 재시도 횟수를 다시 채우지 않았습니다. RF 변경은 즉시 전송 외에 새 동기화 예약이 없어, 실패한 값의 재적용을 기대하기 어려웠습니다.

**수정:** CPI 변경·트랙볼 복원·RF 변경마다 제한된 재동기화 예약과 재시도 예산을 다시 설정합니다. 증가 명령을 반복하는 대신 현재의 **절대 CPI/TX 인덱스**를 재전송하므로 중복 증가하지 않습니다. 재시도 소진 뒤에도 실패하면 로그를 남깁니다.

관련: `modules/modu-control/src/runtime.c:31`, `modules/modu-control/src/runtime.c:243`  
회귀: `test_cpi_rearms_retry_budget`, `test_tx_rearms_retry_budget`

이 방식은 무한 재시도가 아닙니다. 연결이 회복되지 않으면 재연결이나 설정 재실행이 필요할 수 있습니다. RF는 이전과 동일하게 영구 저장하지 않고 연결 변화/재부팅 때 기본 출력 요청으로 돌아갑니다.

### 1-4. 방향키 모드에 다시 들어가도 이전 입력 간격이 남음 — 중간

방향키 입력 간격을 500ms로 두고 한 번 입력한 다음 마우스 모드를 거쳐 바로 돌아오면, 이전의 `next_at` 때문에 새 움직임의 첫 키 입력까지 기다렸습니다. 모의 테스트에서는 12ms 시점에 새 입력이 나와야 하는 조건이 실패했습니다.

**수정:** 모드/세대 변화 시 대기 큐뿐 아니라 다음 입력 시각과 방향 순서도 초기화합니다. 이미 눌린 가상 키는 해제한 뒤 새 모드로 넘어갑니다.

관련: `modules/modu-control/src/runtime.c:54`, `modules/modu-control/src/runtime.c:182`  
회귀: `test_arrow_reentry_is_not_delayed`

### 1-5. 공을 반대로 굴려도 이전 방향의 대기 키가 뒤늦게 섞임 — 중간

오른쪽 키 입력 여러 개를 대기시킨 직후 왼쪽으로 돌리면, 이전 오른쪽 대기 입력이 살아 있어 왼쪽·오른쪽이 번갈아 나올 수 있었습니다.

**수정:** 반대 방향으로 새 키 입력이 확정되면 이전 반대편 대기분을 버립니다. 주축 우선 모드에서는 다른 축의 대기분도 비웁니다. 이미 눌린 키는 정상 해제하며, 대각선 모드에서는 허용된 두 축을 유지합니다.

관련: `modules/modu-control/src/runtime.c:200`  
회귀: `test_reverse_discards_opposite_pending_taps`, `test_repeat_interval`, `test_left_and_right_pulses_are_independent`

### 1-6. 빌드 전처리에서 삭제된 속성을 다시 살릴 수 있음 — 중간

DTS에서 `input-processors`를 먼저 지정하고 `/delete-property/ input-processors;`로 지웠는데도 기존 생성기가 옛 체인을 찾아 다시 붙였습니다. 삭제된 `chosen` 참조도 이전 지정값으로 해석했습니다. 문자열 안의 세미콜론·속성처럼 보이는 문장·주석 기호 처리와 주석 처리한 include에도 경계 문제가 있었습니다.

**수정:** 속성 지정과 삭제를 순서대로 처리하고, 따옴표 안의 내용은 주석/새 속성으로 취급하지 않습니다. include 확장 전에 주석을 제거합니다. 필요한 센서/스캔 참조가 최종적으로 없으면 예전 값을 추측해 쓰지 않고 중단합니다.

관련: `scripts/prepare_build.py:20`, `scripts/prepare_build.py:66`, `scripts/prepare_build.py:93`  
검사: `tests/test_prepare.py`의 합성 fixture 18개

**구분:** 이것은 생성기의 결함을 합성 자료로 재현한 것입니다. 실제 MODU 고정 소스에 이 삭제/주석 패턴이 존재한다고 확인한 것은 아닙니다. 이 스크립트는 전체 DTS 언어와 C 전처리기를 대체하지 않는 보수적 연결 생성기입니다.

### 1-7. 진단 ZIP에 `.config`가 누락될 수 있음 — 중간

빌드 스크립트는 생성된 `.config`를 진단 폴더로 복사했지만, Actions upload-artifact는 숨김 파일을 기본적으로 제외합니다. 따라서 복사는 됐어도 최종 진단 ZIP에서는 빠질 수 있었습니다.

**수정:** 진단 업로드에만 `include-hidden-files: true`를 지정했습니다. 저장소 전체 숨김 파일을 공개하는 설정은 아닙니다. 실제 워크플로·`BUILD_WORKFLOW_COPY.txt`·HTML 내부 복사본을 함께 갱신했습니다. 링크 맵도 `zephyr.map`뿐 아니라 ZMK의 `zmk.map` 경로를 수집합니다.

관련: `.github/workflows/build.yml:73`, `scripts/build_firmware.py`  
검사: YAML 파싱, 워크플로 복사본 일치 및 경로 검사. 실제 GitHub 업로드 시험은 미실시.

## 2. 확인한 결과

| 검사 | v0.1.0에 같은 검사 적용 | v0.1.1 |
|---|---|---|
| 기존 정적 검사와 순수 C 로직 | 통과 | 통과 |
| 새 런타임 호스트 시나리오 12개 | 6개 실패 / 6개 통과 | 12개 통과 |
| 확장한 DTS fixture 18개 | 6개 실패 / 12개 통과 | 18개 통과 |
| HEX/UF2 합성 자료 검사 | 통과 | 통과 |
| 실제 ZMK 전체 컴파일·Studio·센서 | 미실시 | 미실시 |

순수 C 테스트의 180,378은 assertion 실행 횟수입니다. 독립 테스트가 18만 개라는 뜻이 아닙니다. 런타임의 실제 소스를 호스트용 스케줄러·전송·설정 저장 대역과 연결해 실행했지만, Zephyr의 스레드/인터럽트나 장치 드라이버 전체를 테스트한 것은 아닙니다.

로그: `docs/LOCAL_TEST_LOG.txt`, `docs/review_logs/runtime_before.txt`, `runtime_after.txt`, `prepare_before.txt`, `prepare_after.txt`.

## 3. 변경하지 않은 부분

v0.1.0 대비 `config/modu.keymap`, `config/modu-controls.dtsi`, `config/modu.json`, `config/info.json`, `config/west.yml`, `build.yaml`은 바이트 단위로 동일합니다. 따라서 이번 검토 수정 때문에 기존 키 위치나 제어 키 배정이 다시 바뀌지 않습니다.

보드 `ms88sf3/nrf52840`, 좌우 shield 이름, ZMK/MODU 커밋 고정, 원본 라이선스·고지 및 네 개 HEX/UF2 안전 스크립트를 보존했습니다. 외부 썸클러스터 스캔이나 PMW3610 드라이버 자체를 새로 교체하지 않았습니다. 좌우 센서 CPI와 소프트웨어 포인터 배율은 계속 별개의 동작입니다. USB Studio만 사용한다는 구성도 유지했습니다.

## 4. 아직 확정할 수 없는 항목

정확한 의존 커밋의 파일을 이 환경에서 다운로드하지 못했고 west/ARM 빌드 도구가 없었습니다. 따라서 실제 preflight 통과, Zephyr API/장치 트리 호환, 링크와 용량, USB Studio 연결/저장/복원, 센서 CPI 단위·장착 방향, 오른쪽 명령 수신과 RF 실제 적용은 미확인입니다.

키 매핑/제어 메타데이터를 등록하는 코드가 있어도 실제 Studio 화면을 연 결과를 제시하지는 않습니다. 실시간 CPI/실제 RF 출력 조회창·슬라이더도 구현하지 않았습니다. 센서가 없는 썸 유닛에서 존재하지 않는 센서가 동작할 수 있는 것은 아닙니다.

ELF 적재 범위 검사와 UF2 구조 검사는 존재하지만, 최종 UF2 각 바이트와 ELF의 완전 일치 증명이나 장치 부트로더 호환성 시험은 아닙니다. 빌드 컨테이너와 Actions major 태그도 가변 참조입니다. 이전 코드의 안전 검사를 지우거나 더 느슨하게 만들지 않았습니다.

## 5. Codespaces 없이 적용

아직 저장소에 올리지 않았다면 v0.1.0 대신 v0.1.1의 내부 파일 전체를 업로드합니다. 이미 개인 시험용 저장소에 올렸다면 같은 경로로 이번 내부 파일 전체를 교체합니다. 키맵만 교체하는 패치가 아니므로 `modules/`, `scripts/`, `tests/`, `.github/`를 빠뜨리지 않습니다. 파일 삭제나 보드 변경은 필요하지 않습니다.

커밋 예:

```text
Fix trackball state, split retries and build diagnostics (v0.1.1)
```

`Actions → Build MODU-C Studio → Run workflow → main`으로 실행합니다. `Static and native tests`만 성공한 것은 펌웨어 빌드 성공이 아닙니다. 좌우 Compile과 Package까지 성공한 실행의 `modu-c-studio-firmware`가 설치 후보입니다. 실패하면 해당 실행에 생성된 `modu-diagnostics-left/right` 또는 실패 단계 로그가 원인 확인 자료입니다.

## 참고한 공식 자료

- ZMK behavior locality와 메타데이터: https://zmk.dev/docs/development/new-behavior
- ZMK 현재 main의 호출 경로: https://github.com/zmkfirmware/zmk/blob/main/app/src/behavior.c
- upload-artifact 숨김 파일 기본값: https://github.com/actions/upload-artifact
- Studio 기능과 요구조건: https://zmk.dev/docs/features/studio

웹에서 확인한 현재 문서/소스와 다운로드하지 못한 고정 커밋의 검증을 구분합니다. 로컬 결함 재현의 근거는 이 패키지의 소스와 비교 로그입니다.

## 검토 대상 식별

원본 v0.1.0 ZIP SHA-256:

```text
b17160918d8ab0766b87788c02d2b58c6026af85cc0e3aa96221839b69aafbd7
```

v0.1.1 구성 파일의 SHA-256은 루트 `SOURCE_SHA256SUMS.txt`에서 확인할 수 있습니다. 파일이 맞다는 확인이지 펌웨어 동작 보증이 아닙니다.
