# MODU-C STENO v0.3.0 빌드 결과물 안내


1. ZIP을 풀고, 내부의 `config`, `modules`, `scripts`, `tests`, `docs`, `.github` 및 루트 파일들을 본인 GitHub **소스 저장소 루트**에 넣습니다. 바깥 폴더를 한 겹 더 올리지 마세요.
2. `.github/workflows/build.yml`도 이 버전으로 교체한 뒤 Actions에서 **Build MODU-C Studio STENO → Run workflow**를 실행합니다. 모든 파일이 업로드된 후 실행하세요.
3. Static and native tests, Compile left/right, Package both UF2 files가 모두 성공한 실행의 **modu-c-studio-firmware** 결과물을 받습니다.
4. 기존 정상 펌웨어를 보관하고, 결과물의 `modu_left.uf2`와 `modu_right.uf2`를 각각 맞는 쪽에 설치합니다. 하드웨어 모듈 교체나 추가 배선은 하지 않습니다.

**기존 자동 빌더의 payload/modu-source.zip에 이 ZIP만 덮어쓰는 방식이 아닙니다.** 그 빌더의 고정 SHA 검사는 별도 갱신이 필요합니다. 이 패키지는 일반 소스 저장소 업로드 방식입니다. Codespaces는 쓰지 않습니다.

권장 첫 확인은 한글 입력기에서 전환키, 가/나, 약어 1개, 숫자 1/0, !/), F1/F10/F11/F12, ~/`/Esc, 다시 일반 모드 B, 좌우 트랙볼 순서입니다. 처음에는 게임이나 중요한 문서 대신 빈 메모장에서 확인하세요.



키맵: 동봉 STENO_MAPPING_KO.md 참고. 기호/겹모를 누른 채 대상 키를 누르세요. 설치 전 기존 정상 UF2를 백업하세요.
