# MODU-C v0.1.3 — 전체 코드·트랙볼 연결·Studio 구성 검토

검토일: 2026-09-08  
검토 기준: 대화에 첨부된 `MODU-C_Studio_Trackball_v0.1.2.zip`  
산출: 검토 수정 소스 v0.1.3 / 실제 ZMK 전체 빌드·UF2 생성·기기 연결 미실시

## 1. 결론과 검증 수준

요청한 좌우 모드·임시 전환·센서 CPI·가상 방향키·무선 출력은 단순 메뉴 이름만 추가한 것이 아니라 상태 관리, 입력 변환, 대상 장치 전달, 센서 설정 호출까지 코드가 연결되어 있습니다. 그러나 **드라이버 호출 코드가 있다는 사실과 실제 센서에서 설정이 적용됐다는 사실은 다릅니다.** 특히 고정 의존 소스와 Zephyr 빌드 환경을 이 실행 환경에서 확보하지 못했습니다.

이번에는 실제 `input_processor.c`까지 호스트 검사에 포함하고, 빌드 전 처리의 오류를 수정했습니다. USB 전용 Studio를 명시하고, 이후 실제 컴파일 결과에서 센서·좌우 입력 경로·레이아웃·USB를 검사하도록 보강했습니다. 소스·모의 검사를 통과한 설치 후보 준비물이지 실기 검증 안정판이 아닙니다.

v0.1.3으로 다음 GitHub Actions 빌드를 진행하는 편이 맞습니다. 기존 키 배정·CPI 기본값·모드 상태 정책·양쪽 RF 최대 +8 dBm은 바꾸지 않았습니다.

## 2. 발견하고 수정한 문제

### A. 정상적인 단일 phandle 표기를 거부함

이전 `phandle()`은 `<&label>`만 허용하고 `&label` 표기는 거부했습니다. `chosen`의 scanner/transform과 listener의 `device`에 bare 참조를 사용한 합성 자료에서 정상 구성이 빌드 전 오류가 되는 것을 재현했습니다.

수정: 단일 bare 참조와 단일 bracketed 참조를 모두 허용합니다. 여러 phandle, 추가 인수, 잘못된 형식을 부분 문자열로 통과시키지는 않습니다.

**주의:** 실제 고정 MODU 소스가 이 표기를 쓴다고 이번에 확인한 것은 아닙니다. 원본의 실제 형태와 무관하게 생성기에서 재현한 결함입니다.

### B. 문자열 안의 중괄호와 노드 이름을 문법으로 오인함

설명 문자열 안의 `{` 또는 `trackball_listener { }` 같은 내용이 노드 검색·하위 본문 제거에 간섭했습니다. 문자열 내용을 같은 길이의 공백으로 마스킹하여 문법 검색에서 제외하도록 수정했습니다. 실제 속성 값은 원문에서 읽습니다.

이는 전체 DTS/C 전처리기를 구현했다는 뜻은 아닙니다. 조건부 include, 복잡한 macro나 익숙하지 않은 upstream 구조는 여전히 보수적으로 중단할 수 있습니다. Zephyr의 실제 DTS 컴파일과 뒤의 EDT 검사가 최종 구조 확인 단계입니다.

### C. 오른쪽 입력 경로 누락·중복과 비활성 노드가 통과함

이전 생성기는 오른쪽 listener가 존재하기만 하면 입력 `device`가 없어도, 왼쪽 센서와 같은 device를 가리켜도 통과했습니다. 주요 listener/센서/scanner가 비활성 상태인 경우도 충분히 확인하지 않았습니다.

수정: 좌우 listener의 실제 참조를 요구하고 오른쪽과 왼쪽 장치가 같은 경우 거부합니다. 주요 노드의 비활성 상태도 거부합니다. preflight 진단에 각 listener의 입력 장치 이름을 남깁니다.

### D. USB 사용과 USB 전용을 구분하지 않음

v0.1.2에는 왼쪽 USB Studio snippet과 `CONFIG_ZMK_STUDIO=y`가 있었지만, Studio의 BLE transport를 명시적으로 끄지는 않았습니다. 검토한 공개 ZMK 현재 main Kconfig는 BLE 조건에서 Studio GATT를 기본 y로 둡니다. 따라서 USB snippet을 넣었다는 사실만으로 USB 전용임을 보장하지 않습니다.

수정: 왼쪽 build command에 `-DCONFIG_ZMK_STUDIO_TRANSPORT_BLE=n`을 추가했습니다. **키보드용 BLE나 좌우 split BLE를 끄는 변경이 아닙니다.** 오른쪽에는 Studio snippet을 넣지 않습니다. 정확한 pinned Studio transport Kconfig 이름은 Actions preflight에서 확인하도록 했습니다. 컴파일된 `.config`에서 UART/RPC/metadata/settings가 활성이고 Studio GATT가 비활성인지 다시 확인합니다.

이는 pinned 커밋에서 BLE transport가 실제로 켜진 UF2를 관측했다는 주장이 아니라, 소스 설정의 독점성 보완입니다.

### E. 기존 빌드 후 검사만으로는 양쪽 트랙볼 연결을 증명하지 못함

기존 검사는 주요 Kconfig와 DTS에 선택된 레이아웃 문구가 있는지, ELF flash 영역이 맞는지를 주로 확인했습니다. 왼쪽과 오른쪽의 센서·listener·processor 연결이 모두 맞는지를 확인하는 검사는 부족했습니다.

추가한 `scripts/check_integration.py`는 Actions에서 compiler-produced `edt.pickle`을 읽어 다음을 확인하도록 작성했습니다.

| 영역 | 검사 조건 |
|---|---|
| 물리 레이아웃 | 선택된 layout의 keys 75개, 원본 67개 순서와 가상 방향 8개 map 유지 |
| 스캔 | 기존 alternate-thumb scanner 연결과 transform 크기 |
| 로컬 센서 | side와 빌드 대상 일치, 실제 PMW3610 참조, sensor/bus 활성 상태 |
| 왼쪽 중앙 | 두 listener가 각각 local PMW / 별도 input-split 장치에 연결 |
| 좌우 변환 | MODU processor가 각각 한 번, 마지막 위치에 side 0/1로 연결 |
| 우회 방지 | layer override 또는 선행 code-mapper/behavior 체인이 XY 처리를 우회하는 경우 중단 |
| 오른쪽 주변 | 로컬 PMW 센서가 input-split 송신 장치에 연결, 중복 MODU 변환 없음 |
| 센서/RF 명령 | 내부 `modu_hw` 전달 동작 존재 |
| USB | Studio UART가 활성 USB CDC ACM 장치와 활성 부모에 연결 |

통과 시 `modu-integration.json`을 진단 폴더에 보존합니다. 기존 ELF 영역·HEX/UF2 검사를 제거하거나 느슨하게 하지 않았습니다. `check_built.py`는 명시적 `--zephyr-base`로 같은 Zephyr checkout의 devicetree Python 모듈을 사용합니다. 워크플로에는 이전에도 PYTHONPATH가 있어, 이것을 기존 Actions에서 재현된 import 오류라고 주장하지 않습니다.

**이 새 검사는 합성 EDT 객체에서만 실행했습니다. 실제 compiler-produced EDT 검사 통과 기록은 아직 없습니다.** 알 수 없는 원본 연결을 만나면 빌드를 멈추므로, 검사 통과를 위해 보드/핀/검사를 임의 변경하면 안 됩니다.

## 3. 기능별 코드 경로

### 좌우 이동 입력

```text
왼쪽 PMW → 원래 driver/축 보정 → local listener → MODU processor(side 0)
오른쪽 PMW → 원래 driver/축 보정 → split 송신 → 왼쪽 remote listener → MODU processor(side 1)
                                                            ↓
                      mouse / scroll → 해당 상대 이동 이벤트 → ZMK 입력 listener/HID
                      arrow → virtual position 67..74 → 현재 keymap/Studio 배정
                      off → 트랙볼 상대 이동 소비
```

좌우 상태, 소프트웨어 배율, 이동 나머지, 가상키 대기열은 분리되어 있습니다. 오른쪽에서 한 번 더 MODU 변환하지 않고 중앙에서 변환하는 구조입니다. 기존 upstream의 회전/축 보정 코드는 교체하지 않았습니다. upstream에서 이미 버린 미세 이동까지 이 모듈의 나머지 누적으로 복원할 수는 없습니다.

### 임시 모드와 영구 모드

공개 mode/hold 동작은 중앙에서 실행합니다. 임시 모드는 source와 키 위치로 구분한 16개 한정 스택을 좌우 별도로 사용합니다. 마지막으로 누른 임시 키를 우선하고, 손을 떼면 남은 임시 모드나 영구 모드로 돌아갑니다. 임시 모드 도중 영구 모드를 바꾸면 그 새 영구 모드로 돌아갑니다. BLE 연결 변화는 놓친 key release 때문에 모드가 고정되지 않도록 임시 상태를 취소합니다.

`Disabled`는 볼의 X/Y 이동 비활성입니다. 다른 마우스 클릭 입력까지 모두 차단하는 모드가 아닙니다.

### 실제 센서 CPI

```text
Studio에서 좌/우 CPI 제어 키 배정 → 실제 키 누름 → 중앙 desired CPI 갱신
→ 해당 MCU로 절대 CPI 명령 → local worker → 실제 sensor device
→ sensor_attr_set(SENSOR_CHAN_ALL, PMW3610_ALT_ATTR_CPI, encoded value)
```

왼쪽/오른쪽은 별도 동작입니다. 어느 손의 키에 배정했는지와 적용 대상은 무관합니다. 오른쪽은 peripheral source 0으로 전달하며 logical side 1과 혼동하지 않습니다. 수신부에서도 side를 확인합니다. CPI 인코딩은 내려받은 드라이버의 변환 macro와 대조합니다. 소프트웨어 포인터 배율로 대체한 API가 아닙니다.

CPI 기본 600, 허용값 200~3200/200단위. 센서 준비 대기 및 전달 재시도가 있지만 무한 재시도나 센서 적용 완료 응답 프로토콜은 아닙니다. 큐 전달 성공과 실제 센서 적용 성공은 같지 않습니다. 센서가 없는 유닛에서 센서가 생기는 것은 아닙니다.

### 방향키와 Studio 재배정

67~70은 왼쪽 ↑↓←→, 71~74는 오른쪽 ↑↓←→입니다. 12ms press/release를 정상 position-event 경로로 보냅니다. 방향키 모드에서 해당 가상 위치의 현재 레이어 배정이 사용됩니다. 마우스 모드의 아날로그 X/Y까지 keymap의 가상키 배정으로 바꾸는 것은 아닙니다.

이 방향키 구현은 이동량에 따른 **짧은 키 입력**입니다. 지속 hold 방식이 아니며, 대각선 허용도 두 축을 순차 입력하는 방식입니다. 게임의 동시 WASD hold와 동일하다고 설명하면 안 됩니다.

가상 이벤트의 source는 중앙/local입니다. 오른쪽 가상 방향에 source-locality bootloader/reset을 배정하면 자동으로 오른쪽 장치에 적용되는 구조가 아닙니다. 부트로더는 기존 물리 키 `Fn → 왼쪽 Ctrl 위치 → 5(왼쪽)/6(오른쪽)`를 사용합니다.

### RF 최대 기본값과 저장

좌우 빌드 기본값 `CONFIG_BT_CTLR_TX_PWR_PLUS_8=y`, 런타임 초기/기본값 복원/재연결 값은 MC_TX_PLUS_8입니다. 수동 감소·증가·직접 지정은 세션 한정입니다. 광고/능동 검색은 최대 기본 요청을 유지합니다. 이 기능은 수신 감도나 USB 신호 세기 변경이 아닙니다.

트랙볼의 영구 모드·CPI·속도·반전·대각선 설정은 마지막 변경 약 1.2초 뒤 자체 settings record에 저장합니다. 임시 모드와 RF 값은 저장하지 않습니다. Studio keymap 저장과 이 실행 설정 저장은 별개입니다.

## 4. Studio 디자인과 사용 범위

**독립 제작한 설정 앱이나 트랙볼 대시보드가 아닙니다. 기본 ZMK Studio에 고정 layout과 사용자 정의 동작 메타데이터를 제공합니다.**

`STUDIO_LAYOUT_PREVIEW_KO.html`은 source-based read-only preview입니다. config/modu.json의 위치/크기와 config/modu.keymap의 배정을 사용합니다. 실제 Studio에 연결하거나 설정을 변경하지 않습니다. PNG도 이 안내 HTML을 Chromium으로 렌더링한 것이며 실기 Studio screenshot이 아닙니다.

레이아웃은 양손 본체 → 아래 썸키 → 더 아래 좌우 가상 방향 4개씩입니다. 기존 67개 논리 위치 중 6개는 원본 빈 자리이며, 61개 일반/썸 입력 위치와 가상키 8개를 표시합니다. 실제 장착 스위치 수는 유닛에 따라 다릅니다. 본체를 실물 모양으로 렌더링하거나 트랙볼 원형 위젯을 넣은 디자인이 아닙니다.

Studio로 전달되는 physical-key 속성은 위치/크기/회전입니다. JSON의 L/R label, 안내 화면의 한국어 설명/고정 방향 제목/기능별 색상이 그대로 Studio에 고정 적용되는 것은 아닙니다. 실제 keycap 표시는 배정한 동작에 따라 달라집니다.

레이어는 Base/Fn/MODU Controls 및 예비 5개입니다. 공개 MODU 제어 동작은 좌우 각 11개와 공통 2개, 총 24개 정의입니다. 실제 목록 표시 확인은 기기 연결 후 해야 합니다. 내부 전달용 `MODU Internal: Hardware transport (do not assign)`는 사용자 설정용이 아니며 특별한 숨김 처리를 검증한 것이 아닙니다.

| Studio에서 배정할 항목 | 선택 예 |
|---|---|
| MODU Right: Trackball while held | Scroll |
| MODU Left: Trackball mode | Arrow keys |
| MODU Right: Sensor CPI | Set exact value → 1200 CPI |
| MODU Left: Sensor CPI | Increase / faster |
| MODU Right: Pointer speed | Set exact value → 150 (%) |
| MODU Both: Radio TX power | Reset to default 또는 Maximum |

**키에 CPI 1200을 배정·저장하는 것과 현재 CPI가 즉시 1200으로 바뀌는 것은 다릅니다.** 여기서는 배정한 키를 눌렀을 때 그 명령이 실행됩니다.

현재 범위 밖: 실시간 CPI/RF 조회와 전용 슬라이더, 입력 그래프/신호 측정, 새로운 driver/pin/회전각/폴링 주기의 Studio 편집, 새 인코더 회전 변환, 모든 미지원 썸 유닛의 자동 지원. 기본 Studio의 콤보/매크로 내부/일반 동작 속성 편집 제한도 그대로입니다. 이 패키지는 그 제한을 해제한 별도 Studio fork가 아닙니다.

## 5. 실행한 검사

| 구분 | 결과 | 의미 |
|---|---:|---|
| DTS preflight | 26개 통과 | 합성 소스, 18개 기존 + 8개 새 회귀 |
| runtime/input 호스트 | 28개 통과 | 실제 core/runtime, 새 8개는 실제 input_processor 포함. API/장치/스케줄러는 대역 |
| 컴파일 구조·USB 설정 검사기 | 31개 통과 | 합성 EDT/config와 west 명령 생성. 실제 Zephyr 빌드 아님 |
| RF 기본값 검사 | 8개 통과 | 코드 정책과 합성 `.config` 정상/거부 |
| Python unittest 총계 | **93개 통과** | 새 모듈 47개가 모두 개별 결함이었다는 뜻은 아님 |
| 순수 C 핵심 로직 | 180,378 assertion 통과 | C11 엄격 경고 + ASan/UBSan. 독립 테스트 18만 개가 아님 |
| 정적 보존·HEX/UF2 자체 검사 | 통과 | 기존 안전 검사, 합성 파일. 설치용 UF2 생성 아님 |
| HTML 브라우저 검사 | 통과 | 탭 전환·키 상세 표시·JS 오류 없음. 실제 Studio 시험 아님 |

새 parser/runtime 검사 16개를 포함한 62개 suite를 v0.1.2에 적용하면 5 failure + 4 error가 발생했습니다. 한 method의 subtest가 둘이므로 실패 method 수와 출력 건수는 다릅니다. 생성기 문제를 수정한 같은 62개 suite는 통과했고, 이후 EDT/USB 검사기 31개를 더해 93개가 통과했습니다. 새 input-processor 8개 자체는 기존 v0.1.2에서도 통과했습니다.

로그는 `docs/review_logs/v0.1.3_*.txt`와 `docs/LOCAL_TEST_LOG.txt`에 있습니다. 하드웨어 코드 `hardware.c`와 동작 등록 `behavior.c`는 읽고 경로를 검토했지만 실제 Zephyr 헤더로 컴파일한 것은 아닙니다. current main API 문서는 정확한 pinned 헤더 검증을 대신하지 않습니다.

## 6. 유지한 것과 다음 단계

v0.1.2 대비 config 전체, build.yaml, workflow, core/runtime/hardware/behavior/input_processor C 소스, 보드·의존 커밋, 원본 license/notice, 기존 4개 HEX/UF2 안전 스크립트를 바이트 단위로 보존합니다. 변경 범위는 build/preflight/post-build 검사, 호스트 테스트와 문서입니다. GPIO를 추측해서 변경하지 않았습니다.

전체 ZMK/Zephyr ARM 컴파일·링크/메모리 사용량·실제 generated DTS/EDT·UF2·USB Studio 저장/복원·CPI 실측·센서 장착별 방향·양쪽 동시 입력·HCI TX 적용·재연결·실제 해제 누락은 미검증입니다. 가드가 추가됐다는 이유로 이 검증을 완료했다고 보고해서는 안 됩니다.

Codespaces 없이 v0.1.3 ZIP 내부 전체를 본인의 시험용 GitHub 저장소 루트에 업로드하고 `Build MODU-C Studio` Actions를 실행합니다. Static/native만 아니라 **Compile left, Compile right, Package both**까지 성공한 `modu-c-studio-firmware` 산출물이 필요합니다. 양쪽을 같은 버전으로 업데이트해야 합니다. 기존 정상 좌우 UF2를 보관하세요. 진단은 `modu-diagnostics-left/right`입니다.

첫 실기 검사는 일반 키/썸키 → USB Studio 한 키 저장 → 양쪽 모드·임시 복귀 → 방향키 잔류 → 각 CPI 단독 변경 → 오른쪽 재연결 동기화 → RF 순으로 진행합니다. 이 순서는 향후 확인 항목이지 수행 완료 기록이 아닙니다. 저장된 Studio 키맵은 소스 기본 배정과 다를 수 있으며, 확인을 위해 무조건 초기화하지 마세요.

## 참고한 공개 원문

- ZMK Studio capabilities: https://zmk.dev/docs/features/studio
- Physical layout geometry: https://zmk.dev/docs/hardware-integration/physical-layouts
- Behavior metadata/locality: https://zmk.dev/docs/development/new-behavior
- Input processors: https://zmk.dev/docs/keymaps/input-processors
- Studio transport defaults (current main, NOT pinned verification): https://github.com/zmkfirmware/zmk/blob/main/app/src/studio/Kconfig
- Compiled EDT Python object model (current main): https://github.com/zephyrproject-rtos/zephyr/blob/main/scripts/dts/python-devicetree/src/devicetree/edtlib.py
- nRF52840 TX configuration: https://zmk.dev/docs/troubleshooting/connection-issues

공개 문서/현재 main과 이번에 확보하지 못한 정확한 고정 커밋을 구분합니다. 결함 재현의 직접 근거는 이 패키지의 비교 로그와 검사 소스입니다.
