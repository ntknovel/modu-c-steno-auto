# MODU-C v0.3.0 위치별 원본 배정

번호는 0부터 시작하는 Compact71 논리 번호입니다. 오른쪽 추가 B는 60이며, 왼쪽 B는 41입니다. 실제 키 위치를 바꾸지 않고 동작을 바꾸었습니다.

STENO의 `st_i_...`는 초성, `st_f_...`는 종성, `vext`는 겹모, `abbr`는 약어, `symbol`은 기호입니다. 키보드 그림과 한국어 라벨은 루트의 STUDIO_LAYOUT_PREVIEW_KO.html에서 볼 수 있습니다.

|번호|원래 위치|일반 모드 소스|속기 모드 소스|
|---:|---|---|---|
|0|Esc|`&mxesc`|`&mxesc`|
|1|1|`&mx1`|`&mx1`|
|2|2|`&mx2`|`&mx2`|
|3|3|`&mx3`|`&mx3`|
|4|4|`&mx4`|`&mx4`|
|5|5|`&mx5`|`&mx5`|
|6|6|`&mx6`|`&mx6`|
|7|7|`&mx7`|`&mx7`|
|8|8|`&mx8`|`&mx8`|
|9|9|`&mx9`|`&mx9`|
|10|0|`&mx0`|`&mx0`|
|11|Backspace|`&mxbsp`|`&mxbsp`|
|12|Tab|`&mxtab`|`&mxtab`|
|13|Q|`&kp Q`|`&st_i_b`|
|14|W|`&kp W`|`&st_i_j`|
|15|E|`&kp E`|`&st_i_d`|
|16|R|`&kp R`|`&st_i_g`|
|17|T|`&kp T`|`&st_i_s`|
|18|Y|`&kp Y`|`&st_f_s`|
|19|U|`&kp U`|`&st_f_g`|
|20|I|`&kp I`|`&st_f_d`|
|21|O|`&kp O`|`&st_f_j`|
|22|P|`&kp P`|`&st_f_b`|
|23|Home|`&kp LC(A)`|`&lang_ht RCTRL 0`|
|24|Caps|`&kp CAPSLOCK`|`&st_abbr_l`|
|25|A|`&kp A`|`&st_i_m`|
|26|S|`&kp S`|`&st_i_n`|
|27|D|`&kp D`|`&st_i_ng`|
|28|F|`&kp F`|`&st_i_r`|
|29|G|`&kp G`|`&st_i_h`|
|30|H|`&kp H`|`&st_f_h`|
|31|J|`&kp J`|`&st_f_r`|
|32|K|`&kp K`|`&st_f_ng`|
|33|L|`&kp L`|`&st_f_n`|
|34|;|`&kp SEMI`|`&st_f_m`|
|35|PgUp|`&ht300 SQT DQT`|`&st_abbr_r`|
|36|LShift|`&kp LSHIFT`|`&st_vext_l`|
|37|Z|`&kp Z`|`&st_i_kh`|
|38|X|`&kp X`|`&st_i_t`|
|39|C|`&kp C`|`&st_i_ch`|
|40|V|`&kp V`|`&st_i_p`|
|41|B|`&kp B`|`&st_i_double`|
|42|N|`&kp N`|`&st_f_double`|
|43|M|`&kp M`|`&st_f_p`|
|44|,|`&kp COMMA`|`&st_f_ch`|
|45|.|`&kp DOT`|`&st_f_t`|
|46|/|`&ht200 FSLH QUESTION`|`&st_f_kh`|
|47|PgDn|`&kp RSHIFT`|`&st_vext_r`|
|48|LCtrl|`&kp LCTRL`|`&kp LCTRL`|
|49|LAlt|`&kp LALT`|`&kp LALT`|
|50|LGUI|`&ht200 LC(Y) LBKT`|`&st_symbol_l`|
|51|RAlt|`&ht200 RCTRL RBKT`|`&st_symbol_r`|
|52|RCtrl|`&st_lang_return`|`&select_shift`|
|53|End|`&kp BSPC`|`&kp BSPC`|
|54|왼 엄지 바깥(LANG1)|`&lt250 NUM LGUI`|`&st_v_o`|
|55|왼 엄지 가운데(Space)|`&lt250 MOUSE MINUS`|`&st_v_eu`|
|56|왼 엄지 안쪽(Fn)|`&kp ENTER`|`&st_vu_enter`|
|57|오른 엄지 안쪽(Bspc)|`&kp SPACE`|`&st_veo_space`|
|58|오른 엄지 가운데(Enter)|`&lt250 NAV EQUAL`|`&st_v_i`|
|59|오른 엄지 바깥(Fn)|`&lt250 FN K_APP`|`&st_v_a`|
|60|오른 추가 B|`&st_mode`|`&st_mode`|

## 숫자 조합


아래의 “기호”, “겹모” 조합은 **속기 모드에서 해당 보조키를 누른 채 대상 키를 누르는 방식**입니다. 왼쪽·오른쪽 어느 보조키를 사용해도 됩니다.

| 원래 키 위치 | 단독 | 기호키와 함께 | 겹모키와 함께 |
|---|---|---|---|
| Esc | ~ | ` | Esc |
| 1 2 3 4 5 6 7 8 9 0 | 1 2 3 4 5 6 7 8 9 0 | ! @ # $ % ^ & * ( ) | F1~F10 |
| 숫자줄 오른쪽 Backspace | Backspace | Backspace | F11 |
| Tab | Tab | Tab | F12 |

F11/F12의 추가 위치는 Backspace/Tab으로 정했습니다. 4는 $, 5는 %인 일반 숫자줄 순서입니다. 기호와 겹모를 함께 누르면 **F키 기능이 우선**합니다.

일반 모드에서도 같은 숫자줄을 사용합니다. 기호는 기존 Cornix식 D+F 또는 J+K 조합으로 여는 Symbols 레이어, F키는 오른쪽 바깥 엄지의 Menu/Fn을 홀드하여 사용합니다. 일반 모드의 양쪽 Shift는 Shift이며 속기 겹모키로 동작하지 않습니다.

Backspace·숫자·F키는 누른 동안 키다운 상태를 유지하여 호스트의 반복 입력을 사용할 수 있게 했습니다. 속기 Tab 단독은 기존처럼 놓을 때 한 번만 출력합니다. 보조키를 먼저 떼어도 처음 선택된 키의 올바른 키업을 보냅니다. 보조키를 새 숫자 조합에 사용한 뒤 놓을 때 [, ?, ], Backspace 같은 단독 기호가 추가되지 않도록 했습니다.


## 레이어 번호

|번호|레이어|
|---:|---|
|0|Base|
|1|Num|
|2|MODU Controls|
|3|Mouse|
|4|Nav|
|5|Fn-BT|
|6|Symbols|
|7|STENO-KO|
|8|Select Nav|
