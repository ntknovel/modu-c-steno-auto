from pathlib import Path
import sys, unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from build_firmware import build_command
from check_integration import check_studio_config, IntegrationError
FLAGS=('ZMK_STUDIO','ZMK_STUDIO_RPC','ZMK_STUDIO_TRANSPORT_UART','ZMK_BEHAVIOR_METADATA','ZMK_KEYMAP_SETTINGS_STORAGE','ZMK_SPLIT_ROLE_CENTRAL')
def good():return ''.join('CONFIG_'+x+'=y\n' for x in FLAGS)+'# CONFIG_ZMK_STUDIO_LOCKING is not set\n# CONFIG_ZMK_STUDIO_TRANSPORT_BLE is not set\n'
class UnlockedTests(unittest.TestCase):
    def test_lock_off_in_left_build(self):
        cmd=build_command(ROOT,Path('/workspace'),'left',dict(board='ms88sf3/nrf52840',shield='modu_left',snippet='studio-rpc-usb-uart'))
        self.assertIn('-DCONFIG_ZMK_STUDIO_LOCKING=n',cmd)
        self.assertIn('-DCONFIG_ZMK_STUDIO_TRANSPORT_BLE=n',cmd)
    def test_accept_explicit_unlock(self):check_studio_config(good(),'left')
    def test_reject_locked_output(self):
        with self.assertRaises(IntegrationError):check_studio_config(good()+'CONFIG_ZMK_STUDIO_LOCKING=y\n','left')
    def test_reject_missing_lock_evidence(self):
        with self.assertRaises(IntegrationError):check_studio_config(good().replace('# CONFIG_ZMK_STUDIO_LOCKING is not set\n',''),'left')
    def test_reject_ble_even_when_unlocked(self):
        with self.assertRaises(IntegrationError):check_studio_config(good()+'CONFIG_ZMK_STUDIO_TRANSPORT_BLE=y\n','left')
    def test_draft_status_checked_but_no_keymap_write(self):
        source=(ROOT/'modules/modu-control/src/studio_profile.c').read_text()
        self.assertIn('zmk_keymap_check_unsaved_changes()==0',source)
        self.assertNotIn('zmk_keymap_save_changes(',source)
        self.assertNotIn('zmk_keymap_set_layer_binding_at_idx(',source)
    def test_mode_record_is_one_versioned_save(self):
        source=(ROOT/'modules/modu-control/src/runtime.c').read_text()
        self.assertIn('modu_control/v2',source)
        self.assertIn('memcpy(snapshot.profiles,mode_memory',source)
        self.assertIn('memcpy(snapshot.sides,core.config',source)
        self.assertNotIn('settings_delete(',source)
if __name__=='__main__':unittest.main()
