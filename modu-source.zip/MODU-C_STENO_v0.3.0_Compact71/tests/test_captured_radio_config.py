"""Actual ORIGINAL config excerpts + explicitly modified fixtures; NOT a Kconfig/ARM build."""
import importlib.util
import json
from pathlib import Path
import re
import unittest

ROOT=Path(__file__).resolve().parents[1]
fixture=json.loads((ROOT/'tests/fixtures/captured_original_radio_config.json').read_text())
spec=importlib.util.spec_from_file_location('radio_checker',ROOT/'scripts/check_built.py')
checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)

def modified_maximum(side):
    # Derived fixture only: original default was 0 dBm and dynamic control was disabled.
    cfg='\n'.join(fixture['halves'][side]['radio_and_required_excerpt'])+'\n'
    return cfg.replace('# CONFIG_BT_CTLR_TX_PWR_PLUS_8 is not set','CONFIG_BT_CTLR_TX_PWR_PLUS_8=y').replace(
        'CONFIG_BT_CTLR_TX_PWR_DBM=0','CONFIG_BT_CTLR_TX_PWR_DBM=8').replace(
        '# CONFIG_BT_CTLR_TX_PWR_DYNAMIC_CONTROL is not set','CONFIG_BT_CTLR_TX_PWR_DYNAMIC_CONTROL=y')

class CapturedRadioConfigTests(unittest.TestCase):
    def test_real_original_both_have_vendor_hci(self):
        for side in ('left','right'):
            self.assertIn('CONFIG_BT_HCI_VS=y',fixture['halves'][side]['radio_and_required_excerpt'])
    def test_real_original_numeric_power_is_dbm_zero(self):
        for side in ('left','right'):
            self.assertIn('CONFIG_BT_CTLR_TX_PWR_DBM=0',fixture['halves'][side]['radio_and_required_excerpt'])
    def test_bad_extension_symbol_is_not_assigned(self):
        cfg=(ROOT/'modules/modu-control/modu.conf').read_text()
        self.assertNotRegex(cfg,r'(?m)^CONFIG_BT_HCI_VS_EXT=')
        self.assertRegex(cfg,r'(?m)^CONFIG_BT_HCI_VS=y$')
    def test_fragment_symbols_occur_in_original_or_our_module(self):
        assigned=set(re.findall(r'(?m)^(CONFIG_\w+)=',(ROOT/'modules/modu-control/modu.conf').read_text()))
        own={'CONFIG_MODU_CONTROL'}
        for side in ('left','right'):
            known=set(re.findall(r'CONFIG_\w+','\n'.join(fixture['halves'][side]['radio_and_required_excerpt'])))
            self.assertFalse(assigned-known-own,assigned-known-own)
    def test_modified_left_maximum_fixture_passes(self):
        checker.check_tx_power_config(modified_maximum('left'))
    def test_modified_right_maximum_fixture_passes(self):
        checker.check_tx_power_config(modified_maximum('right'))
    def test_real_original_zero_is_not_authorized_as_maximum(self):
        for side in ('left','right'):
            with self.assertRaises(SystemExit):
                checker.check_tx_power_config('\n'.join(fixture['halves'][side]['radio_and_required_excerpt']))
    def test_old_invented_numeric_name_cannot_authorize_maximum(self):
        with self.assertRaises(SystemExit):
            checker.check_tx_power_config('CONFIG_BT_CTLR_TX_PWR_PLUS_8=y\nCONFIG_BT_CTLR_TX_PWR=8\n')
    def test_wrong_effective_power_is_still_refused(self):
        with self.assertRaises(SystemExit):
            checker.check_tx_power_config(modified_maximum('left').replace('TX_PWR_DBM=8','TX_PWR_DBM=0'))
    def test_hci_required_at_final_gate(self):
        self.assertIn("'CONFIG_BT_HCI_VS=y'",(ROOT/'scripts/check_built.py').read_text())
    def test_build_does_not_ignore_kconfig_warnings(self):
        txt=(ROOT/'scripts/build_firmware.py').read_text()
        self.assertNotIn('KCONFIG_WARN_UNDEF=n',txt)
        self.assertNotIn('KCONFIG_ERROR_ON_WARNINGS=OFF',txt)
        self.assertNotIn('KCONFIG_WARN_UNDEF=OFF',txt)

if __name__=='__main__': unittest.main()
