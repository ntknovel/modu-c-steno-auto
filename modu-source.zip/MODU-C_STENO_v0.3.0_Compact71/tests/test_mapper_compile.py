from pathlib import Path
import copy,json,sys,tempfile,unittest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from compile_mapper import compile_project,prepare_project
import validate

def stock():return {'schema':'modu-local-project-1','positions':71,'layers':[{'id':i,'name':['Base','Num','MODU Controls','Mouse','Nav','Fn','Symbols','STENO-KO','Select Nav'][i],'bindings':b} for i,b in enumerate(validate.bindings_with_parameters((ROOT/'config/modu.keymap').read_text()))],'combos':[],'macros':[],'tapdances':[]}
def custom():
 p=stock();p['macros']=[{'id':1,'steps':[{'type':'press','binding':'&kp 0x700e0'},{'type':'tap','binding':'&kp C'},{'type':'wait','ms':200},{'type':'release','binding':'&kp 0x700e0'}]}]
 p['tapdances']=[{'id':1,'termMs':200,'bindings':['&kp A','&kp B']}]
 p['combos']=[{'id':1,'keys':[25,26],'layers':[0],'termMs':50,'binding':'&lm_m1'}]
 p['layers'][0]['bindings'][10]='&lm_t1';return p
class MapperCompileTests(unittest.TestCase):
 def test_stock_compiles_to_nine_exact_layers(self):
  result=compile_project(stock(),ROOT);self.assertEqual(validate.bindings_with_parameters(result),[x['bindings'] for x in stock()['layers']])
 def test_three_advanced_definitions(self):
  result=compile_project(custom(),ROOT)
  for text in ('zmk,behavior-macro','zmk,behavior-tap-dance','key-positions = <25 26>','LM Macro 1','LM Tap Dance 1','<&macro_wait_time 200>','<&macro_release>','&lm_t1'):self.assertIn(text,result)
 def test_reject_dts_injection(self):
  p=stock();p['layers'][0]['bindings'][10]='&kp A>; /delete-node/ &sensor; <'
  with self.assertRaises(ValueError):compile_project(p,ROOT)
 def test_reject_missing_definition(self):
  p=stock();p['layers'][0]['bindings'][10]='&lm_t2'
  with self.assertRaises(ValueError):compile_project(p,ROOT)
 def test_reject_looping_macro(self):
  p=custom();p['macros'][0]['steps']=[{'type':'tap','binding':'&lm_m1'}]
  with self.assertRaises(ValueError):compile_project(p,ROOT)
 def test_reject_unreleased_key(self):
  p=custom();p['macros'][0]['steps'].pop()
  with self.assertRaises(ValueError):compile_project(p,ROOT)
 def test_reject_unmatched_release(self):
  p=custom();p['macros'][0]['steps'].pop(0)
  with self.assertRaises(ValueError):compile_project(p,ROOT)
 def test_macro_queue_bound(self):
  p=custom();p['macros'][0]['steps']=[{'type':'tap','binding':'&kp A'}]*25
  with self.assertRaises(ValueError):compile_project(p,ROOT)
 def test_combo_physical_only(self):
  p=custom();p['combos'][0]['keys']=[25,61]
  with self.assertRaises(ValueError):compile_project(p,ROOT)
 def test_duplicate_combo_refused(self):
  p=custom();c=copy.deepcopy(p['combos'][0]);c['id']=2;p['combos'].append(c)
  with self.assertRaises(ValueError):compile_project(p,ROOT)
 def test_reserved_centers_refused(self):
  p=stock();p['layers'][0]['bindings'][69]='&kp A'
  with self.assertRaises(ValueError):compile_project(p,ROOT)
 def test_non_base_center_refused(self):
  p=stock();p['layers'][1]['bindings'][69]='&lball 1'
  with self.assertRaises(ValueError):compile_project(p,ROOT)
 def test_77_not_silently_compiled(self):
  p=stock();p['positions']=77
  with self.assertRaises(ValueError):compile_project(p,ROOT)
 def test_invalid_name_escaped_not_executed(self):
  p=stock();p['layers'][0]['name']='x"; / { };'
  with self.assertRaises(ValueError):compile_project(p,ROOT)
 def test_stable_byte_output(self):self.assertEqual(compile_project(custom(),ROOT),compile_project(custom(),ROOT))
 def test_disabled_optional_project_clears_generated_file(self):
  with tempfile.TemporaryDirectory() as d:
   r=Path(d);(r/'config').mkdir();(r/'config/local-custom.dtsi').write_text('stale contents')
   self.assertFalse(prepare_project(r)['configured']);self.assertNotIn('stale',(r/'config/local-custom.dtsi').read_text())
if __name__=='__main__':unittest.main()
