"""Synthetic DTS fixtures for preflight safeguards; NOT upstream-source validation."""
import json
import os
import tempfile
from pathlib import Path
import sys
import unittest
SOURCE_ROOT=Path(os.environ.get('MODU_TEST_SOURCE_ROOT',Path(__file__).resolve().parents[1]))
sys.path.insert(0,str(SOURCE_ROOT/'scripts'))
from prepare_build import ORIGINAL,PreflightError,resolve_dts,nodes,clean,flatten,prop
ROOT=Path(__file__).resolve().parents[1]
LAYOUT=json.loads((ROOT/'config/modu.json').read_text())['layouts']['default_transform']['layout']

def fixture():
    rc=' '.join(f'RC({r},{c})' for r,c in ORIGINAL)
    return """/ {
 chosen { zmk,kscan = <&alt_scan>; zmk,matrix-transform = <&default_transform>; };
 alt_scan: alt_scan { compatible = "zmk,alt-thumb-kscan"; };
 default_transform: keymap_transform { compatible = "zmk,matrix-transform"; rows=<6>; columns=<12>; map = <"""+rc+""">; };
 sensor_left: sensor_left { compatible = "pixart,pmw3610-alt"; };
 trackball_listener { compatible = "zmk,input-listener"; device = <&sensor_left>; input-processors=<&original_scale 1 1>; };
 peripheral_trackball_listener { compatible="zmk,input-listener"; device=<&remote_input>; };
};"""
class PreflightTests(unittest.TestCase):
    def test_left_preserves_chain_and_scan(self):
        s,r=resolve_dts(fixture(),'left',LAYOUT)
        self.assertIn('input-processors = <&original_scale 1 1>, <&modu_tb 0>',s)
        self.assertIn('input-processors = <&modu_tb 1>',s)
        self.assertIn('kscan = <&alt_scan>',s)
        self.assertEqual(r['positions_with_virtual_directions'],71)
        self.assertEqual(s.count('<&key_physical_attrs'),71)
        self.assertNotIn('gpios',s)
    def test_right_does_not_process(self):
        s,r=resolve_dts(fixture(),'right',LAYOUT)
        self.assertEqual(r['side'],'right');self.assertNotIn('input-processors =',s)
    def test_refuse_changed_matrix(self):
        with self.assertRaises(PreflightError):resolve_dts(fixture().replace('RC(5,9)','RC(5,10)'),'left',LAYOUT)
    def test_refuse_unknown_sensor(self):
        with self.assertRaises(PreflightError):resolve_dts(fixture().replace('pixart,pmw3610-alt','unknown'),'left',LAYOUT)
    def test_refuse_replaced_thumb_scanner(self):
        with self.assertRaises(PreflightError):resolve_dts(fixture().replace('zmk,alt-thumb-kscan','zmk,kscan-gpio-matrix'),'left',LAYOUT)
    def test_layer_override_is_not_silently_ignored(self):
        text=fixture().replace('input-processors=<&original_scale 1 1>;','scroll_layer { layers=<1>; input-processors=<&mapper>; };')
        with self.assertRaises(PreflightError):resolve_dts(text,'left',LAYOUT)
    def test_transform_offsets_preserved(self):
        s,_=resolve_dts(fixture()+'\n&default_transform { col-offset = <6>; };','right',LAYOUT)
        self.assertNotIn('col-offset',s);self.assertIn('&default_transform {',s)
    def test_reference_listener_override(self):
        text=fixture().replace('trackball_listener {','tb: trackball_listener {',1)+'\n&tb { input-processors=<&other 2 3>; };'
        s,_=resolve_dts(text,'left',LAYOUT)
        self.assertIn('<&other 2 3>, <&modu_tb 0>',s)
    def test_path_listener_override(self):
        text=fixture()+'\n&{/trackball_listener} { input-processors=<&override 2 3>; };'
        s,_=resolve_dts(text,'left',LAYOUT)
        self.assertIn('<&override 2 3>, <&modu_tb 0>',s)
    def test_no_sensor_fallback_guess(self):
        text=fixture().replace('device = <&sensor_left>;','')
        with self.assertRaises(PreflightError):resolve_dts(text,'left',LAYOUT)
    def test_layout_order_regression(self):
        bad=LAYOUT.copy();bad[0],bad[1]=bad[1],bad[0]
        with self.assertRaises(PreflightError):resolve_dts(fixture(),'left',bad)

    def test_deleted_listener_chain_is_not_resurrected(self):
        text=fixture()+'\n&{/trackball_listener} { /delete-property/ input-processors; };'
        s,r=resolve_dts(text,'left',LAYOUT)
        self.assertIn('input-processors = <&modu_tb 0>;',s)
        self.assertNotIn('original_scale',s)
        self.assertIsNone(r['listeners'][0]['previous_chain'])
    def test_delete_then_reassign_uses_final_value(self):
        text=fixture()+'\n&{/trackball_listener} { /delete-property/ input-processors; input-processors=<&new_scale 1 2>; };'
        s,_=resolve_dts(text,'left',LAYOUT)
        self.assertIn('<&new_scale 1 2>, <&modu_tb 0>',s)
    def test_deleted_chosen_reference_is_rejected(self):
        text=fixture()+'\n/ { chosen { /delete-property/ zmk,kscan; }; };'
        with self.assertRaises(PreflightError):resolve_dts(text,'left',LAYOUT)
    def test_comment_markers_inside_strings_are_preserved(self):
        original='label = "path://literal/*not a comment*/"; // real comment\n'
        result=clean(original)
        self.assertIn('"path://literal/*not a comment*/"',result)
        self.assertNotIn('real comment',result)
    def test_property_semicolon_inside_string(self):
        self.assertEqual(prop({'top':'label="first; second";'},'label'),'"first; second"')
    def test_property_name_inside_string_is_not_assignment(self):
        self.assertIsNone(prop({'top':'label="input-processors = <&fake>;";'},'input-processors'))
    def test_commented_include_is_not_expanded(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d)
            (d/'never.dtsi').write_text('SHOULD_NOT_APPEAR')
            (d/'actual.dtsi').write_text('SHOULD_APPEAR')
            (d/'root.overlay').write_text('/*\n#include "never.dtsi"\n*/\n#include "actual.dtsi"\n')
            result=flatten(d/'root.overlay')
            self.assertNotIn('SHOULD_NOT_APPEAR',result)
            self.assertIn('SHOULD_APPEAR',result)

    def test_bare_chosen_phandles_are_valid(self):
        text=fixture().replace('<&alt_scan>', '&alt_scan').replace('<&default_transform>', '&default_transform')
        output,report=resolve_dts(text,'left',LAYOUT)
        self.assertEqual(report['scan_wrapper'],'alt_scan')
        self.assertEqual(output.count('<&key_physical_attrs'),71)
    def test_bare_listener_device_phandles_are_valid(self):
        text=fixture().replace('<&sensor_left>','&sensor_left').replace('<&remote_input>','&remote_input')
        _,report=resolve_dts(text,'left',LAYOUT)
        self.assertEqual(report['local_sensor'],'sensor_left')
    def test_braces_in_strings_do_not_create_nodes(self):
        text=fixture().replace('compatible = "pixart,pmw3610-alt";',
            'compatible = "pixart,pmw3610-alt"; label="fake { unmatched";')
        resolve_dts(text,'left',LAYOUT)
    def test_node_shaped_string_is_not_a_second_listener(self):
        text=fixture().replace('compatible = "pixart,pmw3610-alt";',
            'compatible = "pixart,pmw3610-alt"; label="trackball_listener { }";')
        resolve_dts(text,'left',LAYOUT)
    def test_missing_right_route_is_rejected(self):
        text=fixture().replace('device=<&remote_input>;', '')
        with self.assertRaises(PreflightError):resolve_dts(text,'left',LAYOUT)
    def test_same_sensor_cannot_feed_both_sides(self):
        text=fixture().replace('device=<&remote_input>;', 'device=<&sensor_left>;')
        with self.assertRaises(PreflightError):resolve_dts(text,'left',LAYOUT)
    def test_disabled_listener_is_rejected(self):
        for name in ('trackball_listener','peripheral_trackball_listener'):
            text=fixture()+f'\n&{{/{name}}} {{ status="disabled"; }};'
            with self.subTest(name=name),self.assertRaises(PreflightError):resolve_dts(text,'left',LAYOUT)
    def test_disabled_local_sensor_is_rejected(self):
        text=fixture()+'\n&sensor_left { status="disabled"; };'
        with self.assertRaises(PreflightError):resolve_dts(text,'left',LAYOUT)

if __name__=='__main__':unittest.main()
