from pathlib import Path
import hashlib, json, subprocess, tempfile, unittest,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
import patch_compact_storage as p
from layout_contract import NEW_TO_OLD,POSITIONS
class CompactStorageTests(unittest.TestCase):
 def test_reference_checksum(self):self.assertEqual(hashlib.sha256((ROOT/'tests/fixtures/pinned_keymap_641514.c').read_bytes()).hexdigest(),p.PINNED_SHA)
 def test_unknown_upstream_refused(self):
  with tempfile.TemporaryDirectory() as d:
   w=Path(d);q=w/'zmk/app/src/keymap.c';q.parent.mkdir(parents=True);q.write_text('not the pinned source')
   with self.assertRaises(ValueError):p.apply(ROOT,w)
   self.assertEqual(q.read_text(),'not the pinned source')
 def test_patch_idempotent_and_no_storage_reset(self):
  with tempfile.TemporaryDirectory() as d:
   w=Path(d);q=w/'zmk/app/src/keymap.c';q.parent.mkdir(parents=True);q.write_bytes((ROOT/'tests/fixtures/pinned_keymap_641514.c').read_bytes())
   first=p.apply(ROOT,w);content=q.read_bytes();second=p.apply(ROOT,w)
   self.assertEqual(first,second);self.assertEqual(q.read_bytes(),content);self.assertFalse(first['erases_settings'])
 def test_mapping_survivors(self):
  self.assertEqual(len(POSITIONS),71);self.assertEqual(len(NEW_TO_OLD),71)
  self.assertEqual(NEW_TO_OLD[:51],tuple(range(51)));self.assertEqual(NEW_TO_OLD[51:],tuple(range(57,77)))
 def test_actual_patched_save_and_load_host(self):
  source=p.transform((ROOT/'tests/fixtures/pinned_keymap_641514.c').read_text())
  def extract(name):
   start=source.index('static int '+name+'(');brace=source.index('{',start);level=1;i=brace+1
   while level:
    if source[i]=='{':level+=1
    elif source[i]=='}':level-=1
    i+=1
   return source[start:i]
  pre=r'''
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <errno.h>
#define ZMK_KEYMAP_LEN 71
#define ZMK_KEYMAP_LAYERS_LEN 9
#define CONFIG_ZMK_KEYMAP_LAYER_NAME_MAX_LEN 32
#define BUILD_ASSERT(x,msg) _Static_assert(x,msg)
#define CONFIG_ZMK_KEYMAP_LAYER_REORDERING 0
#define CONFIG_ZMK_BEHAVIOR_LOCAL_IDS_IN_BINDINGS 0
#define IS_ENABLED(x) x
#define LOG_DBG(...) ((void)0)
#define LOG_WRN(...) ((void)0)
#define LOG_ERR(...) ((void)0)
#define BIT(x) (1u<<(x))
#define WRITE_BIT(v,b,on) ((v)=(on)?((v)|BIT(b)):((v)&~BIT(b)))
#define MIN(a,b) ((a)<(b)?(a):(b))
#define LAYER_BINDING_SETTINGS_KEY "modusteno1/l/%d/%d"
typedef unsigned int zmk_keymap_layer_id_t;
typedef int (*settings_read_cb)(void*,void*,size_t);
struct zmk_behavior_binding {const char *behavior_dev;uint32_t param1,param2;};
struct zmk_behavior_binding_setting {uint16_t behavior_local_id;uint32_t param1,param2;} __attribute__((packed));
static struct zmk_behavior_binding zmk_keymap[9][71];
static uint8_t zmk_keymap_layer_pending_changes[9][9];
static char zmk_keymap_layer_names[9][32];
static struct zmk_behavior_binding_setting storage[9][77];
static int writes;
static uint16_t zmk_behavior_get_local_id(const char *n){return strcmp(n,"kp")==0?1:2;}
static const char *zmk_behavior_find_behavior_name_from_local_id(uint16_t n){return n==1?"kp":"none";}
static int settings_name_steq(const char *name,const char *part,const char **next){size_t n=strlen(part);if(strncmp(name,part,n)|| (name[n]&&name[n]!='/'))return 0;*next=name[n]=='/'?name+n+1:NULL;return 1;}
static int settings_save_one(const char *name,const void *data,size_t len){unsigned l,k;assert(sscanf(name,"modusteno1/l/%u/%u",&l,&k)==2);assert(l<9&&k<77);assert(k<51||k>56);memset(&storage[l][k],0,sizeof(storage[l][k]));memcpy(&storage[l][k],data,len);writes++;return 0;}
static int read_cb(void *arg,void *out,size_t len){memcpy(out,arg,len);return (int)len;}
'''
  main=r'''
int main(void){
 for(unsigned l=0;l<9;l++)for(unsigned k=0;k<77;k++){
  storage[l][k]=(struct zmk_behavior_binding_setting){1,10000+l*100+k,0};
  char name[24];snprintf(name,sizeof(name),"l/%u/%u",l,k);
  assert(keymap_handle_set(name,sizeof(storage[l][k]),read_cb,&storage[l][k])==0);
 }
 for(unsigned l=0;l<9;l++)for(unsigned k=0;k<71;k++){
  unsigned old=(unsigned)modu_storage_from_compact(k);
  assert(modu_compact_from_storage(old)==(int)k);
  assert(zmk_keymap[l][k].param1==10000+l*100+old);
  zmk_keymap[l][k].param1=20000+l*100+k;
  WRITE_BIT(zmk_keymap_layer_pending_changes[l][k/8],k%8,1);
 }
 assert(save_bindings()==0);assert(writes==639);
 for(unsigned l=0;l<9;l++)for(unsigned k=0;k<71;k++)assert(storage[l][modu_storage_from_compact(k)].param1==20000+l*100+k);
 for(unsigned l=0;l<9;l++)for(unsigned old=51;old<=56;old++)assert(storage[l][old].param1==10000+l*100+old);
 assert(keymap_handle_set("l/0/77",4,read_cb,&storage[0][0])==0);
 assert(keymap_handle_set("l_n/9",4,read_cb,&storage[0][0])==-EINVAL);
 puts("PASS actual patched save_bindings/keymap_handle_set: 9 layers, all legacy slots, no phantom writes");return 0;
}
'''
  with tempfile.TemporaryDirectory() as d:
   c=Path(d)/'test.c';exe=Path(d)/'test';c.write_text(pre+p.HELPERS+extract('save_bindings')+extract('keymap_handle_set')+main)
   subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror','-fsanitize=undefined,address',str(c),'-o',str(exe)],check=True,capture_output=True,text=True)
   result=subprocess.run([str(exe)],check=True,capture_output=True,text=True);self.assertIn('PASS actual patched',result.stdout)
 def test_namespace_covers_load_save_reset(self):
  source=p.transform((ROOT/'tests/fixtures/pinned_keymap_641514.c').read_text())
  self.assertNotIn('"keymap/',source)
  self.assertNotIn('"keymap"',source)
  for token in ('"modusteno1/layer_order"','"modusteno1/l_n/%d"','"modusteno1/l/%d/%d"','settings_load_subtree("modusteno1")','settings_load_subtree_direct("modusteno1"','SETTINGS_STATIC_HANDLER_DEFINE(keymap, "modusteno1"'):
   self.assertIn(token,source)
 def test_upgrade_from_known_compact_source(self):
  with tempfile.TemporaryDirectory() as d:
   w=Path(d);q=w/'zmk/app/src/keymap.c';q.parent.mkdir(parents=True)
   q.write_text(p.transform_compact((ROOT/'tests/fixtures/pinned_keymap_641514.c').read_text()))
   report=p.apply(ROOT,w)
   self.assertEqual(report['keymap_namespace'],'modusteno1')
   self.assertFalse(report['reads_old_normal_keymap'])
if __name__=='__main__':unittest.main()
