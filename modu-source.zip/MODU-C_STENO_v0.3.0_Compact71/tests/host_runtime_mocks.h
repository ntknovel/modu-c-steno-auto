/* Minimal deterministic HOST TEST doubles. NOT Zephyr headers or an emulator. */
#pragma once
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>
#define CONFIG_ZMK_SPLIT_ROLE_CENTRAL MC_TEST_CENTRAL
#define CONFIG_ZMK_SPLIT 1
#define CONFIG_ZMK_LOG_LEVEL 0
#define IS_ENABLED(x) (x)
#define DT_NODELABEL(x) x
#define DT_PROP(node, prop) MC_TEST_SIDE
#define MC_TEST_NAME_modu_hw "modu_hw"
#define MC_TEST_NAME_lball "lball"
#define MC_TEST_NAME_rball "rball"
#define MC_TEST_DEVICE_NAME_(node) MC_TEST_NAME_##node
#define DEVICE_DT_NAME(node) MC_TEST_DEVICE_NAME_(node)
#define ARG_UNUSED(x) ((void)(x))
#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))
#define CLAMP(x,lo,hi) MAX((lo),MIN((x),(hi)))
#define ARRAY_SIZE(x) (sizeof(x)/sizeof((x)[0]))
#define K_FOREVER (-1)
#define K_NO_WAIT 0
#define K_MSEC(x) (x)
#define APPLICATION 0
#define LOG_MODULE_DECLARE(...)
static inline void mock_log(const char *fmt, ...) { (void)fmt; }
#define LOG_WRN(...) mock_log(__VA_ARGS__)
#define LOG_DBG(...) mock_log(__VA_ARGS__)
#define LOG_INF(...) mock_log(__VA_ARGS__)
#define REQUIRE(x) do { if (!(x)) { fprintf(stderr,"FAIL %s:%d: %s\n",__FILE__,__LINE__,#x); exit(1); } } while(0)
struct k_mutex { int held; };
#define K_MUTEX_DEFINE(n) struct k_mutex n
static inline void k_mutex_lock(struct k_mutex *m, int t) { (void)t; REQUIRE(!m->held); m->held=1; }
static inline void k_mutex_unlock(struct k_mutex *m) { REQUIRE(m->held); m->held=0; }
struct k_work { void (*handler)(struct k_work *); };
struct k_work_delayable { struct k_work work; bool pending; int64_t due; };
#define K_WORK_DELAYABLE_DEFINE(n, fn) static struct k_work_delayable n={.work={.handler=fn}}
static int64_t mock_now;
static struct k_work_delayable *work_items[32];
static unsigned work_count;
static inline int64_t k_uptime_get(void) { return mock_now; }
static inline int k_work_reschedule(struct k_work_delayable *w, int64_t delay) {
    unsigned i; for(i=0;i<work_count;i++) if(work_items[i]==w) break;
    if(i==work_count) { REQUIRE(work_count<ARRAY_SIZE(work_items));work_items[work_count++]=w; }
    w->due=mock_now+delay; w->pending=true; return 1;
}
static inline int k_work_schedule(struct k_work_delayable *w, int64_t delay) {
    return w->pending ? 0 : k_work_reschedule(w,delay);
}
static inline void advance_to(int64_t target) {
    unsigned iterations=0; REQUIRE(target>=mock_now);
    for(;;) {
        struct k_work_delayable *first=NULL;
        for(unsigned i=0;i<work_count;i++) if(work_items[i]->pending && work_items[i]->due<=target &&
            (!first || work_items[i]->due<first->due)) first=work_items[i];
        if(!first) break;
        REQUIRE(++iterations<1000); mock_now=first->due;first->pending=false;first->work.handler(&first->work);
    }
    mock_now=target;
}
#define SYS_INIT(fn, level, priority) /* initialize() is called explicitly by host tests */
typedef int (*settings_read_cb)(void *, void *, size_t);
#define SETTINGS_STATIC_HANDLER_DEFINE(...) /* host tests call settings_set() directly */
int settings_save_one(const char *, const void *, size_t);
struct zmk_behavior_binding { const char *behavior_dev; uint32_t param1,param2; };
struct zmk_behavior_binding_event { uint32_t position; int64_t timestamp; uint8_t source; uint8_t layer; };
struct zmk_position_state_changed { uint8_t source; uint32_t position; bool state; int64_t timestamp; };
#define ZMK_POSITION_STATE_CHANGE_SOURCE_LOCAL 255
int zmk_behavior_invoke_binding(const struct zmk_behavior_binding *, struct zmk_behavior_binding_event, bool);
int raise_zmk_position_state_changed(struct zmk_position_state_changed);

/* Input-boundary doubles. Constants match Zephyr/Linux input-event encodings,
 * but these declarations are NOT an ABI/Zephyr compile check. */
struct device { const void *config; const void *api; };
struct input_event { const struct device *dev; uint8_t sync,type; uint16_t code; int32_t value; };
struct zmk_input_processor_state { uint8_t input_device_index; int16_t *remainder; };
struct zmk_input_processor_driver_api {
    int (*handle_event)(const struct device *,struct input_event *,uint32_t,uint32_t,
                        struct zmk_input_processor_state *);
};
#define INPUT_EV_KEY 1
#define INPUT_EV_REL 2
#define INPUT_REL_X 0
#define INPUT_REL_Y 1
#define INPUT_REL_HWHEEL 6
#define INPUT_REL_WHEEL 8
#define INPUT_BTN_LEFT 0x110
#define ZMK_INPUT_PROC_CONTINUE 0
#define ZMK_INPUT_PROC_STOP 1
#define CONFIG_KERNEL_INIT_PRIORITY_DEFAULT 40
#define POST_KERNEL 0
#define DEVICE_DT_INST_DEFINE(n,init,pm,data,config,level,priority,api_ptr) \
    static const void *const mock_input_api __attribute__((unused))=(api_ptr)

/* Studio map doubles. Read-only from firmware: never synthesize a key press. */
static struct zmk_behavior_binding mock_profile_slots[2];
static unsigned mock_profile_reads;
static int mock_unsaved;
static inline int zmk_keymap_check_unsaved_changes(void) { return mock_unsaved; }
static inline const struct zmk_behavior_binding *zmk_keymap_get_layer_binding_at_idx(unsigned layer,unsigned position) {
    REQUIRE(layer==0); REQUIRE(position>=69 && position<=70);
    mock_profile_reads++; return &mock_profile_slots[position-69];
}
