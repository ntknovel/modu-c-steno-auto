"""Compile actual runtime.c with small host test doubles, NOT real Zephyr headers."""
from pathlib import Path
import os
import shutil
import subprocess
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
SOURCE=Path(os.environ.get("MODU_TEST_SOURCE_ROOT",ROOT))
class RuntimeHostTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cc=shutil.which(os.environ.get('CC','cc'))
        if not cc: raise unittest.SkipTest('Host C compiler not installed')
        cls.temp=tempfile.TemporaryDirectory(prefix='modu-runtime-host-')
        cls.addClassCleanup(cls.temp.cleanup)
        temp=Path(cls.temp.name)
        for header in ('zephyr/device.h','zephyr/kernel.h','zephyr/init.h','zephyr/settings/settings.h',
                       'zephyr/logging/log.h','zmk/behavior.h','zmk/event_manager.h','zmk/events/position_state_changed.h',
                       'zephyr/input/input.h','zephyr/dt-bindings/input/input-event-codes.h','drivers/input_processor.h','zmk/keymap.h'):
            p=temp/header;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('#include "host_runtime_mocks.h"\n')
        (temp/'modu_profile_under_test.c').write_text('#include "'+(SOURCE/'modules/modu-control/src/studio_profile.c').as_posix()+'"\n')
        runtime=SOURCE/'modules/modu-control/src/runtime.c'
        (temp/'modu_runtime_under_test.c').write_text('#include "'+runtime.as_posix()+'"\n')
        (temp/'modu_input_under_test.c').write_text('#include "'+(SOURCE/'modules/modu-control/src/input_processor.c').as_posix()+'"\n')
        behavior=(SOURCE/'modules/modu-control/src/behavior.c').read_text()
        global_mode='BEHAVIOR_LOCALITY_GLOBAL' in behavior.split('hw_api=',1)[-1]
        cls.executables={}
        for side in (0,1):
            exe=temp/f'runtime_{side}'
            command=[cc,'-std=c11','-Wall','-Wextra','-Werror','-Wno-unused-function',
                     '-Wno-sign-compare','-Wno-missing-field-initializers','-fsanitize=undefined',
                     f'-DMC_TEST_CENTRAL={1-side}',f'-DMC_TEST_SIDE={side}',f'-DMC_TEST_GLOBAL={int(global_mode)}',
                     '-I',str(temp),'-I',str(ROOT/'tests'),'-I',str(SOURCE/'modules/modu-control/include'),
                     str(SOURCE/'modules/modu-control/src/core.c'),str(ROOT/'tests/test_runtime_host.c'),'-o',str(exe)]
            result=subprocess.run(command,text=True,capture_output=True)
            if result.returncode: raise AssertionError('HOST HARNESS compile failed (not Zephyr):\n'+result.stderr)
            cls.executables[side]=exe
    def run_case(self,name,side=0):
        p=subprocess.run([str(self.executables[side]),name],text=True,capture_output=True)
        self.assertEqual(p.returncode,0,p.stdout+p.stderr)
    def test_remote_failure_propagates(self):self.run_case('remote_failure')
    def test_stale_sync_does_not_rewrite_desired_cpi(self):self.run_case('stale_snapshot')
    def test_cpi_rearms_retry_budget(self):self.run_case('cpi_retry')
    def test_tx_rearms_retry_budget(self):self.run_case('tx_retry')
    def test_arrow_reentry_is_not_delayed(self):self.run_case('reentry')
    def test_reverse_discards_opposite_pending_taps(self):self.run_case('reverse')
    def test_link_loss_releases_virtual_key(self):self.run_case('release')
    def test_left_and_right_pulses_are_independent(self):self.run_case('sides')
    def test_repeat_interval(self):self.run_case('repeat_interval')
    def test_central_settings_validation(self):self.run_case('settings')
    def test_peripheral_settings_validation(self):self.run_case('settings',1)
    def test_peripheral_applies_only_own_cpi(self):self.run_case('peripheral',1)
    def test_left_boots_at_maximum_tx(self):self.run_case('tx_boot')
    def test_right_boots_at_maximum_tx(self):self.run_case('tx_boot',1)
    def test_left_tx_default_reset_is_maximum(self):self.run_case('tx_reset_local')
    def test_right_tx_default_reset_is_maximum(self):self.run_case('tx_reset_local',1)
    def test_central_reconnect_restores_both_maximum_tx(self):self.run_case('tx_reconnect')
    def test_peripheral_reconnect_restores_maximum_tx(self):self.run_case('tx_reconnect',1)
    def test_both_tx_reset_routes_maximum(self):self.run_case('tx_both')
    def test_manual_tx_is_still_independent_and_retry_keeps_it(self):self.run_case('tx_manual')

    def test_input_left_pointer_scaling_and_right_independence(self):self.run_case('input_mouse')
    def test_input_hold_scroll_uses_wheel_codes_and_restores(self):self.run_case('input_hold')
    def test_input_right_arrows_reach_right_virtual_positions(self):self.run_case('input_arrows')
    def test_input_arrow_frame_sync(self):self.run_case('input_frame')
    def test_input_disabled_consumes_motion_not_buttons(self):self.run_case('input_off')
    def test_input_reverse_scroll_and_fractional_accumulation(self):self.run_case('input_reverse_scroll')
    def test_input_diagonal_emits_both_directions(self):self.run_case('input_diagonal')
    def test_input_hold_does_not_overwrite_persistent_mode(self):self.run_case('input_persistent')

    def test_cycle_sequence(self):self.run_case('cycle_sequence')
    def test_cycle_sides(self):self.run_case('cycle_sides')
    def test_cycle_held(self):self.run_case('cycle_held')
    def test_cycle_modes(self):self.run_case('cycle_modes')
    def test_profile_mouse_scroll(self):self.run_case('profile_mouse_scroll')
    def test_profile_arrows(self):self.run_case('profile_arrows')
    def test_profile_invalid(self):self.run_case('profile_invalid')
    def test_profile_discard(self):self.run_case('profile_discard')
    def test_profile_cycle_override(self):self.run_case('profile_cycle_override')
    def test_profile_boot(self):self.run_case('profile_boot')
    def test_profile_hold(self):self.run_case('profile_hold')
    def test_profile_pending(self):self.run_case('profile_pending')
    def test_profile_readonly(self):self.run_case('profile_readonly')
    def test_profile_base_only(self):self.run_case('profile_base_only')

    def test_mode_memory_left_reboot(self):self.run_case("remember_left_reboot")
    def test_mode_memory_right_reboot(self):self.run_case("remember_right_reboot")
    def test_mode_memory_both_reboot(self):self.run_case("remember_both_reboot")
    def test_mode_memory_hold_not_saved(self):self.run_case("remember_hold_not_saved")
    def test_mode_memory_hold_cycle_reboot(self):self.run_case("remember_hold_cycle_reboot")
    def test_mode_memory_same_value_saves_priority(self):self.run_case("remember_same_value_saves_priority")
    def test_mode_memory_new_studio_baseline(self):self.run_case("remember_new_studio_baseline")
    def test_mode_memory_discard_restores_override(self):self.run_case("remember_discard_restores_override")
    def test_mode_memory_draft_cpi_save(self):self.run_case("remember_draft_cpi_save")
    def test_mode_memory_manual_during_draft(self):self.run_case("remember_manual_during_draft")
    def test_mode_memory_save_same_baseline(self):self.run_case("remember_save_same_baseline")
    def test_mode_memory_reconnect(self):self.run_case("remember_reconnect")
    def test_mode_memory_v1_migration(self):self.run_case("remember_v1_migration")
    def test_mode_memory_corrupt_record(self):self.run_case("remember_corrupt_record")
    def test_mode_memory_save_debounce(self):self.run_case("remember_save_debounce")
