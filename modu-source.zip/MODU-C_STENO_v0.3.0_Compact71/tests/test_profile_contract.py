"""Source/package contracts for v0.1.5. These do not simulate a connected device."""
from pathlib import Path
import json
import sys
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import validate

class ProfileContractTests(unittest.TestCase):
    def setUp(self):
        self.layout=json.loads((ROOT/'config/modu.json').read_text())['layouts']['default_transform']['layout']
        self.layers=validate.bindings_with_parameters((ROOT/'config/modu.keymap').read_text())

    def test_extra_b_is_next_to_n_and_main_b_stays(self):
        extra,n,main=self.layout[60],self.layout[42],self.layout[41]
        self.assertEqual((extra['x'],extra['y']),(n['x']-1,n['y']))
        self.assertEqual((main['x'],main['y']),(5,3))
        self.assertEqual(self.layers[0][41],'&kp B')
        self.assertEqual(self.layers[0][60],'&st_mode')
        self.assertEqual(self.layers[7][60],'&st_mode')

    def test_no_overlapping_key_rectangles(self):
        for i,a in enumerate(self.layout):
            for j,b in enumerate(self.layout[i+1:],i+1):
                overlap=(min(a['x']+a.get('w',1),b['x']+b.get('w',1))-max(a['x'],b['x'])>1e-6 and
                         min(a['y']+a.get('h',1),b['y']+b.get('h',1))-max(a['y'],b['y'])>1e-6)
                self.assertFalse(overlap,f'{i} overlaps {j}')

    def test_direction_and_setting_positions_are_distinct(self):
        self.assertEqual(len(self.layout),71)
        self.assertEqual([(k['row'],k['col']) for k in self.layout[61:]],[(6,i) for i in range(10)])
        for i in (69,70):self.assertEqual((self.layout[i]['w'],self.layout[i]['h']),(1,1))
        self.assertEqual(self.layers[0][61:69],['&kp '+x for x in ('UP','DOWN','LEFT','RIGHT')]*2)

    def test_profile_slots_live_on_base_only(self):
        self.assertEqual(self.layers[0][69:],['&lball MC_MOUSE','&rball MC_MOUSE'])
        for layer in self.layers[1:]:self.assertEqual(layer[69:],['&trans','&trans'])

    def test_cycle_keys_remain_on_controls_not_typing_layers(self):
        old=validate.bindings_with_parameters((ROOT/'docs/original-modu.keymap.txt').read_text())
        self.assertEqual(len(self.layers),9)
        self.assertEqual(self.layers[1][48],'&mo MODU_CONTROLS')
        self.assertFalse(any('cycle' in b for i in (0,1) for b in self.layers[i]))
        self.assertEqual(self.layers[2][54],'&lcycle MC_CYCLE_NEXT')
        self.assertEqual(self.layers[2][58],'&rcycle MC_CYCLE_NEXT')
        self.assertEqual(self.layers[2][5:7],['&bootloader','&bootloader'])

    def test_native_square_layout_has_no_extension_dependency(self):
        # Old uploaded cosmetic files may remain; no active build may depend on them.
        for path in ('.github/workflows/build.yml','scripts/build_firmware.py',
                     'scripts/render_layout_preview.py','modules/modu-control/CMakeLists.txt'):
            self.assertNotIn('studio-extension',(ROOT/path).read_text())

    def test_both_crosses_pass_static_validation(self):
        validate.check_trackball_cross(self.layout)

    def test_reader_is_compiled_and_does_not_write_keymap(self):
        self.assertIn('src/studio_profile.c',(ROOT/'modules/modu-control/CMakeLists.txt').read_text())
        reader=(ROOT/'modules/modu-control/src/studio_profile.c').read_text()
        self.assertIn('zmk_keymap_get_layer_binding_at_idx(0,MC_PROFILE_START+side)',reader)
        for forbidden in ('zmk_keymap_set_layer_binding_at_idx','zmk_keymap_save_changes','zmk_behavior_invoke_binding'):
            self.assertNotIn(forbidden,reader)

if __name__=='__main__':unittest.main()
