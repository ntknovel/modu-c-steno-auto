from pathlib import Path
import re,sys,unittest,hashlib
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from validate import bindings_with_parameters
from check_built import check_steno_config
class StenoContractTests(unittest.TestCase):
 def test_exact_role_layout(self):
  layers=bindings_with_parameters((ROOT/'config/modu.keymap').read_text());base,st=layers[0],layers[7]
  self.assertEqual(len(layers),9)
  self.assertTrue(all(len(l)==71 for l in layers))
  expected={13:'i_b',14:'i_j',15:'i_d',16:'i_g',17:'i_s',18:'f_s',19:'f_g',20:'f_d',21:'f_j',22:'f_b',25:'i_m',26:'i_n',27:'i_ng',28:'i_r',29:'i_h',30:'f_h',31:'f_r',32:'f_ng',33:'f_n',34:'f_m',37:'i_kh',38:'i_t',39:'i_ch',40:'i_p',41:'i_double',42:'f_double',43:'f_p',44:'f_ch',45:'f_t',46:'f_kh',24:'abbr_l',35:'abbr_r',36:'vext_l',47:'vext_r',50:'symbol_l',51:'symbol_r',54:'v_o',55:'v_eu',56:'vu_enter',57:'veo_space',58:'v_i',59:'v_a',60:'mode'}
  for pos,role in expected.items():self.assertEqual(st[pos],'&st_'+role)
  for pos,key in zip(range(13,23),'QWERTYUIOP'):self.assertEqual(base[pos],'&kp '+key)
  self.assertEqual(base[41],'&kp B');self.assertEqual(base[60],'&st_mode')
 def test_aux_nodes_and_modifiers(self):
  s=(ROOT/'config/modu-steno-aux.dtsi').read_text()
  self.assertEqual(s.count('compatible = "zmk,behavior-modu-steno-aux";'),13)
  for i in range(1,13):self.assertIn('function-key = <F'+str(i)+'>;',s)
  for i in range(10):self.assertIn('symbol-key = <LS(N'+str(i)+')>;',s)
  for t in ('normal-key = <TILDE>;','symbol-key = <GRAVE>;','function-key = <ESC>;'):self.assertIn(t,s)
 def test_old_number_and_vowel_canonical_rules_not_redefined(self):
  # Actual original decoder/dictionaries remain byte-identical to the recovered v2.2.6 source.
  module=ROOT/'modules/modu-steno'
  import json
  golden=json.loads((ROOT/'docs/cornix-core-sha256.json').read_text())
  for name,digest in golden.items():self.assertEqual(hashlib.sha256((module/name).read_bytes()).hexdigest(),digest)
 def test_all_normal_combos_exclude_steno_and_select(self):
  s=(ROOT/'config/modu.keymap').read_text()
  start=s.index('    combos {');end=s.index('    keymap {',start)
  combo=s[start:end]
  masks=re.findall(r'layers\s*=\s*<([^>]+)>',combo)
  self.assertTrue(masks)
  for mask in masks:self.assertTrue(set(mask.split()) <= {'BASE','NUM','FN'})
 def test_compiler_guard_requires_real_steno_flags(self):
  cfg=(ROOT/'modules/modu-steno/modu-steno.conf').read_text()
  check_steno_config(cfg)
  with self.assertRaises(SystemExit):check_steno_config(cfg.replace('MAX_POSITIONS=64','MAX_POSITIONS=50'))
  with self.assertRaises(SystemExit):check_steno_config(cfg.replace('CONFIG_CORNIX_STENO=y',''))
 def test_steno_module_is_in_active_build_not_just_packaged(self):
  s=(ROOT/'scripts/build_firmware.py').read_text()
  self.assertIn('modules/modu-steno',s)
  self.assertIn('modu-steno.conf',s)
  for path in ('src/steno/modu_aux.c','src/behaviors/behavior_modu_aux.c','src/steno/steno_output.c'):
   self.assertIn(path,(ROOT/'modules/modu-steno/CMakeLists.txt').read_text())
