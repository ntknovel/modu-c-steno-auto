"""Synthetic compiler-EDT/config tests, NOT a real device tree or a firmware build."""
from pathlib import Path
from types import SimpleNamespace as NS
import sys
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from layout_contract import POSITIONS
from check_integration import IntegrationError, check_graph, check_studio_config
from build_firmware import build_command

def node(path,compat,**props):
    return NS(path=path,compats=[compat],status='okay',parent=None,children={},
              props={k.replace('_','-'):NS(val=v) for k,v in props.items()})
def put(n,p,v):n.props[p]=NS(val=v)
def cell(n,v):return NS(controller=n,data={'side':v})
def fixture(side='left'):
    scan=node('/scan','zmk,alt-thumb-kscan')
    tx=node('/transform','zmk,matrix-transform',rows=7,columns=12,
        map=[(r<<8)|c for r,c in POSITIONS])
    layout=node('/layout','zmk,physical-layout',keys=list(range(71)),transform=tx,kscan=scan)
    sensor=node('/spi/sensor','pixart,pmw3610-alt')
    hw=node('/hw','modu,hardware',side=0 if side=='left' else 1,sensor=sensor)
    command=node('/behaviors/modu_hw','modu,hardware-command')
    processor=node('/modu_tb','modu,trackball-processor')
    split=node('/split/input@0','zmk,input-split')
    uart=node('/usb/cdc','zephyr,cdc-acm-uart')
    left=node('/trackball_listener','zmk,input-listener',device=sensor,input_processors=[cell(processor,0)])
    right=node('/peripheral_trackball_listener','zmk,input-listener',device=split,input_processors=[cell(processor,1)])
    if side=='right':
        put(left,'input-processors',[]);put(right,'input-processors',[]);put(split,'device',sensor)
    chosen={'zmk,physical-layout':layout,'zmk,kscan':scan,'zmk,studio-rpc-uart':uart}
    edt=NS(nodes=[scan,tx,layout,sensor,hw,command,processor,split,uart,left,right],chosen_node=chosen.get)
    return edt,NS(scan=scan,tx=tx,layout=layout,sensor=sensor,hw=hw,command=command,processor=processor,
                  split=split,uart=uart,left=left,right=right,chosen=chosen)

class CompiledGraphTests(unittest.TestCase):
    def reject(self,e,side='left'):
        with self.assertRaises(IntegrationError):check_graph(e,side)
    def test_correct_central(self):
        e,n=fixture();report=check_graph(e,'left');self.assertEqual(report['listeners'][1]['processor_side'],1)
    def test_correct_peripheral(self):
        e,n=fixture('right');self.assertEqual(check_graph(e,'right')['split_sender'],n.split.path)
    def test_missing_right_listener(self):
        e,n=fixture();e.nodes.remove(n.right);self.reject(e)
    def test_right_listener_wrong_device(self):
        e,n=fixture();put(n.right,'device',n.sensor);self.reject(e)
    def test_right_listener_wrong_side(self):
        e,n=fixture();put(n.right,'input-processors',[cell(n.processor,0)]);self.reject(e)
    def test_left_listener_wrong_device(self):
        e,n=fixture();put(n.left,'device',n.split);self.reject(e)
    def test_processor_missing(self):
        e,n=fixture();put(n.left,'input-processors',[]);self.reject(e)
    def test_processor_duplicated(self):
        e,n=fixture();put(n.left,'input-processors',[cell(n.processor,0),cell(n.processor,0)]);self.reject(e)
    def test_scaler_after_controller_rejected(self):
        e,n=fixture();scale=node('/scale','zmk,input-processor-scaler');put(n.left,'input-processors',[cell(n.processor,0),cell(scale,1)]);self.reject(e)
    def test_xy_mapper_before_controller_rejected(self):
        e,n=fixture();mapper=node('/map','zmk,input-processor-code-mapper');put(n.left,'input-processors',[cell(mapper,0),cell(n.processor,0)]);self.reject(e)
    def test_original_scale_before_controller_allowed(self):
        e,n=fixture();scale=node('/scale','zmk,input-processor-scaler');put(n.left,'input-processors',[cell(scale,1),cell(n.processor,0)]);check_graph(e,'left')
    def test_layer_override_rejected(self):
        e,n=fixture();n.left.children['override']=node('/trackball_listener/override','',layers=[1]);self.reject(e)
    def test_disabled_sensor_or_bus(self):
        for bus in (False,True):
            e,n=fixture()
            if bus:n.sensor.parent=node('/spi','nordic,nrf-spim');n.sensor.parent.status='disabled'
            else:n.sensor.status='disabled'
            with self.subTest(bus=bus):self.reject(e)
    def test_usb_must_be_cdc(self):
        e,n=fixture();n.uart.compats=['nordic,nrf-uart'];self.reject(e)
    def test_usb_disabled_parent(self):
        e,n=fixture();n.uart.parent=node('/usb','nordic,nrf-usbd');n.uart.parent.status='disabled';self.reject(e)
    def test_virtual_positions_exact(self):
        e,n=fixture();n.tx.props['map'].val[-1]+=1;self.reject(e)
    def test_layout_key_count_exact(self):
        e,n=fixture();n.layout.props['keys'].val.pop();self.reject(e)
    def test_legacy_chosen_transform_rejected(self):
        e,n=fixture();n.chosen['zmk,matrix-transform']=n.tx;self.reject(e)
    def test_replaced_scanner_rejected(self):
        e,n=fixture();n.scan.compats=['zmk,kscan-gpio-matrix'];self.reject(e)
    def test_private_command_missing(self):
        e,n=fixture();e.nodes.remove(n.command);self.reject(e)
    def test_right_missing_sensor_split(self):
        e,n=fixture('right');n.split.props.pop('device');self.reject(e,'right')
    def test_right_must_not_duplicate_conversion(self):
        e,n=fixture('right');put(n.left,'input-processors',[cell(n.processor,1)]);self.reject(e,'right')
    def test_side_mismatch(self):
        e,n=fixture('right');put(n.hw,'side',0);self.reject(e,'right')

LEFT_CFG='\n'.join(k+'=y' for k in ('CONFIG_ZMK_STUDIO','CONFIG_ZMK_STUDIO_RPC',
    'CONFIG_ZMK_STUDIO_TRANSPORT_UART','CONFIG_ZMK_BEHAVIOR_METADATA',
    'CONFIG_ZMK_KEYMAP_SETTINGS_STORAGE','CONFIG_ZMK_SPLIT_ROLE_CENTRAL'))+'\n# CONFIG_ZMK_STUDIO_LOCKING is not set\n'
class USBOnlyTests(unittest.TestCase):
    def test_usb_config(self):check_studio_config(LEFT_CFG+'# CONFIG_ZMK_STUDIO_TRANSPORT_BLE is not set\n','left')
    def test_ble_studio_rejected(self):
        with self.assertRaises(IntegrationError):check_studio_config(LEFT_CFG+'CONFIG_ZMK_STUDIO_TRANSPORT_BLE=y\n','left')
    def test_missing_uart_rejected(self):
        with self.assertRaises(IntegrationError):check_studio_config(LEFT_CFG.replace('CONFIG_ZMK_STUDIO_TRANSPORT_UART=y',''),'left')
    def test_right_config(self):check_studio_config('CONFIG_ZMK_BLE=y\nCONFIG_ZMK_SPLIT=y\n','right')
    def test_right_studio_rejected(self):
        with self.assertRaises(IntegrationError):check_studio_config(LEFT_CFG,'right')
    def test_build_left_studio_gatt_off_not_keyboard_ble(self):
        cmd=build_command(ROOT,Path('/workspace'),'left',{'board':'ms88sf3/nrf52840','shield':'modu_left','snippet':'studio-rpc-usb-uart'})
        self.assertIn('-DCONFIG_ZMK_STUDIO_TRANSPORT_BLE=n',cmd)
        self.assertIn('studio-rpc-usb-uart',cmd)
        self.assertNotIn('-DCONFIG_ZMK_BLE=n',cmd)
        self.assertNotIn('-DCONFIG_ZMK_SPLIT=n',cmd)
    def test_build_right_no_studio_snippet(self):
        cmd=build_command(ROOT,Path('/workspace'),'right',{'board':'ms88sf3/nrf52840','shield':'modu_right','snippet':None})
        self.assertIn('-DCONFIG_ZMK_STUDIO=n',cmd)
        self.assertNotIn('-S',cmd)
        self.assertNotIn('-DCONFIG_ZMK_STUDIO_TRANSPORT_BLE=n',cmd)
    def test_build_invalid_side(self):
        with self.assertRaises(ValueError):build_command(ROOT,Path('/workspace'),'neither',{})

if __name__=='__main__':unittest.main()
