/* Executes the real runtime.c against deterministic scheduling/transport doubles.
 * Does NOT check the Zephyr ABI, radio stack, USB, or the sensor driver. */
#include "host_runtime_mocks.h"
#include "modu_profile_under_test.c"
#include "modu_runtime_under_test.c"
#if MC_TEST_CENTRAL
#include "modu_input_under_test.c"
#endif
static struct zmk_position_state_changed events[128];
static unsigned event_count, command_count, last_source, last_side, last_value;
static int remote_status;
static bool inject_new_cpi;
static uint16_t sensor_cpi;
static unsigned local_tx;
static unsigned sent_tx[2];
static unsigned sent_tx_count[2];
static struct stored_config saved;
static unsigned saves;
int settings_save_one(const char *name,const void *data,size_t len) {
    REQUIRE(!state_lock.held); REQUIRE(!strcmp(name,MC_STORE_KEY));
    REQUIRE(len==sizeof(saved));memcpy(&saved,data,len);saves++;return 0;
}
int raise_zmk_position_state_changed(struct zmk_position_state_changed e) {
    REQUIRE(!state_lock.held);REQUIRE(event_count<ARRAY_SIZE(events));events[event_count++]=e;return 0;
}
void modu_hw_init(void) {}
void modu_local_cpi(uint16_t cpi) { sensor_cpi=cpi; }
void modu_local_tx(unsigned tx) { local_tx=tx; }
int zmk_behavior_invoke_binding(const struct zmk_behavior_binding *b,struct zmk_behavior_binding_event e,bool down) {
    REQUIRE(!state_lock.held); REQUIRE(down); unsigned side=b->param1&255,kind=b->param1>>8;
    command_count++;last_source=e.source;last_side=side;last_value=b->param2;
    if(kind==1 && side<2) {sent_tx[side]=b->param2;sent_tx_count[side]++;}
    /* This injection models a new key event arriving after a sync snapshot was taken. */
    if(inject_new_cpi && side==0 && kind==0) {
        inject_new_cpi=false;REQUIRE(modu_change(0,MC_KIND_CPI,MC_SET,1200)==0);
    }
    if(!MC_TEST_GLOBAL && e.source!=ZMK_POSITION_STATE_CHANGE_SOURCE_LOCAL) return remote_status;
    /* GLOBAL returns local status, ignoring the remote failure (upstream behavior.c). */
    if(side==MC_TEST_SIDE) {
        if(kind==0) modu_remote_cpi(side,(uint16_t)b->param2);else modu_local_tx(b->param2);
    }
    return 0;
}
static int read_stored(void *arg,void *dest,size_t len) { memcpy(dest,arg,len);return (int)len; }
static unsigned presses(void) { unsigned n=0;for(unsigned i=0;i<event_count;i++)n+=events[i].state;return n; }
static void test_tx_boot_default(void) {
    REQUIRE(tx_index[0]==MC_TX_PLUS_8 && tx_index[1]==MC_TX_PLUS_8);
    advance_to(1500);REQUIRE(local_tx==MC_TX_PLUS_8);
}
static void test_tx_reset_local(void) {
    advance_to(1500);
    REQUIRE(modu_tx_change(MC_TEST_SIDE,MC_SET,MC_TX_0)==0);
    REQUIRE(local_tx==MC_TX_0); /* Explicit 0 dBm must remain a selectable value. */
    REQUIRE(modu_tx_change(MC_TEST_SIDE,MC_RESET,0)==0);
    REQUIRE(local_tx==MC_TX_PLUS_8 && tx_index[MC_TEST_SIDE]==MC_TX_PLUS_8);
}
static void test_tx_reconnect_default(void) {
    advance_to(1500);
    REQUIRE(modu_tx_change(MC_TEST_SIDE,MC_SET,MC_TX_MINUS_20)==0);
    REQUIRE(local_tx==MC_TX_MINUS_20);
    modu_link_changed();
    REQUIRE(tx_index[0]==MC_TX_PLUS_8 && tx_index[1]==MC_TX_PLUS_8);
    REQUIRE(local_tx==MC_TX_PLUS_8);
#if MC_TEST_CENTRAL
    advance_to(3000);
    REQUIRE(sent_tx_count[0]>0 && sent_tx_count[1]>0);
    REQUIRE(sent_tx[0]==MC_TX_PLUS_8 && sent_tx[1]==MC_TX_PLUS_8);
#endif
}
static void test_settings(void) {
    REQUIRE(modu_change(MC_TEST_SIDE,MC_KIND_POINTER,MC_SET,175)==0);
    advance_to(1200);REQUIRE(saves==1);REQUIRE(saved.sides[MC_TEST_SIDE].pointer_pct==175);
    struct stored_config invalid=saved;invalid.sides[0].cpi=750;
    REQUIRE(settings_set("v2",sizeof(invalid),read_stored,&invalid)==-EINVAL);
    REQUIRE(settings_set("v2",sizeof(saved),read_stored,&saved)==0);
    REQUIRE(settings_set("other",sizeof(saved),read_stored,&saved)==-ENOENT);
}
#if MC_TEST_CENTRAL
static void arrow_mode(unsigned s) { REQUIRE(modu_change(s,MC_KIND_MODE,MC_SET,MC_ARROWS)==0); }
static void move(unsigned s,int x) {struct mc_result out;REQUIRE(modu_motion(s,0,x,true,&out)==0);}

static struct input_event input_event(unsigned axis,int value,bool sync) {
    return (struct input_event){.type=INPUT_EV_REL,.code=axis?INPUT_REL_Y:INPUT_REL_X,.value=value,.sync=sync};
}
static int feed(unsigned side,struct input_event *e) {
    struct zmk_input_processor_state state={0};
    return process(NULL,e,side,0,&state);
}
static void test_input_mouse(void) {
    REQUIRE(modu_change(0,MC_KIND_POINTER,MC_SET,150)==0);
    struct input_event e=input_event(0,1,true);REQUIRE(feed(0,&e)==0 && e.value==1);
    e=input_event(0,1,true);REQUIRE(feed(0,&e)==0 && e.value==2 && e.code==INPUT_REL_X);
    e=input_event(0,2,true);REQUIRE(feed(1,&e)==0 && e.value==2);
}
static void test_input_hold(void) {
    REQUIRE(modu_hold(0,900,MC_SCROLL,true)==0);
    struct input_event e=input_event(1,24,true);REQUIRE(feed(0,&e)==0 && e.code==INPUT_REL_WHEEL && e.value==-1);
    e=input_event(0,24,true);REQUIRE(feed(0,&e)==0 && e.code==INPUT_REL_HWHEEL && e.value==1);
    e=input_event(1,24,true);REQUIRE(feed(1,&e)==0 && e.code==INPUT_REL_Y && e.value==24);
    REQUIRE(modu_hold(0,900,0,false)==0);
    e=input_event(1,24,true);REQUIRE(feed(0,&e)==0 && e.code==INPUT_REL_Y && e.value==24);
}
static void test_input_arrows(void) {
    arrow_mode(1);
    struct input_event e=input_event(1,-40,true);REQUIRE(feed(1,&e)==ZMK_INPUT_PROC_STOP);
    advance_to(0);REQUIRE(event_count==1 && events[0].position==65 && events[0].state);
    advance_to(12);REQUIRE(event_count==2 && !events[1].state && events[1].position==65);
    e=input_event(0,40,true);REQUIRE(feed(1,&e)==ZMK_INPUT_PROC_STOP);
    advance_to(40);REQUIRE(event_count==3 && events[2].position==68);
}
static void test_input_frame(void) {
    arrow_mode(0);
    struct input_event e=input_event(0,40,false);REQUIRE(feed(0,&e)==ZMK_INPUT_PROC_STOP);
    advance_to(0);REQUIRE(event_count==0);
    e=input_event(1,0,true);REQUIRE(feed(0,&e)==ZMK_INPUT_PROC_STOP);
    advance_to(0);REQUIRE(event_count==1 && events[0].position==64);
}
static void test_input_off(void) {
    REQUIRE(modu_change(1,MC_KIND_MODE,MC_SET,MC_OFF)==0);
    struct input_event e=input_event(0,999,true);REQUIRE(feed(1,&e)==ZMK_INPUT_PROC_STOP);
    e=(struct input_event){.type=INPUT_EV_KEY,.code=INPUT_BTN_LEFT,.value=1,.sync=1};
    REQUIRE(feed(1,&e)==ZMK_INPUT_PROC_CONTINUE && e.value==1 && e.code==INPUT_BTN_LEFT);
    advance_to(100);REQUIRE(event_count==0);
}
static void test_input_reverse_scroll(void) {
    REQUIRE(modu_change(1,MC_KIND_MODE,MC_SET,MC_SCROLL)==0);
    REQUIRE(modu_change(1,MC_KIND_INVERT,MC_SET,1)==0);
    struct input_event e=input_event(1,12,true);REQUIRE(feed(1,&e)==0 && e.value==0 && e.sync);
    e=input_event(1,12,true);REQUIRE(feed(1,&e)==0 && e.value==1 && e.code==INPUT_REL_WHEEL);
}
static void test_input_diagonal(void) {
    arrow_mode(1);REQUIRE(modu_change(1,MC_KIND_DIAGONAL,MC_SET,1)==0);
    struct input_event e=input_event(0,40,false);REQUIRE(feed(1,&e)==ZMK_INPUT_PROC_STOP);
    e=input_event(1,-40,true);REQUIRE(feed(1,&e)==ZMK_INPUT_PROC_STOP);
    advance_to(55);REQUIRE(presses()==2 && event_count==4);
    REQUIRE(events[0].position==65 && events[2].position==68);
}
static void test_input_persistent(void) {
    REQUIRE(modu_change(0,MC_KIND_MODE,MC_SET,MC_SCROLL)==0);
    REQUIRE(modu_hold(0,900,MC_ARROWS,true)==0);
    REQUIRE(modu_change(0,MC_KIND_MODE,MC_SET,MC_OFF)==0);
    REQUIRE(mc_mode(&core,0)==MC_ARROWS);
    REQUIRE(modu_hold(0,900,0,false)==0);REQUIRE(mc_mode(&core,0)==MC_OFF);
}
static void test_remote_failure(void) {
    remote_status=-ENOTCONN;REQUIRE(modu_sync()==-ENOTCONN);
    REQUIRE(last_side==1);REQUIRE(last_source==0);
}
static void test_stale_snapshot(void) {
    inject_new_cpi=true;REQUIRE(modu_sync()==0);
    REQUIRE(core.config[0].cpi==1200); /* v0.1.0 erroneously changes it back to 600 */
    REQUIRE(modu_sync()==0);REQUIRE(sensor_cpi==1200);
}
static void test_cpi_retry(void) {
    sync_attempts=0;REQUIRE(modu_change(1,MC_KIND_CPI,MC_SET,1400)==0);REQUIRE(sync_attempts>0);
}
static void test_tx_both_default(void) {
    advance_to(1500);
    REQUIRE(modu_tx_change(MC_BOTH,MC_SET,MC_TX_0)==0);
    REQUIRE(tx_index[0]==MC_TX_0 && tx_index[1]==MC_TX_0);
    REQUIRE(modu_tx_change(MC_BOTH,MC_RESET,0)==0);
    REQUIRE(sent_tx[0]==MC_TX_PLUS_8 && sent_tx[1]==MC_TX_PLUS_8);
    REQUIRE(last_side==MC_RIGHT && last_source==0);
}
static void test_tx_manual_independent(void) {
    advance_to(1500);
    REQUIRE(modu_tx_change(MC_LEFT,MC_DEC,0)==0);
    REQUIRE(tx_index[0]==MC_TX_PLUS_6 && tx_index[1]==MC_TX_PLUS_8);
    REQUIRE(modu_tx_change(MC_RIGHT,MC_SET,MC_TX_0)==0);
    REQUIRE(tx_index[0]==MC_TX_PLUS_6 && tx_index[1]==MC_TX_0);
    REQUIRE(modu_tx_change(MC_RIGHT,MC_RESET,0)==0);
    REQUIRE(tx_index[0]==MC_TX_PLUS_6 && tx_index[1]==MC_TX_PLUS_8);
    REQUIRE(modu_tx_change(MC_RIGHT,MC_INC,0)==0);
    REQUIRE(tx_index[1]==MC_TX_PLUS_8); /* At maximum, increase saturates. */
    REQUIRE(modu_tx_change(MC_RIGHT,MC_SET,MC_TX_PLUS_8+1)==-EINVAL);
    advance_to(3000); /* Retry must retain manual left value during this session. */
    REQUIRE(sent_tx[0]==MC_TX_PLUS_6 && sent_tx[1]==MC_TX_PLUS_8);
}
static void test_tx_retry(void) {
    sync_attempts=0;remote_status=-ENOTCONN;
    REQUIRE(modu_tx_change(MC_RIGHT,MC_SET,7)==-ENOTCONN);REQUIRE(sync_attempts>0);
}
static void test_reentry(void) {
    REQUIRE(modu_change(0,MC_KIND_RATE,MC_SET,500)==0);
    arrow_mode(0);move(0,40);advance_to(0);REQUIRE(presses()==1);advance_to(12);
    REQUIRE(modu_change(0,MC_KIND_MODE,MC_SET,MC_MOUSE)==0);advance_to(12);
    arrow_mode(0);move(0,40);advance_to(12);REQUIRE(presses()==2);
}
static void test_reverse(void) {
    arrow_mode(0);move(0,160);advance_to(0);REQUIRE(presses()==1);
    move(0,-160);advance_to(130);
    for(unsigned i=1;i<event_count;i++) if(events[i].state) REQUIRE(events[i].position==MC_VIRTUAL_START+2);
}
static void test_release(void) {
    REQUIRE(modu_hold(0,12,MC_ARROWS,true)==0);move(0,80);advance_to(0);
    REQUIRE(event_count==1 && events[0].state);modu_link_changed();advance_to(0);
    REQUIRE(event_count==2 && !events[1].state);REQUIRE(mc_mode(&core,0)==MC_MOUSE);
    advance_to(100);REQUIRE(event_count==2);
}
static void test_sides(void) {
    arrow_mode(0);arrow_mode(1);move(0,40);move(1,-40);advance_to(0);REQUIRE(presses()==2);
    REQUIRE(modu_change(0,MC_KIND_MODE,MC_SET,MC_MOUSE)==0);advance_to(0);
    REQUIRE(event_count==3 && events[2].position==64 && !events[2].state);
    advance_to(12);REQUIRE(event_count==4 && events[3].position==67 && !events[3].state);
}
static void test_repeat_interval(void) {
    arrow_mode(0);move(0,160);advance_to(130);REQUIRE(presses()==4);
    int64_t previous=-40;
    for(unsigned i=0;i<event_count;i++) if(events[i].state) {REQUIRE(events[i].timestamp-previous>=40);previous=events[i].timestamp;}
}
#else
static void test_peripheral(void) {
    modu_remote_cpi(0,1200);REQUIRE(sensor_cpi==0);REQUIRE(core.config[0].cpi==600);
    modu_remote_cpi(1,1400);REQUIRE(sensor_cpi==1400);REQUIRE(core.config[1].cpi==1400);
    advance_to(1200);REQUIRE(saves==1 && saved.sides[1].cpi==1400);
}
#endif

#if MC_TEST_CENTRAL
static void profile(unsigned side, const char *dev,unsigned mode,unsigned param2) {
    mock_profile_slots[side]=(struct zmk_behavior_binding){.behavior_dev=dev,.param1=mode,.param2=param2};
}
static void test_cycle_sequence(void) {
    for(unsigned i=0;i<6;i++) {
        REQUIRE(modu_change(0,MC_KIND_CYCLE,MC_SET,MC_CYCLE_NEXT)==0);
        REQUIRE(mc_mode(&core,0)==(int)((i+1)%3));
    }
}
static void test_cycle_sides(void) {
    REQUIRE(modu_change(1,MC_KIND_CYCLE,MC_SET,MC_CYCLE_NEXT)==0);
    REQUIRE(mc_mode(&core,0)==MC_MOUSE && mc_mode(&core,1)==MC_SCROLL);
    REQUIRE(modu_change(0,MC_KIND_CYCLE,MC_SET,MC_CYCLE_NEXT)==0);
    REQUIRE(mc_mode(&core,0)==MC_SCROLL && mc_mode(&core,1)==MC_SCROLL);
}
static void test_cycle_held(void) {
    REQUIRE(modu_hold(0,8,MC_ARROWS,true)==0);
    REQUIRE(modu_change(0,MC_KIND_CYCLE,MC_SET,MC_CYCLE_NEXT)==0);
    REQUIRE(mc_mode(&core,0)==MC_ARROWS && core.config[0].mode==MC_SCROLL);
    REQUIRE(modu_hold(0,8,0,false)==0 && mc_mode(&core,0)==MC_SCROLL);
}
static void test_cycle_modes(void) {
    REQUIRE(modu_change(0,MC_KIND_CYCLE,MC_SET,MC_CYCLE_PREVIOUS)==0 && mc_mode(&core,0)==MC_ARROWS);
    REQUIRE(modu_change(0,MC_KIND_MODE,MC_SET,MC_OFF)==0);
    REQUIRE(modu_change(0,MC_KIND_CYCLE,MC_SET,MC_CYCLE_NEXT)==0 && mc_mode(&core,0)==MC_MOUSE);
    REQUIRE(modu_change(0,MC_KIND_CYCLE,MC_SET,MC_CYCLE_MOUSE_SCROLL)==0 && mc_mode(&core,0)==MC_SCROLL);
    REQUIRE(modu_change(0,MC_KIND_CYCLE,MC_SET,MC_CYCLE_MOUSE_SCROLL)==0 && mc_mode(&core,0)==MC_MOUSE);
    REQUIRE(modu_change(0,MC_KIND_CYCLE,MC_SET,88)<0 && mc_mode(&core,0)==MC_MOUSE);
}
static void test_profile_mouse_scroll(void) {
    profile(0,"lball",MC_SCROLL,0); struct mc_result out;
    REQUIRE(modu_motion(0,1,24,true,&out)==0 && out.mode==MC_SCROLL && out.value==-1);
    REQUIRE(modu_motion(1,0,24,true,&out)==0 && out.mode==MC_MOUSE && out.value==24);
    REQUIRE(command_count==0 && event_count==0 && saves==0);
}
static void test_profile_arrows(void) {
    profile(1,"rball",MC_ARROWS,0); struct mc_result out;
    REQUIRE(modu_motion(1,0,40,true,&out)==0 && out.mode==MC_ARROWS);
    advance_to(0);REQUIRE(event_count==1 && events[0].position==68 && events[0].state);
    advance_to(12);REQUIRE(event_count==2 && !events[1].state);
}
static void test_profile_invalid(void) {
    struct mc_result out;
    const char *names[]={"kp","bootloader","rball",NULL,"lball","lball"};
    for(unsigned i=0;i<6;i++) {
        profile(0,names[i],i==4 ? 500 : MC_SCROLL,i==5 ? 1 : 0);
        REQUIRE(modu_motion(0,0,12,true,&out)==0 && out.mode==MC_MOUSE);
    }
    REQUIRE(command_count==0 && event_count==0);
}
static void test_profile_discard(void) {
    struct mc_result out;profile(0,"lball",MC_MOUSE,0);
    REQUIRE(modu_motion(0,0,24,true,&out)==0 && out.mode==MC_MOUSE);
    mock_unsaved=1;
    profile(0,"lball",MC_SCROLL,0);REQUIRE(modu_motion(0,0,24,true,&out)==0 && out.mode==MC_SCROLL);
    mock_unsaved=0;
    profile(0,"lball",MC_MOUSE,0);REQUIRE(modu_motion(0,0,24,true,&out)==0 && out.mode==MC_MOUSE);
    advance_to(1400);REQUIRE(saves==0); /* Studio drafts never auto-save runtime state. */
}
static void test_profile_cycle_override(void) {
    profile(0,"lball",MC_SCROLL,0);
    REQUIRE(modu_change(0,MC_KIND_CYCLE,MC_SET,MC_CYCLE_NEXT)==0 && mc_mode(&core,0)==MC_ARROWS);
    struct mc_result out;REQUIRE(modu_motion(0,0,1,true,&out)==0 && out.mode==MC_ARROWS);
    profile(0,"lball",MC_MOUSE,0);
    REQUIRE(modu_motion(0,0,1,true,&out)==0 && out.mode==MC_MOUSE);
    REQUIRE(core.config[0].mode==MC_ARROWS); /* Saved physical preference is separate. */
}
static void test_profile_boot(void) {
    core.config[0].mode=MC_SCROLL;
    profile(0,"lball",MC_MOUSE,0);
    struct mc_result out;REQUIRE(modu_motion(0,0,1,true,&out)==0 && out.mode==MC_MOUSE);
    profile(0,"lball",MC_PROFILE_KEYS,0);
    REQUIRE(modu_motion(0,0,1,true,&out)==0 && out.mode==MC_SCROLL);
    REQUIRE(mc_profile(&core,2,0)<0 && mc_profile(&core,0,9)<0);
}
static void test_profile_hold(void) {
    profile(0,"lball",MC_SCROLL,0);
    REQUIRE(modu_hold(0,2,MC_ARROWS,true)==0);
    profile(0,"lball",MC_MOUSE,0);
    struct mc_result out;REQUIRE(modu_motion(0,0,0,true,&out)==0 && out.mode==MC_ARROWS);
    REQUIRE(modu_hold(0,2,0,false)==0 && mc_mode(&core,0)==MC_MOUSE);
}
static void test_profile_pending(void) {
    profile(0,"lball",MC_ARROWS,0);struct mc_result out;
    REQUIRE(modu_motion(0,0,160,true,&out)==0);advance_to(0);REQUIRE(event_count==1 && events[0].state);
    profile(0,"lball",MC_MOUSE,0);advance_to(100);
    REQUIRE(event_count==2 && !events[1].state && mc_mode(&core,0)==MC_MOUSE);
}
static void test_profile_readonly(void) {
    profile(0,"lball",MC_SCROLL,0);struct mc_result out;
    for(unsigned i=0;i<100;i++) REQUIRE(modu_motion(0,0,1,true,&out)==0);
    advance_to(1400);REQUIRE(command_count==0 && saves==0 && event_count==0);
    REQUIRE(mock_profile_reads==100);
}
static void test_profile_base_only(void) {
    /* The getter double asserts immutable layer ID 0 and positions 75/76. */
    profile(0,"lball",MC_OFF,0);profile(1,"rball",MC_SCROLL,0);
    struct mc_result out;REQUIRE(modu_motion(0,1,24,true,&out)==0 && out.mode==MC_OFF);
    REQUIRE(modu_motion(1,1,24,true,&out)==0 && out.mode==MC_SCROLL);
}
/* Reboot simulations reload the actual serialized runtime record. They do NOT
 * substitute memory copies for settings_set(), and they leave Studio key bindings
 * unchanged as a powered-off device would. No ZMK keymap writes are performed. */
static void reboot_from_saved(void) {
    struct stored_config record=saved;
    for(unsigned i=0;i<work_count;i++) work_items[i]->pending=false;
    work_count=0;mock_now=0;mock_unsaved=0;
    REQUIRE(initialize()==0);
    REQUIRE(settings_set("v2",sizeof(record),read_stored,&record)==0);
}
static unsigned current_mode(unsigned side) {
    struct mc_result out;
    REQUIRE(modu_motion(side,0,0,true,&out)==0);
    return out.mode;
}
static void mouse_baselines(void) {
    profile(0,"lball",MC_MOUSE,0); profile(1,"rball",MC_MOUSE,0);
    REQUIRE(current_mode(0)==MC_MOUSE && current_mode(1)==MC_MOUSE);
}
static void test_remember_left_reboot(void) {
    mouse_baselines();
    REQUIRE(modu_change(0,MC_KIND_CYCLE,MC_SET,MC_CYCLE_NEXT)==0);
    advance_to(1200);REQUIRE(saved.profiles[0].manual==1);
    reboot_from_saved();
    REQUIRE(current_mode(0)==MC_SCROLL && current_mode(1)==MC_MOUSE);
    REQUIRE(mock_profile_slots[0].param1==MC_MOUSE);
}
static void test_remember_right_reboot(void) {
    mouse_baselines();
    REQUIRE(modu_change(1,MC_KIND_CYCLE,MC_SET,MC_CYCLE_NEXT)==0);
    REQUIRE(modu_change(1,MC_KIND_CYCLE,MC_SET,MC_CYCLE_NEXT)==0);
    advance_to(1200);reboot_from_saved();
    REQUIRE(current_mode(1)==MC_ARROWS && current_mode(0)==MC_MOUSE);
}
static void test_remember_both_reboot(void) {
    mouse_baselines();
    REQUIRE(modu_change(0,MC_KIND_MODE,MC_SET,MC_SCROLL)==0);
    REQUIRE(modu_change(1,MC_KIND_MODE,MC_SET,MC_OFF)==0);
    advance_to(1200);
    for(unsigned i=0;i<4;i++) { reboot_from_saved();REQUIRE(current_mode(0)==MC_SCROLL && current_mode(1)==MC_OFF); }
}
static void test_remember_hold_not_saved(void) {
    mouse_baselines();
    REQUIRE(modu_change(0,MC_KIND_CYCLE,MC_SET,MC_CYCLE_NEXT)==0);
    REQUIRE(modu_hold(0,800,MC_ARROWS,true)==0);
    advance_to(1200);REQUIRE(mc_mode(&core,0)==MC_ARROWS);
    REQUIRE(saved.sides[0].mode==MC_SCROLL);
    reboot_from_saved();REQUIRE(current_mode(0)==MC_SCROLL && core.motion[0].held==0);
}
static void test_remember_hold_cycle_reboot(void) {
    mouse_baselines();REQUIRE(modu_hold(1,801,MC_ARROWS,true)==0);
    REQUIRE(modu_change(1,MC_KIND_CYCLE,MC_SET,MC_CYCLE_NEXT)==0);
    REQUIRE(mc_mode(&core,1)==MC_ARROWS);
    REQUIRE(modu_hold(1,801,0,false)==0);
    REQUIRE(mc_mode(&core,1)==MC_SCROLL);
    advance_to(1200);reboot_from_saved();REQUIRE(current_mode(1)==MC_SCROLL);
}
static void test_remember_same_value_saves_priority(void) {
    profile(0,"lball",MC_SCROLL,0);REQUIRE(current_mode(0)==MC_SCROLL);
    /* config.mode already Mouse. Changing only priority must still save. */
    REQUIRE(core.config[0].mode==MC_MOUSE);
    REQUIRE(modu_change(0,MC_KIND_MODE,MC_SET,MC_MOUSE)==0);
    advance_to(1200);REQUIRE(saves==1);
    reboot_from_saved();REQUIRE(current_mode(0)==MC_MOUSE);
}
static void test_remember_new_studio_baseline(void) {
    mouse_baselines();REQUIRE(modu_change(0,MC_KIND_CYCLE,MC_SET,MC_CYCLE_NEXT)==0);
    advance_to(1200);reboot_from_saved();REQUIRE(current_mode(0)==MC_SCROLL);
    profile(0,"lball",MC_ARROWS,0);REQUIRE(current_mode(0)==MC_ARROWS);
    advance_to(1200);REQUIRE(saved.profiles[0].manual==0);
    reboot_from_saved();REQUIRE(current_mode(0)==MC_ARROWS);
    /* Changing back to Mouse must not revive an obsolete override. */
    profile(0,"lball",MC_MOUSE,0);REQUIRE(current_mode(0)==MC_MOUSE);
    advance_to(1200);reboot_from_saved();REQUIRE(current_mode(0)==MC_MOUSE);
}
static void test_remember_discard_restores_override(void) {
    mouse_baselines();REQUIRE(modu_change(0,MC_KIND_CYCLE,MC_SET,MC_CYCLE_NEXT)==0);
    advance_to(1200);unsigned count=saves;
    mock_unsaved=1;profile(0,"lball",MC_ARROWS,0);REQUIRE(current_mode(0)==MC_ARROWS);
    advance_to(2500);REQUIRE(saves==count);
    profile(0,"lball",MC_MOUSE,0);mock_unsaved=0;REQUIRE(current_mode(0)==MC_SCROLL);
    advance_to(4000);REQUIRE(saves==count);
    reboot_from_saved();REQUIRE(current_mode(0)==MC_SCROLL);
}
static void test_remember_draft_cpi_save(void) {
    mouse_baselines();REQUIRE(modu_change(0,MC_KIND_CYCLE,MC_SET,MC_CYCLE_NEXT)==0);
    advance_to(1200);
    mock_unsaved=1;profile(0,"lball",MC_ARROWS,0);REQUIRE(current_mode(0)==MC_ARROWS);
    REQUIRE(modu_change(0,MC_KIND_CPI,MC_SET,1200)==0);advance_to(2400);
    REQUIRE(saved.profiles[0].mode==MC_MOUSE && saved.profiles[0].manual==1);
    profile(0,"lball",MC_MOUSE,0);reboot_from_saved();
    REQUIRE(current_mode(0)==MC_SCROLL && core.config[0].cpi==1200);
}
static void test_remember_manual_during_draft(void) {
    mouse_baselines();mock_unsaved=1;
    profile(0,"lball",MC_SCROLL,0);REQUIRE(current_mode(0)==MC_SCROLL);
    REQUIRE(modu_change(0,MC_KIND_CYCLE,MC_SET,MC_CYCLE_NEXT)==0);
    REQUIRE(current_mode(0)==MC_ARROWS);advance_to(1200);
    profile(0,"lball",MC_MOUSE,0);reboot_from_saved();REQUIRE(current_mode(0)==MC_ARROWS);
}
static void test_remember_save_same_baseline(void) {
    mouse_baselines();REQUIRE(modu_change(1,MC_KIND_CYCLE,MC_SET,MC_CYCLE_NEXT)==0);
    advance_to(1200);mock_unsaved=1;REQUIRE(current_mode(1)==MC_SCROLL);
    mock_unsaved=0;REQUIRE(current_mode(1)==MC_SCROLL);
    advance_to(2400);reboot_from_saved();REQUIRE(current_mode(1)==MC_SCROLL);
}
static void test_remember_reconnect(void) {
    mouse_baselines();REQUIRE(modu_change(1,MC_KIND_MODE,MC_SET,MC_ARROWS)==0);
    REQUIRE(modu_hold(1,909,MC_SCROLL,true)==0);modu_link_changed();
    REQUIRE(current_mode(1)==MC_ARROWS && core.motion[1].held==0);
    advance_to(1200);reboot_from_saved();REQUIRE(current_mode(1)==MC_ARROWS);
}
static void test_remember_v1_migration(void) {
    struct stored_config_v1 old={.version=MC_STORE_VERSION_V1,.sides={mc_defaults,mc_defaults}};
    old.sides[0].mode=MC_SCROLL;old.sides[0].cpi=1800;
    old.sides[1].pointer_pct=175;
    REQUIRE(settings_set("v1",sizeof(old),read_stored,&old)==0);
    profile(0,"lball",MC_MOUSE,0);profile(1,"rball",MC_ARROWS,0);
    REQUIRE(current_mode(0)==MC_SCROLL && current_mode(1)==MC_ARROWS);
    advance_to(1200);REQUIRE(saved.version==MC_STORE_VERSION);
    reboot_from_saved();REQUIRE(current_mode(0)==MC_SCROLL && core.config[0].cpi==1800);
    REQUIRE(core.config[1].pointer_pct==175);
    /* Older record must not win if loaded after v2. */
    old.sides[0].cpi=200;
    REQUIRE(settings_set("v1",sizeof(old),read_stored,&old)==0);
    REQUIRE(core.config[0].cpi==1800);
}
static void test_remember_corrupt_record(void) {
    mouse_baselines();REQUIRE(modu_change(0,MC_KIND_CYCLE,MC_SET,MC_CYCLE_NEXT)==0);
    advance_to(1200);struct stored_config bad=saved;
    bad.profiles[0].mode=99;REQUIRE(settings_set("v2",sizeof(bad),read_stored,&bad)==-EINVAL);
    bad=saved;bad.profiles[1].manual=2;REQUIRE(settings_set("v2",sizeof(bad),read_stored,&bad)==-EINVAL);
    bad=saved;bad.profiles[0].reserved=1;REQUIRE(settings_set("v2",sizeof(bad),read_stored,&bad)==-EINVAL);
    REQUIRE(settings_set("v2",sizeof(saved)-1,read_stored,&saved)==-EINVAL);
    REQUIRE(current_mode(0)==MC_SCROLL);
}
static void test_remember_save_debounce(void) {
    mouse_baselines();REQUIRE(modu_change(0,MC_KIND_CYCLE,MC_SET,MC_CYCLE_NEXT)==0);
    advance_to(1000);REQUIRE(saves==0);
    REQUIRE(modu_change(0,MC_KIND_CYCLE,MC_SET,MC_CYCLE_NEXT)==0);
    advance_to(2199);REQUIRE(saves==0);
    advance_to(2200);REQUIRE(saves==1 && saved.sides[0].mode==MC_ARROWS);
}

#endif
int main(int argc,char **argv) {
    REQUIRE(argc==2);initialize();
    if(!strcmp(argv[1],"settings"))test_settings();
    else if(!strcmp(argv[1],"tx_boot"))test_tx_boot_default();
    else if(!strcmp(argv[1],"tx_reset_local"))test_tx_reset_local();
    else if(!strcmp(argv[1],"tx_reconnect"))test_tx_reconnect_default();
#if MC_TEST_CENTRAL

    else if(!strcmp(argv[1],"remember_left_reboot"))test_remember_left_reboot();
    else if(!strcmp(argv[1],"remember_right_reboot"))test_remember_right_reboot();
    else if(!strcmp(argv[1],"remember_both_reboot"))test_remember_both_reboot();
    else if(!strcmp(argv[1],"remember_hold_not_saved"))test_remember_hold_not_saved();
    else if(!strcmp(argv[1],"remember_hold_cycle_reboot"))test_remember_hold_cycle_reboot();
    else if(!strcmp(argv[1],"remember_same_value_saves_priority"))test_remember_same_value_saves_priority();
    else if(!strcmp(argv[1],"remember_new_studio_baseline"))test_remember_new_studio_baseline();
    else if(!strcmp(argv[1],"remember_discard_restores_override"))test_remember_discard_restores_override();
    else if(!strcmp(argv[1],"remember_draft_cpi_save"))test_remember_draft_cpi_save();
    else if(!strcmp(argv[1],"remember_manual_during_draft"))test_remember_manual_during_draft();
    else if(!strcmp(argv[1],"remember_save_same_baseline"))test_remember_save_same_baseline();
    else if(!strcmp(argv[1],"remember_reconnect"))test_remember_reconnect();
    else if(!strcmp(argv[1],"remember_v1_migration"))test_remember_v1_migration();
    else if(!strcmp(argv[1],"remember_corrupt_record"))test_remember_corrupt_record();
    else if(!strcmp(argv[1],"remember_save_debounce"))test_remember_save_debounce();
    else if(!strcmp(argv[1],"cycle_sequence"))test_cycle_sequence();
    else if(!strcmp(argv[1],"cycle_sides"))test_cycle_sides();
    else if(!strcmp(argv[1],"cycle_held"))test_cycle_held();
    else if(!strcmp(argv[1],"cycle_modes"))test_cycle_modes();
    else if(!strcmp(argv[1],"profile_mouse_scroll"))test_profile_mouse_scroll();
    else if(!strcmp(argv[1],"profile_arrows"))test_profile_arrows();
    else if(!strcmp(argv[1],"profile_invalid"))test_profile_invalid();
    else if(!strcmp(argv[1],"profile_discard"))test_profile_discard();
    else if(!strcmp(argv[1],"profile_cycle_override"))test_profile_cycle_override();
    else if(!strcmp(argv[1],"profile_boot"))test_profile_boot();
    else if(!strcmp(argv[1],"profile_hold"))test_profile_hold();
    else if(!strcmp(argv[1],"profile_pending"))test_profile_pending();
    else if(!strcmp(argv[1],"profile_readonly"))test_profile_readonly();
    else if(!strcmp(argv[1],"profile_base_only"))test_profile_base_only();
    else if(!strcmp(argv[1],"input_mouse"))test_input_mouse();
    else if(!strcmp(argv[1],"input_hold"))test_input_hold();
    else if(!strcmp(argv[1],"input_arrows"))test_input_arrows();
    else if(!strcmp(argv[1],"input_frame"))test_input_frame();
    else if(!strcmp(argv[1],"input_off"))test_input_off();
    else if(!strcmp(argv[1],"input_reverse_scroll"))test_input_reverse_scroll();
    else if(!strcmp(argv[1],"input_diagonal"))test_input_diagonal();
    else if(!strcmp(argv[1],"input_persistent"))test_input_persistent();
    else if(!strcmp(argv[1],"remote_failure"))test_remote_failure();
    else if(!strcmp(argv[1],"stale_snapshot"))test_stale_snapshot();
    else if(!strcmp(argv[1],"cpi_retry"))test_cpi_retry();
    else if(!strcmp(argv[1],"tx_retry"))test_tx_retry();
    else if(!strcmp(argv[1],"tx_both"))test_tx_both_default();
    else if(!strcmp(argv[1],"tx_manual"))test_tx_manual_independent();
    else if(!strcmp(argv[1],"reentry"))test_reentry();
    else if(!strcmp(argv[1],"reverse"))test_reverse();
    else if(!strcmp(argv[1],"release"))test_release();
    else if(!strcmp(argv[1],"sides"))test_sides();
    else if(!strcmp(argv[1],"repeat_interval"))test_repeat_interval();
#else
    else if(!strcmp(argv[1],"peripheral"))test_peripheral();
#endif
    else {fprintf(stderr,"Unknown test\n");return 2;}
    printf("PASS: %s (%s, HOST DOUBLES ONLY)\n",argv[1],MC_TEST_CENTRAL?"central":"peripheral");return 0;
}
