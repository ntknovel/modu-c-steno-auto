"""Synthetic EDT objects; NOT results from a real Zephyr configure or keyboard."""
from copy import deepcopy
import json
from pathlib import Path
from types import SimpleNamespace as NS
import sys
import unittest
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from prepare_from_edt import (resolve_edt, check_preserved_nodes, check_baseline_config,
                              original_keymap, PreflightError, ORIGINAL)
from build_firmware import baseline_command
from test_integration import fixture as extended_fixture, node, put
LAYOUT = json.loads((ROOT/'config/modu.json').read_text())['layouts']['default_transform']['layout']

def original(side='left'):
    e, n = extended_fixture(side)
    put(n.tx, 'rows', 6)
    put(n.tx, 'map', [(r << 8) | c for r, c in ORIGINAL])
    n.chosen.pop('zmk,physical-layout')
    n.chosen['zmk,matrix-transform'] = n.tx
    e.nodes = [x for x in e.nodes if x not in (n.layout, n.hw, n.command, n.processor)]
    put(n.left, 'input-processors', [])
    put(n.right, 'input-processors', [])
    put(n.sensor, 'cpi', 600)
    put(n.sensor, 'rotation', 45)
    put(n.sensor, 'spi-max-frequency', 2000000)
    if side == 'right':
        n.left.status = 'disabled'
    return e, n

def extended(e):
    e = deepcopy(e)
    processor = node('/input_processors/modu_tb', 'modu,trackball-processor')
    e.nodes.append(processor)
    for i, path in enumerate(('/trackball_listener', '/peripheral_trackball_listener')):
        for n in e.nodes:
            if n.path == path and n.status == 'okay':
                n.props['input-processors'].val.append(NS(controller=processor, data={'side': i}))
    return e

class OriginalEDTTests(unittest.TestCase):
    def test_left_uses_original_sensor_and_scanner(self):
        e,n=original(); text,r=resolve_edt(e,'left',LAYOUT)
        self.assertEqual(r['local_sensor'],n.sensor.path)
        self.assertEqual(r['scan_wrapper'],n.scan.path)
        self.assertIn('input-processors = <&modu_tb 0>',text)
        self.assertIn('input-processors = <&modu_tb 1>',text)
    def test_right_disabled_local_listener_is_valid(self):
        e,n=original('right');text,r=resolve_edt(e,'right',LAYOUT)
        self.assertEqual(r['local_sensor'],n.sensor.path)
        self.assertNotIn('input-processors =',text)
        self.assertNotIn('status =',text)
    def test_right_absent_local_listener_is_valid(self):
        e,n=original('right');e.nodes.remove(n.left)
        _,r=resolve_edt(e,'right',LAYOUT);self.assertEqual(r['split_device'],n.split.path)
    def test_right_ignores_inactive_listener_wrong_reference(self):
        e,n=original('right');put(n.left,'device',n.scan)
        self.assertEqual(resolve_edt(e,'right',LAYOUT)[1]['local_sensor'],n.sensor.path)
    def test_right_requires_real_split_sender(self):
        e,n=original('right');n.split.props.pop('device')
        with self.assertRaises(PreflightError):resolve_edt(e,'right',LAYOUT)
    def test_right_rejects_ambiguous_sender(self):
        e,n=original('right');e.nodes.append(node('/other','zmk,input-split',device=n.sensor))
        with self.assertRaises(PreflightError):resolve_edt(e,'right',LAYOUT)
    def test_disabled_sensor_rejected(self):
        for side in ('left','right'):
            e,n=original(side);n.sensor.status='disabled'
            with self.subTest(side=side),self.assertRaises(PreflightError):resolve_edt(e,side,LAYOUT)
    def test_disabled_bus_rejected(self):
        e,n=original();n.sensor.parent=node('/spi','nordic,nrf-spim');n.sensor.parent.status='disabled'
        with self.assertRaises(PreflightError):resolve_edt(e,'left',LAYOUT)
    def test_compiled_matrix_order_checked(self):
        e,n=original();n.tx.props['map'].val[0],n.tx.props['map'].val[1]=1,0
        with self.assertRaises(PreflightError):resolve_edt(e,'left',LAYOUT)
    def test_original_dimensions_checked(self):
        e,n=original();put(n.tx,'rows',7)
        with self.assertRaises(PreflightError):resolve_edt(e,'left',LAYOUT)
    def test_studio_layout_order_checked(self):
        e,_=original();bad=deepcopy(LAYOUT);bad[-1]['col']=3
        with self.assertRaises(PreflightError):resolve_edt(e,'left',bad)
    def test_coordinates_all_forwarded(self):
        for side in ('left','right'):
            text,_=resolve_edt(original(side)[0],side,LAYOUT)
            lines=[s.strip() for s in text.splitlines() if '<&key_physical_attrs ' in s]
            self.assertEqual(len(lines),71)
            for k,line in zip(LAYOUT,lines):
                expected=[round(k.get('w',1)*100),round(k.get('h',1)*100),round(k['x']*100),round(k['y']*100),0,0,0]
                self.assertIn('<&key_physical_attrs '+' '.join(map(str,expected)),line)
    def test_sensor_properties_not_overwritten_by_generation(self):
        text,_=resolve_edt(original()[0],'left',LAYOUT)
        for assignment in ('cpi =','rotation =','gpios =','polling','spi-max-frequency ='):
            self.assertNotIn(assignment,text)
    def test_original_processor_chain_retained(self):
        e,n=original();p=node('/processors/scale','zmk,input-processor-scaler')
        put(n.left,'input-processors',[NS(controller=p,data={'multiplier':1,'divisor':2})])
        text,r=resolve_edt(e,'left',LAYOUT)
        self.assertIn('<&{/processors/scale} 1 2>, <&modu_tb 0>',text)
        self.assertEqual(r['listeners'][0]['previous_chain'][0]['data'],{'multiplier':1,'divisor':2})
    def test_xy_mapper_not_silently_preserved(self):
        e,n=original();p=node('/mapper','zmk,input-processor-code-mapper')
        put(n.left,'input-processors',[NS(controller=p,data={})])
        with self.assertRaises(PreflightError):resolve_edt(e,'left',LAYOUT)
    def test_active_layer_override_rejected(self):
        e,n=original();n.left.children['layer']=node('/trackball_listener/layer','',layers=[1])
        with self.assertRaises(PreflightError):resolve_edt(e,'left',LAYOUT)
    def test_final_properties_unchanged_pass(self):
        e,_=original();_,r=resolve_edt(e,'left',LAYOUT)
        self.assertTrue(check_preserved_nodes(extended(e),r)['original_sensor_scan_split_properties_preserved'])
    def test_final_sensor_cpi_or_rotation_change_rejected(self):
        for prop in ('cpi','rotation','spi-max-frequency'):
            e,_=original();_,r=resolve_edt(e,'left',LAYOUT);end=extended(e)
            sensor=next(x for x in end.nodes if x.path==r['local_sensor']);put(sensor,prop,123)
            with self.subTest(prop=prop),self.assertRaises(PreflightError):check_preserved_nodes(end,r)
    def test_final_split_device_change_rejected(self):
        e,n=original('right');_,r=resolve_edt(e,'right',LAYOUT);put(n.split,'device',n.scan)
        with self.assertRaises(PreflightError):check_preserved_nodes(e,r)
    def test_auto_phandle_allocation_does_not_false_fail(self):
        e,n=original();put(n.sensor,'phandle',10);_,r=resolve_edt(e,'left',LAYOUT);end=extended(e)
        for x in end.nodes:
            if x.path==n.sensor.path:put(x,'phandle',33)
        check_preserved_nodes(end,r)
    def test_baseline_role_and_isolation(self):
        check_baseline_config('CONFIG_ZMK_SPLIT=y\nCONFIG_ZMK_SPLIT_ROLE_CENTRAL=y\n','left')
        check_baseline_config('CONFIG_ZMK_SPLIT=y\n','right')
        with self.assertRaises(PreflightError):check_baseline_config('CONFIG_ZMK_SPLIT=y\nCONFIG_MODU_CONTROL=y\n','right')
        with self.assertRaises(PreflightError):check_baseline_config('CONFIG_ZMK_SPLIT=y\n','left')
    def test_original_keymap_hash(self):
        self.assertGreater(len(original_keymap(ROOT)),1000)
    def test_baseline_command_has_no_extension_or_studio(self):
        for side in ('left','right'):
            cmd=list(map(str,baseline_command(ROOT,Path('/work'),side,{'board':'ms88sf3/nrf52840','shield':'modu_'+side})))
            self.assertIn('--cmake-only',cmd)
            joined=' '.join(cmd)
            self.assertNotIn('modu-control',joined);self.assertNotIn('STUDIO',joined);self.assertNotIn('-S',cmd)
            self.assertIn('original-config-'+side,joined)
    def test_production_build_imports_compiled_edt_not_raw_parser(self):
        import build_firmware
        self.assertEqual(build_firmware.prepare.__module__,'prepare_from_edt')

if __name__=='__main__':unittest.main()
