"""Static policy and built-config checker tests; no radio or Zephyr simulation."""
from pathlib import Path
import importlib.util
import re
import unittest
ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("check_built_tx", ROOT / "scripts/check_built.py")
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)
class TxDefaultsTests(unittest.TestCase):
    def test_common_build_fragment_selects_maximum(self):
        text = (ROOT / "modules/modu-control/modu.conf").read_text()
        self.assertRegex(text, r"(?m)^CONFIG_BT_CTLR_TX_PWR_PLUS_8=y$")
        self.assertRegex(text, r"(?m)^CONFIG_BT_CTLR_TX_PWR_DYNAMIC_CONTROL=y$")
    def test_default_alias_does_not_redefine_zero(self):
        text = (ROOT / "modules/modu-control/include/dt-bindings/zmk/modu_control.h").read_text()
        self.assertRegex(text, r"(?m)^#define MC_TX_0 5$")
        self.assertRegex(text, r"(?m)^#define MC_TX_MAX_INDEX MC_TX_PLUS_8$")
        self.assertRegex(text, r"(?m)^#define MC_TX_DEFAULT MC_TX_MAX_INDEX$")
    def test_hardware_discovery_uses_maximum_default(self):
        text = (ROOT / "modules/modu-control/src/hardware.c").read_text()
        self.assertIn("requested_tx=MC_TX_DEFAULT", text)
        self.assertIn("discovery=MAX(tx_dbm[MC_TX_DEFAULT],p)", text)
    def test_studio_default_label_matches_maximum(self):
        text = (ROOT / "modules/modu-control/src/behavior.c").read_text()
        self.assertIn('VAL("+8 dBm (default / maximum)",9)', text)
        self.assertNotIn('0 dBm (default)', text)
    def test_accepts_built_maximum(self):
        checker.check_tx_power_config("CONFIG_BT_CTLR_TX_PWR_PLUS_8=y\nCONFIG_BT_CTLR_TX_PWR_DBM=8\n")
    def test_rejects_built_zero_even_when_plus8_flag_is_present(self):
        with self.assertRaises(SystemExit):
            checker.check_tx_power_config("CONFIG_BT_CTLR_TX_PWR_PLUS_8=y\nCONFIG_BT_CTLR_TX_PWR_DBM=0\n")
    def test_rejects_missing_plus8_selection(self):
        with self.assertRaises(SystemExit):
            checker.check_tx_power_config("CONFIG_BT_CTLR_TX_PWR_DBM=8\n")
    def test_rejects_missing_effective_numeric_power(self):
        with self.assertRaises(SystemExit):
            checker.check_tx_power_config("CONFIG_BT_CTLR_TX_PWR_PLUS_8=y\n")
