"""Native square-cross geometry and generated DTS. Fixtures are NOT hardware builds."""
from copy import deepcopy
from pathlib import Path
import json
import re
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
from prepare_build import resolve_dts, ORIGINAL
from layout_contract import POSITIONS
from test_prepare import fixture
import validate

class CrossLayoutTests(unittest.TestCase):
    def setUp(self):
        self.layout = json.loads((ROOT/'config/modu.json').read_text())['layouts']['default_transform']['layout']

    def check_cross(self, start, center):
        c=self.layout[center]
        for i,(dx,dy) in enumerate(((0,-1),(0,1),(-1,0),(1,0))):
            with self.subTest(position=start+i):
                p=self.layout[start+i]
                self.assertEqual((p['x']-c['x'],p['y']-c['y']),(dx,dy))

    def test_left_cross_direction_order(self): self.check_cross(61,69)
    def test_right_cross_direction_order(self): self.check_cross(65,70)

    def test_crosses_aligned_under_outer_modifier_groups(self):
        left,right=self.layout[69],self.layout[70]
        self.assertEqual(left['y'],right['y'])
        self.assertEqual(left['x'],self.layout[49]['x'])  # LAlt
        self.assertEqual(right['x'],self.layout[52]['x'])  # RCtrl
        for start,center,modifier in ((61,69,49),(65,70,52)):
            self.assertEqual(self.layout[start]['y'],self.layout[modifier]['y']+1)
            self.assertEqual(self.layout[center]['y'],self.layout[modifier]['y']+2)

    def test_compact_canvas_is_fourteen_by_eight_units(self):
        self.assertEqual(min(k['x'] for k in self.layout),0)
        self.assertEqual(min(k['y'] for k in self.layout),0)
        self.assertEqual(max(k['x']+k.get('w',1) for k in self.layout),14)
        self.assertEqual(max(k['y']+k.get('h',1) for k in self.layout),8)

    def test_thumb_coordinates_and_cross_horizontal_separation(self):
        self.assertEqual([(k['x'],k['y']) for k in self.layout[54:60]],
                         [(3.0,5.25),(4.0,5.25),(5.0,5.25),
                          (8.0,5.25),(9.0,5.25),(10.0,5.25)])
        self.assertLessEqual(max(self.layout[i]['x']+1 for i in (61,62,63,64,69)),
                             min(k['x'] for k in self.layout[54:57]))
        self.assertGreaterEqual(min(self.layout[i]['x'] for i in (65,66,67,68,70)),
                                max(k['x']+1 for k in self.layout[57:60]))

    def test_validator_rejects_old_under_thumb_placement(self):
        bad=deepcopy(self.layout)
        for indices,dx,dy in (((61,62,63,64,69),3,2),((65,66,67,68,70),-3,2)):
            for i in indices:bad[i]['x']+=dx;bad[i]['y']+=dy
        with self.assertRaises(SystemExit):validate.check_trackball_cross(bad)

    def test_every_cross_key_is_one_unrotated_square(self):
        for p in self.layout[61:]:
            self.assertEqual((p.get('w',1),p.get('h',1)),(1,1))
            self.assertFalse(any(p.get(axis,0) for axis in ('r','rx','ry')))

    def test_populated_matrix_addresses_preserved_and_count_compacted(self):
        self.assertEqual(len(self.layout),71)
        self.assertEqual([(p['row'],p['col']) for p in self.layout],POSITIONS)

    def generated(self,side):
        dts,_=resolve_dts(fixture(),side,self.layout)
        attrs=re.findall(r'<&key_physical_attrs\s+([^>]+)>',dts)
        rows=[[int(x) for x in attr.split()] for attr in attrs]
        return dts,rows

    def test_left_dts_keeps_all_geometry_and_indices(self):
        _,rows=self.generated('left')
        self.assertEqual(rows,[[round(p.get('w',1)*100),round(p.get('h',1)*100),round(p['x']*100),round(p['y']*100),0,0,0] for p in self.layout])

    def test_right_dts_uses_same_layout_as_central(self):
        self.assertEqual(self.generated('left')[1],self.generated('right')[1])

    def test_generated_mode_centers_are_square_and_surrounded(self):
        _,rows=self.generated('left')
        for start,center in ((61,69),(65,70)):
            c=rows[center]
            self.assertEqual(c[:2],[100,100])
            for i,(dx,dy) in enumerate(((0,-100),(0,100),(-100,0),(100,0))):
                self.assertEqual(rows[start+i][2:4],[c[2]+dx,c[3]+dy])

    def test_generated_map_preserves_sensor_and_setting_positions(self):
        text,_=self.generated('left')
        block=re.search(r'\bmap\s*=\s*<([^>]+)>',text).group(1)
        addresses=[tuple(map(int,p)) for p in re.findall(r'RC\(\s*(\d+)\s*,\s*(\d+)\s*\)',block)]
        self.assertEqual(addresses,POSITIONS)

    def test_validator_rejects_swapped_up_and_down(self):
        bad=deepcopy(self.layout)
        bad[61]['y'],bad[62]['y']=bad[62]['y'],bad[61]['y']
        with self.assertRaises(SystemExit):validate.check_trackball_cross(bad)

    def test_validator_rejects_old_oversized_center(self):
        bad=deepcopy(self.layout);bad[69]['w']=1.6;bad[69]['h']=1.6
        with self.assertRaises(SystemExit):validate.check_trackball_cross(bad)

    def test_validator_rejects_rotation(self):
        bad=deepcopy(self.layout);bad[64]['r']=90
        with self.assertRaises(SystemExit):validate.check_trackball_cross(bad)

    def test_validator_rejects_cross_overlapping_main_keys(self):
        bad=deepcopy(self.layout)
        for i in (61,62,63,64,69):bad[i]['y']-=6
        with self.assertRaises(SystemExit):validate.check_trackball_cross(bad)

    def test_preview_contains_actual_geometry_and_source_bindings(self):
        html=(ROOT/'STUDIO_LAYOUT_PREVIEW_KO.html').read_text()
        embedded=json.loads(html.split('const DATA=',1)[1].split(';const unit=',1)[0])
        self.assertEqual(embedded['layout'],self.layout)
        self.assertEqual(embedded['layers'],validate.bindings_with_parameters((ROOT/'config/modu.keymap').read_text()))
        style=re.search(r'\.mode-setting\{([^}]+)\}',html).group(1)
        self.assertNotIn('50%',style)
        self.assertNotIn('radial-gradient',style)
        self.assertNotIn('studio-extension',html)

if __name__=='__main__':unittest.main()
