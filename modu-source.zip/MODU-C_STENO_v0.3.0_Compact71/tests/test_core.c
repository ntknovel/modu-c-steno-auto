/* Native tests of pure C state/conversion logic. No Zephyr/hardware is simulated. */
#include <modu/core.h>
#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned checks;
#define CHECK(expr) do { checks++; if(!(expr)) { fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#expr);exit(1); } } while(0)
static void defaults_and_limits(void) {
    struct mc_core c;mc_init(&c);
    CHECK(mc_config_valid(&c.config[0]));CHECK(mc_config_valid(&c.config[1]));
    CHECK(mc_mode(&c,0)==MC_MOUSE);CHECK(mc_mode(&c,1)==MC_MOUSE);
    for(unsigned side=0;side<2;side++) {
        for(unsigned i=0;i<30;i++)CHECK(mc_change(&c,side,MC_KIND_CPI,MC_INC,0)==0);
        CHECK(c.config[side].cpi==3200);
        for(unsigned i=0;i<30;i++)CHECK(mc_change(&c,side,MC_KIND_CPI,MC_DEC,0)==0);
        CHECK(c.config[side].cpi==200);
        CHECK(mc_change(&c,side,MC_KIND_CPI,MC_SET,750)==-ERANGE);
        CHECK(mc_change(&c,side,MC_KIND_CPI,MC_SET,0)==-ERANGE);
        CHECK(mc_change(&c,side,MC_KIND_CPI,MC_SET,UINT32_MAX)==-ERANGE);
        CHECK(c.config[side].cpi==200);
        for(unsigned v=200;v<=3200;v+=200) {
            CHECK(mc_change(&c,side,MC_KIND_CPI,MC_SET,v)==0);
            CHECK(c.config[side].cpi==v);CHECK(mc_config_valid(&c.config[side]));
        }
        CHECK(mc_change(&c,side,MC_KIND_RESET,MC_RESET,0)==0);
        CHECK(!memcmp(&c.config[side],&mc_defaults,sizeof(mc_defaults)));
    }
    CHECK(mc_change(&c,0,MC_KIND_CPI,MC_SET,1200)==0);CHECK(c.config[1].cpi==600);
    CHECK(mc_change(&c,2,MC_KIND_CPI,MC_INC,0)==-EINVAL);
    CHECK(mc_change(&c,0,MC_KIND_CPI,99,0)==-EINVAL);
    CHECK(mc_change(&c,0,MC_KIND_MODE,MC_SET,4)==-ERANGE);
    CHECK(mc_change(&c,0,MC_KIND_DIAGONAL,MC_SET,2)==-ERANGE);
    CHECK(mc_change(&c,0,MC_KIND_INVERT,MC_SET,2)==-ERANGE);
    c.config[0].reserved=1;CHECK(!mc_config_valid(&c.config[0]));
}
static void holds(void) {
    struct mc_core c;mc_init(&c);
    CHECK(mc_change(&c,0,MC_KIND_MODE,MC_SET,MC_SCROLL)==0);
    CHECK(mc_hold(&c,0,11,MC_ARROWS,true)==0);CHECK(mc_mode(&c,0)==MC_ARROWS);
    CHECK(mc_hold(&c,0,22,MC_MOUSE,true)==0);CHECK(mc_mode(&c,0)==MC_MOUSE);
    CHECK(mc_mode(&c,1)==MC_MOUSE);
    CHECK(mc_hold(&c,0,11,0,false)==0);CHECK(mc_mode(&c,0)==MC_MOUSE);
    CHECK(mc_hold(&c,0,22,0,false)==0);CHECK(mc_mode(&c,0)==MC_SCROLL);
    CHECK(mc_hold(&c,0,11,MC_ARROWS,true)==0);CHECK(mc_hold(&c,0,22,MC_OFF,true)==0);
    CHECK(mc_hold(&c,0,22,0,false)==0);CHECK(mc_mode(&c,0)==MC_ARROWS);
    CHECK(mc_change(&c,0,MC_KIND_MODE,MC_SET,MC_MOUSE)==0);CHECK(mc_mode(&c,0)==MC_ARROWS);
    CHECK(mc_hold(&c,0,11,0,false)==0);CHECK(mc_mode(&c,0)==MC_MOUSE);
    for(unsigned i=0;i<MC_HOLD_SLOTS;i++)CHECK(mc_hold(&c,0,i,MC_SCROLL,true)==0);
    CHECK(mc_hold(&c,0,0,MC_SCROLL,true)==0);CHECK(c.motion[0].held==MC_HOLD_SLOTS);
    CHECK(mc_hold(&c,0,0,MC_ARROWS,true)==-EALREADY);
    CHECK(mc_hold(&c,0,99,MC_ARROWS,true)==-ENOSPC);
    for(unsigned i=0;i<MC_HOLD_SLOTS;i++)CHECK(mc_hold(&c,0,i,0,false)==0);
    CHECK(mc_mode(&c,0)==MC_MOUSE);CHECK(mc_hold(&c,0,123,0,false)==0);
    CHECK(mc_hold(&c,1,1,MC_ARROWS,true)==0);mc_cancel_holds(&c);
    CHECK(mc_mode(&c,1)==MC_MOUSE);CHECK(c.motion[1].held==0);
}
static void fractional_and_scroll(void) {
    struct mc_core c;struct mc_result r;mc_init(&c);
    CHECK(mc_change(&c,0,MC_KIND_POINTER,MC_SET,25)==0);
    for(unsigned i=0;i<3;i++){CHECK(mc_feed(&c,0,0,1,true,&r)==0);CHECK(r.value==0);}
    CHECK(mc_feed(&c,0,0,1,true,&r)==0);CHECK(r.value==1);
    for(unsigned i=0;i<3;i++){CHECK(mc_feed(&c,0,1,-1,true,&r)==0);CHECK(r.value==0);}
    CHECK(mc_feed(&c,0,1,-1,true,&r)==0);CHECK(r.value==-1);
    CHECK(mc_feed(&c,1,0,1,true,&r)==0);CHECK(r.value==1);
    CHECK(mc_change(&c,0,MC_KIND_MODE,MC_SET,MC_SCROLL)==0);
    CHECK(mc_feed(&c,0,1,23,true,&r)==0);CHECK(r.value==0);
    CHECK(mc_feed(&c,0,1,1,true,&r)==0);CHECK(r.value==-1);
    CHECK(mc_feed(&c,0,0,24,true,&r)==0);CHECK(r.value==1);
    CHECK(mc_change(&c,0,MC_KIND_INVERT,MC_SET,1)==0);
    CHECK(mc_feed(&c,0,1,24,true,&r)==0);CHECK(r.value==1);
    CHECK(mc_change(&c,0,MC_KIND_MODE,MC_SET,MC_OFF)==0);
    CHECK(mc_feed(&c,0,0,INT_MAX,true,&r)==0);CHECK(r.value==0);
    CHECK(mc_change(&c,0,MC_KIND_MODE,MC_SET,MC_MOUSE)==0);
    CHECK(mc_feed(&c,0,0,1,true,&r)==0);CHECK(r.value==0); /* off did not build up motion */
    CHECK(mc_feed(&c,0,0,INT_MAX,true,&r)==0);CHECK(r.value<=32767);
    CHECK(mc_feed(&c,0,0,INT_MIN,true,&r)==0);CHECK(r.value>=-32767);
    CHECK(mc_feed(&c,2,0,0,true,&r)==-EINVAL);CHECK(mc_feed(&c,0,2,0,true,&r)==-EINVAL);
    CHECK(mc_feed(&c,0,0,0,true,NULL)==-EINVAL);
}
static void arrows(void) {
    struct mc_core c;struct mc_result r;mc_init(&c);
    CHECK(mc_change(&c,0,MC_KIND_MODE,MC_SET,MC_ARROWS)==0);
    CHECK(mc_feed(&c,0,0,45,false,&r)==0);CHECK(r.arrows[3]==0);
    CHECK(mc_feed(&c,0,1,10,true,&r)==0);CHECK(r.arrows[3]==1);CHECK(r.arrows[1]==0);
    CHECK(mc_feed(&c,0,1,-40,true,&r)==0);CHECK(r.arrows[0]==1);
    CHECK(mc_feed(&c,0,0,-40,true,&r)==0);CHECK(r.arrows[2]==1); /* dominant Y input cleared the old X remainder */
    CHECK(mc_feed(&c,0,0,-5,true,&r)==0);CHECK(r.arrows[2]==0);
    CHECK(mc_change(&c,0,MC_KIND_DIAGONAL,MC_SET,1)==0);
    CHECK(mc_feed(&c,0,0,80,false,&r)==0);CHECK(mc_feed(&c,0,1,40,true,&r)==0);
    CHECK(r.arrows[3]==2);CHECK(r.arrows[1]==1);
    CHECK(mc_feed(&c,0,1,INT_MIN,true,&r)==0);CHECK(r.arrows[0]==4);
    CHECK(mc_feed(&c,0,0,INT_MAX,true,&r)==0);CHECK(r.arrows[3]==4);
    CHECK(mc_change(&c,0,MC_KIND_MODE,MC_SET,MC_MOUSE)==0);
    CHECK(mc_feed(&c,0,0,0,true,&r)==0);CHECK(r.arrows[3]==0);CHECK(r.value==0);
    CHECK(mc_change(&c,0,MC_KIND_SCROLL,MC_MAX,0)==0);CHECK(c.config[0].scroll_div==1);
    CHECK(mc_change(&c,0,MC_KIND_ARROW,MC_MAX,0)==0);CHECK(c.config[0].arrow_div==1);
    CHECK(mc_change(&c,0,MC_KIND_RATE,MC_MAX,0)==0);CHECK(c.config[0].arrow_ms==20);
    CHECK(mc_change(&c,0,MC_KIND_RATE,MC_SET,19)==-ERANGE);
    CHECK(mc_change(&c,0,MC_KIND_POINTER,MC_SET,401)==-ERANGE);
}
static void randomized_invariants(void) {
    struct mc_core c;struct mc_result r;mc_init(&c);unsigned long v=0x7193;
    for(unsigned i=0;i<20000;i++) {
        v=(v*1664525u+1013904223u)&0xffffffffu;unsigned side=(unsigned)v%2;
        unsigned mode=(unsigned)(v>>2)%4;
        CHECK(mc_change(&c,side,MC_KIND_MODE,MC_SET,mode)==0);
        CHECK(mc_feed(&c,side,(unsigned)(v>>5)%2,(int32_t)(uint32_t)v,true,&r)==0);
        CHECK(mc_config_valid(&c.config[side]));CHECK(r.mode==mode);
        for(unsigned d=0;d<4;d++)CHECK(r.arrows[d]<=4);
        CHECK(r.value>=-32767 && r.value<=32767);
    }
}
int main(void) {
    defaults_and_limits();holds();fractional_and_scroll();arrows();randomized_invariants();
    printf("PASS: %u assertions; pure-C state/conversion tests only. No hardware/Zephyr.\n",checks);
    return 0;
}
