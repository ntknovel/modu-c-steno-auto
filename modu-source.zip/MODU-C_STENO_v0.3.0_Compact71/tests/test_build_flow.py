"""Exercise build orchestration with mocked west, not a firmware compile."""
from pathlib import Path
from unittest.mock import patch
import json
import sys
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import build_firmware as bf

class BuildFlowTests(unittest.TestCase):
    def flow(self, fail=None):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            for name in ('LICENSE','NOTICE.md','THIRD_PARTY_NOTICES.md'):
                (root/name).write_text('test notice')
            (root/'LICENSES').mkdir();(root/'docs').mkdir()
            (root/'docs/original-modu.keymap.txt').write_bytes((ROOT/'docs/original-modu.keymap.txt').read_bytes())
            (root/'build.yaml').write_text(json.dumps({'include':[{'side':'left','board':'ms88sf3/nrf52840','shield':'modu_left','snippet':'studio-rpc-usb-uart'}]}))
            calls=[]
            def run(command,cwd,log):
                stage='original' if '--cmake-only' in command else ('check' if any(str(x).endswith('check_built.py') for x in command) else 'compile')
                calls.append(stage)
                if stage==fail: raise RuntimeError('simulated '+stage+' failure')
                if stage=='original':
                    self.assertEqual((root/'build/original-config-left/modu.keymap').read_bytes(),bf.original_keymap(root))
                if stage=='compile':
                    out=root/'build/left/zephyr';out.mkdir(parents=True)
                    (out/'zmk.hex').write_text('SYNTHETIC PLACEHOLDER - NOT FIRMWARE')
            def prepare(*args):
                calls.append('resolve')
                self.assertEqual(args[-1],root/'build/original-left')
            with patch.object(sys,'argv',['build_firmware.py','--config',str(root),'--workspace',str(root),'--side','left']),patch.object(bf,'prepare_project',return_value={}),patch.object(bf,'apply_compact_storage',return_value={}),patch.object(bf,'verify_commit'),patch.object(bf,'run',side_effect=run),patch.object(bf,'prepare',side_effect=prepare):
                if fail:
                    with self.assertRaises(RuntimeError):bf.main()
                else:bf.main()
            exists=(root/'intermediate/modu_left.hex').exists()
            return calls,exists
    def test_original_resolve_compile_compare_before_publish(self):
        calls,published=self.flow()
        self.assertEqual(calls,['original','resolve','compile','check']);self.assertTrue(published)
    def test_original_failure_cannot_publish(self):
        calls,published=self.flow('original')
        self.assertEqual(calls,['original']);self.assertFalse(published)
    def test_compile_failure_cannot_publish(self):
        calls,published=self.flow('compile')
        self.assertEqual(calls,['original','resolve','compile']);self.assertFalse(published)
    def test_comparison_failure_cannot_publish(self):
        calls,published=self.flow('check')
        self.assertEqual(calls,['original','resolve','compile','check']);self.assertFalse(published)
