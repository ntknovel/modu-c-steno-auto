"""Regression for run 34284077540: UP/DOWN macros collided with enum action.
These are native compiler tests using test headers, NOT an ARM/Zephyr build.
The negative-control compile must fail; the production translation unit must pass.
"""
from pathlib import Path
import os
import re
import shlex
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
MODULE = ROOT / "modules/modu-steno"
VALIDATION = MODULE / "validation"
OUTPUT = MODULE / "src/steno/steno_output.c"


class OutputNamespaceRegression(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cc = shlex.split(os.environ.get("CC", "cc"))
        if not cls.cc or not shutil.which(cls.cc[0]):
            raise unittest.SkipTest("A host C compiler is required; GitHub validation provides cc")

    def compile(self, text, variant="runtime_stubs", config=False):
        includes = [VALIDATION / variant]
        includes += [VALIDATION / p for p in ("runtime_stubs", "stubs", "api_stubs") if p != variant]
        with tempfile.TemporaryDirectory(prefix="modu-output-namespace-") as temp:
            file = Path(temp) / "probe.c"
            file.write_text(text)
            command = self.cc + ["-std=c11", "-Wall", "-Wextra", "-Werror", "-fsyntax-only"]
            if config:
                command += ["-include", str(VALIDATION / "modu_runtime_config.h")]
            for path in includes + [MODULE / "include"]:
                command += ["-I", str(path)]
            command += [str(file)]
            return subprocess.run(command, capture_output=True, text=True, timeout=30)

    def test_key_event_headers_expose_direction_macros(self):
        code = """#include <zmk/events/keycode_state_changed.h>
#ifndef DOWN
#error key event header must expose DOWN
#endif
#ifndef UP
#error key event header must expose UP
#endif
_Static_assert(DOWN == DOWN_ARROW, "DOWN alias changed");
_Static_assert(UP == UP_ARROW, "UP alias changed");
"""
        for variant in ("runtime_stubs", "api_stubs"):
            with self.subTest(variant=variant):
                result = self.compile(code, variant)
                self.assertEqual(result.returncode, 0, result.stderr)

    def test_original_bare_enum_fails_as_negative_control(self):
        code = "#include <zmk/events/keycode_state_changed.h>\nenum action { TAP, DOWN, UP };\n"
        for variant in ("runtime_stubs", "api_stubs"):
            with self.subTest(variant=variant):
                result = self.compile(code, variant)
                self.assertNotEqual(result.returncode, 0, "Test header lost the real macro collision")
                self.assertIn("DOWN", result.stderr)

    def test_complete_output_translation_unit_compiles_with_keycodes(self):
        # Unlike the old tests, keycode macros reach the output C translation unit.
        for variant in ("runtime_stubs", "api_stubs"):
            with self.subTest(variant=variant):
                result = self.compile(OUTPUT.read_text(), variant, config=True)
                self.assertEqual(result.returncode, 0, result.stderr)

    def test_restoring_bare_enum_to_current_source_is_caught(self):
        mutant = OUTPUT.read_text()
        for old, bad in (("CST_OUTPUT_TAP", "TAP"), ("CST_OUTPUT_PRESS", "DOWN"), ("CST_OUTPUT_RELEASE", "UP")):
            mutant = re.sub(r"\b" + old + r"\b", bad, mutant)
        result = self.compile(mutant, config=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("DOWN", result.stderr)

    def test_firmware_does_not_undefine_direction_keycodes(self):
        code = OUTPUT.read_text()
        self.assertNotRegex(code, r"(?m)^\s*#\s*undef\s+(?:DOWN|UP)\b")
        self.assertIn("enum cst_output_action", code)
        for name in ("CST_OUTPUT_TAP", "CST_OUTPUT_PRESS", "CST_OUTPUT_RELEASE"):
            self.assertIn(name, code)


if __name__ == "__main__":
    unittest.main(verbosity=2)
