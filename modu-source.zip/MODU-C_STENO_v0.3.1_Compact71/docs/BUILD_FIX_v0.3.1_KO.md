# MODU-C STENO v0.3.1 — 왼쪽 빌드 오류 수정

분석일: 2026-09-09. 자동 빌더 v1.1.1에 포함하는 펌웨어 소스입니다.

## 원인

사용자가 제공한 GitHub Actions 실행 34284077540의 왼쪽 build.log 1064~1069행:

```text
keys.h:418:14: error: expected identifier before '(' token
#define DOWN (DOWN_ARROW)
steno_output.c:19:20: note: in expansion of macro 'DOWN'
enum action { TAP, DOWN, UP };
```

ZMK는 DOWN과 UP을 방향키 매크로로 사용합니다. 속기 출력 큐가 같은 이름을 열거값으로 사용하여 전처리 단계에서 충돌했습니다. 오른쪽에는 중앙 전용 속기 출력 큐가 컴파일되지 않으므로 이 오류가 발생하지 않았습니다. 첨부 오른쪽 로그에는 최종 링크 및 check_built.py 통과가 있습니다. 토큰·저장소 생성·자동 업로드 실패가 아닙니다.

## 수정

큐의 전용 이름을 CST_OUTPUT_TAP / CST_OUTPUT_PRESS / CST_OUTPUT_RELEASE, 열거형을 cst_output_action으로 변경했습니다. ZMK의 UP/DOWN 정의를 삭제하거나 우회하지 않습니다. 키 입력/해제 큐의 연산, 순서, 타이밍, 예약 용량은 변경하지 않았습니다.

테스트용 이벤트 헤더 2종에 실제 ZMK처럼 키코드 정의가 노출되게 했습니다. 방향키 별칭도 괄호형으로 재현하되 기존 호스트 숫자값은 유지합니다. 기존 검사는 이 헤더 포함 경로가 빠져 오류를 놓쳤습니다.

새 tests/test_steno_output_namespace.py는 원래 열거형이 실패하는 음성 대조군, 정상 전체 출력 C 파일의 컴파일, 오류 이름을 복원하는 변이 검사, 방향키 매크로 보존을 확인합니다. GitHub의 기존 unittest discover 단계에서 자동 실행됩니다.

## 바뀌지 않은 항목

config/ 전체, 일반·속기 키배치, 오른쪽 B 토글, 약어/퀵매크로, 디코더·엔진, 숫자·기호·F1~F12, 500ms 판정, 트랙볼 제어 모듈, USB Studio 및 modusteno1 저장 이름을 그대로 유지했습니다. docs/PRESERVATION_v0.3.1.json에 SHA-256 비교 결과가 있습니다. 이름을 역변환한 출력 소스의 C 토큰열도 원본과 동일합니다.

## 검증 범위

수정 전 소스 + 개선된 테스트 헤더에서 실제 C 컴파일 실패를 재현했습니다. 수정 후 Python 227개, 보조키 476사례, Cornix 회귀, 트랙볼 순수 C 180,378 assertions가 통과했습니다. 보조키와 트랙볼 테스트는 ASan/UBSan을 사용했습니다.

이는 호스트 컴파일/실행 검사입니다. 수정판의 전체 Zephyr/ARM 빌드·Windows PowerShell 실행·실제 GitHub 업로드 및 다운로드·키보드 실기는 여기서 수행하지 못했습니다. 수정 전 사용자 로그의 오른쪽 빌드 성공을 수정판 좌우 빌드 성공으로 간주하지 않습니다.
